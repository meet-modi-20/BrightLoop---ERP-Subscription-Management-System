from flask import Blueprint, request, jsonify
from database import get_db

products_bp = Blueprint('products', __name__)

@products_bp.route('', methods=['GET'])
def list_products():
    ptype = request.args.get('type')
    active_only = request.args.get('active', 'true').lower() == 'true'
    search = request.args.get('search', '').strip()

    query = "SELECT * FROM products WHERE 1=1"
    params = []

    if active_only:
        query += " AND active = 1"

    if ptype:
        query += " AND product_type = ?"
        params.append(ptype.lower())

    if search:
        query += " AND (name LIKE ? OR description LIKE ?)"
        wild = f"%{search}%"
        params.extend([wild, wild])

    query += " ORDER BY id DESC"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        products = [dict(p) for p in cursor.fetchall()]

        # Attach variants to each product
        for prod in products:
            cursor.execute("SELECT * FROM product_variants WHERE product_id = ?", (prod['id'],))
            prod['variants'] = [dict(v) for v in cursor.fetchall()]

        return jsonify({"success": True, "count": len(products), "products": products})

@products_bp.route('/<int:prod_id>', methods=['GET'])
def get_product(prod_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM products WHERE id = ?", (prod_id,))
        prod = cursor.fetchone()
        if not prod:
            return jsonify({"success": False, "error": "Product not found"}), 404

        prod_data = dict(prod)
        cursor.execute("SELECT * FROM product_variants WHERE product_id = ?", (prod_id,))
        prod_data['variants'] = [dict(v) for v in cursor.fetchall()]

        return jsonify({"success": True, "product": prod_data})

@products_bp.route('', methods=['POST'])
def create_product():
    data = request.get_json() or {}
    name = data.get('name', '').strip()
    product_type = data.get('product_type', 'subscription')
    sales_price = float(data.get('sales_price', 0.0))
    cost_price = float(data.get('cost_price', 0.0))
    description = data.get('description', '')
    image_url = data.get('image_url', 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&q=80')
    variants = data.get('variants', [])

    if not name:
        return jsonify({"success": False, "error": "Product name is required."}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO products (name, product_type, sales_price, cost_price, description, image_url, active)
            VALUES (?, ?, ?, ?, ?, ?, 1)
        """, (name, product_type, sales_price, cost_price, description, image_url))
        prod_id = cursor.lastrowid

        # Insert variants if provided
        if variants:
            for v in variants:
                add_p = float(v.get('additional_price', 0.0))
                fin_p = round(sales_price + add_p, 2)
                sku = v.get('sku') or f"SKU-{prod_id}-{v.get('variant_name', 'VAR')[:3].upper()}"
                cursor.execute("""
                    INSERT INTO product_variants (product_id, variant_name, brand, additional_price, final_price, sku, active)
                    VALUES (?, ?, ?, ?, ?, ?, 1)
                """, (prod_id, v.get('variant_name', 'Standard'), v.get('brand', 'Standard'), add_p, fin_p, sku))

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CREATE', 'product', ?, ?)
        """, (str(prod_id), f"Product '{name}' ({product_type}) created."))

        return jsonify({"success": True, "message": "Product created successfully.", "product_id": prod_id}), 201

@products_bp.route('/<int:prod_id>', methods=['PUT'])
def update_product(prod_id):
    data = request.get_json() or {}
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM products WHERE id = ?", (prod_id,))
        if not cursor.fetchone():
            return jsonify({"success": False, "error": "Product not found"}), 404

        cursor.execute("""
            UPDATE products
            SET name = COALESCE(?, name),
                product_type = COALESCE(?, product_type),
                sales_price = COALESCE(?, sales_price),
                cost_price = COALESCE(?, cost_price),
                description = COALESCE(?, description),
                image_url = COALESCE(?, image_url),
                active = COALESCE(?, active)
            WHERE id = ?
        """, (
            data.get('name'), data.get('product_type'), data.get('sales_price'),
            data.get('cost_price'), data.get('description'), data.get('image_url'),
            data.get('active'), prod_id
        ))

        return jsonify({"success": True, "message": "Product updated successfully."})

@products_bp.route('/<int:prod_id>', methods=['DELETE'])
def delete_product(prod_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE products SET active = 0 WHERE id = ?", (prod_id,))
        return jsonify({"success": True, "message": "Product deactivated."})
