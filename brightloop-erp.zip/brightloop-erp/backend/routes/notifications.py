from flask import Blueprint, request, jsonify
from database import get_db

notifications_bp = Blueprint('notifications', __name__)

@notifications_bp.route('', methods=['GET'])
def get_notifications():
    user_id = request.args.get('user_id')
    with get_db() as conn:
        cursor = conn.cursor()
        if user_id:
            cursor.execute("""
                SELECT * FROM notifications
                WHERE user_id = ? OR user_id IS NULL
                ORDER BY id DESC LIMIT 25
            """, (user_id,))
        else:
            cursor.execute("SELECT * FROM notifications ORDER BY id DESC LIMIT 25")

        rows = [dict(r) for r in cursor.fetchall()]
        unread_count = sum(1 for r in rows if not r['is_read'])

        return jsonify({
            "success": True,
            "unread_count": unread_count,
            "notifications": rows
        })

@notifications_bp.route('/<int:notif_id>/read', methods=['POST'])
def mark_as_read(notif_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE notifications SET is_read = 1 WHERE id = ?", (notif_id,))
        return jsonify({"success": True, "message": "Notification marked as read."})

@notifications_bp.route('/read-all', methods=['POST'])
def mark_all_read():
    data = request.get_json() or {}
    user_id = data.get('user_id')
    with get_db() as conn:
        cursor = conn.cursor()
        if user_id:
            cursor.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ? OR user_id IS NULL", (user_id,))
        else:
            cursor.execute("UPDATE notifications SET is_read = 1")
        return jsonify({"success": True, "message": "All notifications marked as read."})
