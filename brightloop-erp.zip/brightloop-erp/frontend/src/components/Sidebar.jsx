import React from 'react';
import { 
  LayoutDashboard, 
  Repeat, 
  Layers, 
  Package, 
  Users, 
  FileText, 
  Receipt, 
  CreditCard, 
  Tag, 
  BarChart3, 
  Settings, 
  Compass,
  Sparkles,
  ChevronRight,
  LogOut,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Sidebar({ currentView, setCurrentView, openOdooModal }) {
  const { user, logout } = useAuth();
  const role = user?.role?.toUpperCase() || 'ADMIN';

  // Navigation items configuration
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['ADMIN', 'STAFF'] },
    { id: 'portal', label: 'Customer Portal', icon: LayoutDashboard, roles: ['CUSTOMER'] },
    { id: 'subscriptions', label: 'Subscriptions', icon: Repeat, roles: ['ADMIN', 'STAFF'], badge: 'Core' },
    { id: 'plans', label: 'Plans', icon: Layers, roles: ['ADMIN', 'STAFF'] },
    { id: 'products', label: 'Products', icon: Package, roles: ['ADMIN', 'STAFF'] },
    { id: 'customers', label: 'Customers', icon: Users, roles: ['ADMIN', 'STAFF'] },
    { id: 'quotations', label: 'Quotations', icon: FileText, roles: ['ADMIN', 'STAFF'] },
    { id: 'invoices', label: 'Invoices', icon: Receipt, roles: ['ADMIN', 'STAFF'] },
    { id: 'payments', label: 'Payments', icon: CreditCard, roles: ['ADMIN', 'STAFF'] },
    { id: 'discounts', label: 'Discounts', icon: Tag, roles: ['ADMIN'] },
    { id: 'reports', label: 'Reports', icon: BarChart3, roles: ['ADMIN', 'STAFF'] },
    { id: 'settings', label: 'Settings', icon: Settings, roles: ['ADMIN'] }
  ];

  const visibleNav = navItems.filter(item => item.roles.includes(role));

  return (
    <aside className="w-64 bg-[#0a1020] text-slate-300 flex flex-col shrink-0 border-r border-slate-800/80 select-none transition-all duration-300">
      {/* Brand Header */}
      <div className="h-16 flex items-center justify-between px-5 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-brand-600 via-indigo-500 to-purple-500 flex items-center justify-center shadow-lg shadow-brand-500/20 text-white font-extrabold text-lg tracking-tighter">
            BL
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-white text-base tracking-tight">Brightloop</span>
              <span className="text-[10px] font-semibold bg-brand-500/20 text-brand-300 px-1.5 py-0.5 rounded border border-brand-500/30">
                ERP
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono">Odoo Hackathon '26</p>
          </div>
        </div>
      </div>

      {/* Role Badge Card */}
      <div className="px-4 py-3 border-b border-slate-800/60 bg-slate-900/40">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {role === 'ADMIN' && <ShieldCheck className="w-4 h-4 text-brand-400" />}
            {role === 'STAFF' && <UserCheck className="w-4 h-4 text-emerald-400" />}
            {role === 'CUSTOMER' && <Users className="w-4 h-4 text-purple-400" />}
            <span className="text-xs font-semibold text-slate-200">{user?.name || 'User'}</span>
          </div>
          <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
            role === 'ADMIN' ? 'bg-indigo-950/80 text-indigo-300 border-indigo-700/50' :
            role === 'STAFF' ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/50' :
            'bg-purple-950/80 text-purple-300 border-purple-700/50'
          }`}>
            {role}
          </span>
        </div>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <p className="px-3 text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
          {role === 'CUSTOMER' ? 'Client Workspace' : 'ERP Enterprise Modules'}
        </p>

        {visibleNav.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id || (currentView.startsWith(item.id));
          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-gradient-to-r from-brand-600 to-indigo-600 text-white shadow-md shadow-brand-600/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && !isActive && (
                <span className="text-[10px] font-semibold bg-brand-500/20 text-brand-300 px-1.5 py-0.5 rounded border border-brand-500/30">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Odoo Architecture Blueprint button */}
        <div className="pt-4 mt-4 border-t border-slate-800/60">
          <button
            onClick={openOdooModal}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold bg-purple-950/40 text-purple-300 border border-purple-800/40 hover:bg-purple-900/40 transition-colors group"
          >
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 text-purple-400 group-hover:rotate-12 transition-transform" />
              <span>Odoo Architecture</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 opacity-60" />
          </button>
        </div>
      </div>

      {/* Footer / Logout */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40">
        <button
          onClick={logout}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-rose-400 hover:bg-rose-950/20 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}
