import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Printer, 
  Download, 
  Send, 
  CreditCard, 
  CheckCircle2, 
  XCircle, 
  Receipt, 
  Clock, 
  Building,
  User,
  ShieldCheck
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function InvoiceDetail({ id, onBack, onRecordPaymentSuccess }) {
  const [invoice, setInvoice] = useState(null);
  const [loading, setLoading] = useState(true);
  const [payModal, setPayModal] = useState(false);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('upi');
  const [payNotes, setPayNotes] = useState('');
  const [paying, setPaying] = useState(false);

  const toast = useToast();

  const fetchInvoice = async () => {
    setLoading(true);
    try {
      const res = await api.getInvoice(id);
      if (res.success) {
        setInvoice(res.invoice);
        setPayAmount(String(res.invoice.balance_due || res.invoice.grand_total));
      }
    } catch (e) {
      toast.error('Failed to load invoice details');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) fetchInvoice();
  }, [id]);

  const handleConfirm = async () => {
    try {
      const res = await api.confirmInvoice(invoice.id);
      if (res.success) {
        toast.success(res.message);
        fetchInvoice();
      }
    } catch (e) {
      toast.error('Confirmation failed');
    }
  };

  const handleCancel = async () => {
    try {
      const res = await api.cancelInvoice(invoice.id);
      if (res.success) {
        toast.success(res.message);
        fetchInvoice();
      }
    } catch (e) {
      toast.error('Cancellation failed');
    }
  };

  const handleSend = async () => {
    try {
      const res = await api.sendInvoice(invoice.id);
      if (res.success) {
        toast.success(res.message);
      }
    } catch (e) {
      toast.error('Failed to send invoice');
    }
  };

  const handleRecordPayment = async (e) => {
    e.preventDefault();
    const amt = parseFloat(payAmount);
    if (!amt || amt <= 0) {
      toast.error('Please enter a valid positive payment amount.');
      return;
    }

    setPaying(true);
    try {
      const res = await api.recordPayment({
        invoice_id: invoice.id,
        amount: amt,
        payment_method: payMethod,
        notes: payNotes,
        status: 'completed'
      });
      if (res.success) {
        toast.success(res.message);
        setPayModal(false);
        fetchInvoice();
        if (onRecordPaymentSuccess) onRecordPaymentSuccess();
      }
    } catch (err) {
      toast.error(err.message || 'Payment recording failed');
    } finally {
      setPaying(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return <div className="p-12 text-center text-slate-400">Loading invoice {id}...</div>;
  }

  if (!invoice) {
    return (
      <div className="p-12 text-center space-y-3">
        <p className="text-slate-600 font-bold">Invoice not found.</p>
        <button onClick={onBack} className="text-xs text-brand-600 font-semibold underline">Go back</button>
      </div>
    );
  }

  const balance = invoice.balance_due !== undefined ? invoice.balance_due : Math.max(0, invoice.grand_total - invoice.amount_paid);

  return (
    <div className="space-y-6">
      {/* Top Controls Bar (Hidden during print) */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 no-print">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 font-mono">{invoice.invoice_number}</h1>
              <StatusBadge status={invoice.payment_status} type="invoice" />
            </div>
            <p className="text-xs text-slate-500">Bill to: {invoice.customer_name} ({invoice.customer_company})</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print / PDF</span>
          </button>

          <button
            onClick={handleSend}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-brand-50 hover:bg-brand-100 text-brand-700 border border-brand-200 rounded-xl text-xs font-semibold transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send Email</span>
          </button>

          {invoice.payment_status === 'draft' && (
            <button
              onClick={handleConfirm}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm Invoice</span>
            </button>
          )}

          {balance > 0 && invoice.payment_status !== 'cancelled' && (
            <button
              onClick={() => setPayModal(true)}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all"
            >
              <CreditCard className="w-4 h-4" />
              <span>Record Payment</span>
            </button>
          )}

          {invoice.payment_status !== 'cancelled' && invoice.payment_status !== 'paid' && (
            <button
              onClick={handleCancel}
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
              title="Cancel Invoice"
            >
              <XCircle className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Printable Enterprise Invoice Document */}
      <div id="printable-invoice" className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm max-w-4xl mx-auto space-y-8">
        {/* Document Header */}
        <div className="flex flex-col sm:flex-row items-start justify-between pb-6 border-b border-slate-200 gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-brand-600 to-indigo-600 text-white font-extrabold flex items-center justify-center text-sm">
                BL
              </div>
              <span className="text-xl font-extrabold text-slate-900 tracking-tight">Brightloop ERP Inc.</span>
            </div>
            <p className="text-xs text-slate-500">Cloud Subscription Billing Solutions</p>
            <p className="text-xs text-slate-500">Cyber City, Phase 2, Gurugram, Haryana 122002</p>
            <p className="text-xs text-slate-600 font-mono">GSTIN: <span className="font-semibold text-slate-800">06AAACB9988D1Z4</span></p>
          </div>

          <div className="text-left sm:text-right space-y-1">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase">TAX INVOICE</h2>
            <p className="font-mono font-bold text-brand-600 text-sm">{invoice.invoice_number}</p>
            <div className="pt-2">
              <StatusBadge status={invoice.payment_status} type="invoice" />
            </div>
          </div>
        </div>

        {/* Invoice Meta Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Billed To Customer</p>
            <p className="font-bold text-slate-900 text-sm">{invoice.customer_name}</p>
            <p className="font-semibold text-slate-700">{invoice.customer_company}</p>
            <p className="text-slate-600 leading-relaxed">
              {invoice.customer_address || 'Registered Corporate Office'}
              {invoice.customer_city ? `, ${invoice.customer_city}` : ''}
              {invoice.customer_state ? `, ${invoice.customer_state}` : ''}
            </p>
            <p className="text-slate-600 font-mono">GSTIN: <span className="font-semibold">{invoice.customer_tax_id || 'Not Registered'}</span></p>
            <p className="text-slate-500">Email: {invoice.customer_email}</p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Billing Specifications</p>
            <div className="flex justify-between py-0.5 border-b border-slate-200/60">
              <span className="text-slate-500">Invoice Date:</span>
              <span className="font-mono font-semibold text-slate-800">{formatDate(invoice.invoice_date)}</span>
            </div>
            <div className="flex justify-between py-0.5 border-b border-slate-200/60">
              <span className="text-slate-500">Payment Due Date:</span>
              <span className="font-mono font-bold text-rose-700">{formatDate(invoice.due_date)}</span>
            </div>
            {invoice.subscription_number && (
              <div className="flex justify-between py-0.5 border-b border-slate-200/60">
                <span className="text-slate-500">Subscription Contract:</span>
                <span className="font-mono font-bold text-brand-600">{invoice.subscription_number}</span>
              </div>
            )}
            <div className="flex justify-between py-0.5">
              <span className="text-slate-500">Billing Period:</span>
              <span className="font-mono text-slate-700">
                {formatDate(invoice.billing_period_start)} to {formatDate(invoice.billing_period_end)}
              </span>
            </div>
          </div>
        </div>

        {/* Product Line Items */}
        <div>
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-900 text-white text-[10px] font-bold uppercase tracking-wider">
                <th className="py-2.5 px-3 rounded-l-lg">Item / Service Description</th>
                <th className="py-2.5 px-3 text-center">Qty</th>
                <th className="py-2.5 px-3 text-right">Unit Price</th>
                <th className="py-2.5 px-3 text-right">Tax Rate</th>
                <th className="py-2.5 px-3 text-right rounded-r-lg">Total Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(invoice.lines || []).map((line, idx) => (
                <tr key={idx} className="hover:bg-slate-50/60">
                  <td className="py-3 px-3">
                    <p className="font-bold text-slate-900">{line.description}</p>
                    {line.product_name && <p className="text-[10px] text-slate-500">{line.product_name}</p>}
                  </td>
                  <td className="py-3 px-3 text-center font-medium text-slate-700">{line.quantity}</td>
                  <td className="py-3 px-3 text-right font-mono text-slate-700">{formatCurrency(line.unit_price)}</td>
                  <td className="py-3 px-3 text-right font-mono text-slate-500">{line.tax_percent}% GST</td>
                  <td className="py-3 px-3 text-right font-bold text-slate-900 font-mono">{formatCurrency(line.line_total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Calculation Totals */}
        <div className="flex justify-end pt-4 border-t border-slate-200">
          <div className="w-72 space-y-2 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal Amount:</span>
              <span className="font-mono text-slate-900">{formatCurrency(invoice.subtotal)}</span>
            </div>
            {invoice.discount_amount > 0 && (
              <div className="flex justify-between text-emerald-600 font-medium">
                <span>Promotional Discount:</span>
                <span className="font-mono">- {formatCurrency(invoice.discount_amount)}</span>
              </div>
            )}
            <div className="flex justify-between text-slate-600">
              <span>CGST (9.0%):</span>
              <span className="font-mono text-slate-900">{formatCurrency((invoice.tax_amount || 0) / 2)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>SGST (9.0%):</span>
              <span className="font-mono text-slate-900">{formatCurrency((invoice.tax_amount || 0) / 2)}</span>
            </div>
            <div className="flex justify-between font-black text-slate-900 pt-2 border-t border-slate-200 text-sm">
              <span>Invoice Grand Total:</span>
              <span className="font-mono text-brand-600">{formatCurrency(invoice.grand_total)}</span>
            </div>
            <div className="flex justify-between text-emerald-700 font-semibold pt-1">
              <span>Amount Paid:</span>
              <span className="font-mono">{formatCurrency(invoice.amount_paid)}</span>
            </div>
            <div className="flex justify-between font-bold text-rose-700 pt-1 border-t border-slate-100 text-xs">
              <span>Remaining Balance Due:</span>
              <span className="font-mono">{formatCurrency(balance)}</span>
            </div>
          </div>
        </div>

        {/* Matched Payments History */}
        {(invoice.payments || []).length > 0 && (
          <div className="pt-4 border-t border-slate-100">
            <h4 className="font-bold text-slate-900 text-xs mb-2">Recorded Remittances & Transactions</h4>
            <div className="space-y-1.5">
              {invoice.payments.map((p, i) => (
                <div key={i} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl text-xs border border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-700">{p.payment_reference}</span>
                    <span className="text-slate-400">•</span>
                    <span className="uppercase text-[10px] font-bold text-slate-500">{p.payment_method}</span>
                    <span className="text-slate-400">•</span>
                    <span className="text-slate-600">{p.notes || 'Settled'}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-500 font-mono">{formatDate(p.payment_date)}</span>
                    <span className="font-bold text-emerald-700 font-mono">{formatCurrency(p.amount)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer Notes */}
        <div className="pt-6 border-t border-slate-200 text-center text-[10px] text-slate-400 space-y-1">
          <p>Thank you for partnering with Brightloop ERP. This is an electronically generated document.</p>
          <p>Bank: HDFC Bank Ltd • Account: 50200012345678 • IFSC: HDFC0001234 • Branch: Cyber City Gurugram</p>
        </div>
      </div>

      {/* Record Payment Modal */}
      {payModal && (
        <Modal
          isOpen={payModal}
          onClose={() => setPayModal(false)}
          title="Record Customer Payment"
          subtitle={`Match remittance against ${invoice.invoice_number}`}
          maxWidth="max-w-md"
        >
          <form onSubmit={handleRecordPayment} className="space-y-4">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex justify-between">
              <div>
                <p className="text-slate-400 text-[10px] uppercase font-bold">Outstanding Due</p>
                <p className="text-base font-bold text-slate-900 mt-0.5">{formatCurrency(balance)}</p>
              </div>
              <div className="text-right">
                <p className="text-slate-400 text-[10px] uppercase font-bold">Customer</p>
                <p className="font-semibold text-slate-800 mt-0.5">{invoice.customer_name}</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Payment Amount (₹)</label>
              <input
                type="number"
                step="0.01"
                min="1"
                max={balance}
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                Partial payments supported. The invoice balance will be updated automatically.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Payment Method</label>
              <select
                value={payMethod}
                onChange={(e) => setPayMethod(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              >
                <option value="upi">UPI (GPay / PhonePe / Paytm)</option>
                <option value="bank_transfer">Bank Transfer (NEFT / RTGS / IMPS)</option>
                <option value="card">Credit / Debit Card</option>
                <option value="online">Online Payment Gateway</option>
                <option value="cash">Cash / Cheque</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Payment Reference / Notes</label>
              <input
                type="text"
                value={payNotes}
                onChange={(e) => setPayNotes(e.target.value)}
                placeholder="e.g. UTR #AXIS99321 or Bank Txn ID"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setPayModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={paying}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20"
              >
                {paying ? 'Processing...' : 'Confirm Remittance'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
