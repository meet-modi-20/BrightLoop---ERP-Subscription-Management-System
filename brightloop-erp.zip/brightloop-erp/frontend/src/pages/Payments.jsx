import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  Search, 
  Filter, 
  Plus, 
  Receipt, 
  ArrowUpRight, 
  Calendar, 
  Smartphone, 
  Building2, 
  DollarSign 
} from 'lucide-react';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Payments({ setCurrentView, setSelectedId }) {
  const [payments, setPayments] = useState([]);
  const [stats, setStats] = useState({});
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [methodFilter, setMethodFilter] = useState('');
  const [recordModal, setRecordModal] = useState(false);
  const [recording, setRecording] = useState(false);

  // Record payment form
  const [newPay, setNewPay] = useState({
    invoice_id: '',
    amount: '',
    payment_method: 'upi',
    notes: '',
    payment_date: new Date().toISOString().split('T')[0]
  });

  const toast = useToast();

  const fetchPayments = async () => {
    setLoading(true);
    try {
      const res = await api.getPayments({ search: searchTerm, method: methodFilter });
      if (res.success) {
        setPayments(res.payments || []);
        setStats(res.stats || {});
      }
    } catch (e) {
      toast.error('Failed to load payments');
    } finally {
      setLoading(false);
    }
  };

  const loadUnpaidInvoices = async () => {
    try {
      const res = await api.getInvoices({ status: 'confirmed' });
      if (res.success) {
        setInvoices(res.invoices || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, [searchTerm, methodFilter]);

  useEffect(() => {
    loadUnpaidInvoices();
  }, []);

  const handleRecord = async (e) => {
    e.preventDefault();
    if (!newPay.invoice_id || !newPay.amount) {
      toast.error('Please select an invoice and enter amount.');
      return;
    }

    setRecording(true);
    try {
      const res = await api.recordPayment({
        invoice_id: parseInt(newPay.invoice_id),
        amount: parseFloat(newPay.amount),
        payment_method: newPay.payment_method,
        notes: newPay.notes,
        payment_date: newPay.payment_date,
        status: 'completed'
      });
      if (res.success) {
        toast.success(res.message);
        setRecordModal(false);
        setNewPay({
          invoice_id: '',
          amount: '',
          payment_method: 'upi',
          notes: '',
          payment_date: new Date().toISOString().split('T')[0]
        });
        fetchPayments();
      }
    } catch (err) {
      toast.error(err.message || 'Payment recording failed');
    } finally {
      setRecording(false);
    }
  };

  const selectedInv = invoices.find(i => String(i.id) === String(newPay.invoice_id));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <CreditCard className="w-6 h-6 text-brand-600" />
            <span>Customer Payments & Collections</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Remittance tracking, invoice reconciliation, and payment method audit
          </p>
        </div>

        <button
          onClick={() => {
            loadUnpaidInvoices();
            setRecordModal(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
        >
          <Plus className="w-4 h-4" />
          <span>Record New Payment</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Total Collected</p>
          <p className="text-xl font-bold text-emerald-700 mt-0.5">{formatCurrency(stats.total_collected || 0)}</p>
          <span className="text-[10px] text-slate-500">{stats.total_count || 0} remittances</span>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">UPI Payments</p>
          <p className="text-xl font-bold text-slate-900 mt-0.5">{formatCurrency(stats.upi_total || 0)}</p>
          <span className="text-[10px] text-slate-500">Fast digital transfers</span>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Bank Transfers (NEFT/RTGS)</p>
          <p className="text-xl font-bold text-slate-900 mt-0.5">{formatCurrency(stats.bank_total || 0)}</p>
          <span className="text-[10px] text-slate-500">Corporate settlements</span>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Cards & Online</p>
          <p className="text-xl font-bold text-slate-900 mt-0.5">{formatCurrency(stats.card_total || 0)}</p>
          <span className="text-[10px] text-slate-500">Auto-debit / credit</span>
        </div>
      </div>

      {/* Search & Method Filter */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto text-xs">
          {[
            { id: '', label: 'All Methods' },
            { id: 'upi', label: 'UPI' },
            { id: 'bank_transfer', label: 'Bank Transfer' },
            { id: 'card', label: 'Card' },
            { id: 'online', label: 'Online' },
            { id: 'cash', label: 'Cash' }
          ].map(m => (
            <button
              key={m.id}
              onClick={() => setMethodFilter(m.id)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                methodFilter === m.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search ref #, customer, invoice..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-100/80 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
          />
        </div>
      </div>

      {/* Payments Table */}
      <div className="erp-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Payment Ref</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Matched Invoice</th>
                <th className="py-3 px-4">Method</th>
                <th className="py-3 px-4">Amount</th>
                <th className="py-3 px-4">Payment Date</th>
                <th className="py-3 px-4">Notes / Txn ID</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan="8" className="py-8 text-center text-slate-400">Loading payments...</td>
                </tr>
              ) : payments.length === 0 ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-400">No payment records found.</td>
                </tr>
              ) : (
                payments.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{p.payment_reference}</td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-slate-900">{p.customer_name}</p>
                      <p className="text-[10px] text-slate-400">{p.customer_company}</p>
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => {
                          setSelectedId(p.invoice_number);
                          setCurrentView('invoice_detail');
                        }}
                        className="font-mono text-[11px] font-bold text-brand-600 hover:underline bg-brand-50 px-2 py-0.5 rounded"
                      >
                        {p.invoice_number}
                      </button>
                    </td>
                    <td className="py-3 px-4">
                      <span className="uppercase text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {p.payment_method}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-700 font-mono text-sm">
                      {formatCurrency(p.amount)}
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-mono">{formatDate(p.payment_date)}</td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate">{p.notes || '—'}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        p.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                        p.status === 'pending' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                        'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${p.status === 'completed' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                        {p.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Payment Modal */}
      {recordModal && (
        <Modal
          isOpen={recordModal}
          onClose={() => setRecordModal(false)}
          title="Record Customer Remittance"
          subtitle="Match payment against an outstanding invoice"
          maxWidth="max-w-md"
        >
          <form onSubmit={handleRecord} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Select Open Invoice</label>
              <select
                value={newPay.invoice_id}
                onChange={(e) => {
                  const invId = e.target.value;
                  setNewPay({ ...newPay, invoice_id: invId });
                  const inv = invoices.find(i => String(i.id) === String(invId));
                  if (inv) {
                    const bal = Math.max(0, inv.grand_total - inv.amount_paid);
                    setNewPay(prev => ({ ...prev, invoice_id: invId, amount: String(bal) }));
                  }
                }}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              >
                <option value="">-- Choose Invoice to Settle --</option>
                {invoices.map(i => {
                  const bal = Math.max(0, i.grand_total - i.amount_paid);
                  return (
                    <option key={i.id} value={i.id}>
                      {i.invoice_number} - {i.customer_name} (Balance: {formatCurrency(bal)})
                    </option>
                  );
                })}
              </select>
            </div>

            {selectedInv && (
              <div className="p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Customer Entity:</span>
                  <span className="font-semibold">{selectedInv.customer_name}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Invoice Total:</span>
                  <span className="font-mono">{formatCurrency(selectedInv.grand_total)}</span>
                </div>
                <div className="flex justify-between font-bold text-indigo-900 pt-1 border-t border-indigo-200">
                  <span>Outstanding Balance Due:</span>
                  <span className="font-mono">{formatCurrency(Math.max(0, selectedInv.grand_total - selectedInv.amount_paid))}</span>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Amount Paid (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  value={newPay.amount}
                  onChange={(e) => setNewPay({ ...newPay, amount: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Payment Method</label>
                <select
                  value={newPay.payment_method}
                  onChange={(e) => setNewPay({ ...newPay, payment_method: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="upi">UPI (GPay/PhonePe)</option>
                  <option value="bank_transfer">Bank Transfer (NEFT/RTGS)</option>
                  <option value="card">Credit / Debit Card</option>
                  <option value="online">Online Gateway</option>
                  <option value="cash">Cash / Cheque</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Remittance Reference / UTR</label>
              <input
                type="text"
                value={newPay.notes}
                onChange={(e) => setNewPay({ ...newPay, notes: e.target.value })}
                placeholder="e.g. UTR #HDFC0928192 or Cheque #102931"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setRecordModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={recording}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20"
              >
                {recording ? 'Recording...' : 'Submit Payment'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
