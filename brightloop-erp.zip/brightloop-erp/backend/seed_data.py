import datetime
from werkzeug.security import generate_password_hash
from database import get_db, init_db

def seed_all():
    init_db()
    
    with get_db() as conn:
        cursor = conn.cursor()
        
        # Check if already seeded
        cursor.execute("SELECT COUNT(*) as count FROM users")
        if cursor.fetchone()['count'] > 0:
            print("Database already contains data. Cleaning and reseeding...")
            cursor.execute("PRAGMA foreign_keys = OFF;")
            tables = [
                'activity_logs', 'notifications', 'payments', 'discount_usage', 'discounts',
                'invoice_lines', 'invoices', 'subscription_lines', 'subscriptions',
                'quotation_lines', 'quotations', 'plans', 'product_variants', 'products',
                'staff', 'customers', 'users', 'settings'
            ]
            for t in tables:
                cursor.execute(f"DELETE FROM {t};")
                cursor.execute(f"DELETE FROM sqlite_sequence WHERE name='{t}';")
            cursor.execute("PRAGMA foreign_keys = ON;")

        # --- 1. USERS ---
        admin_pass = generate_password_hash("Admin@123!")
        staff_pass = generate_password_hash("Staff@123!")
        customer_pass = generate_password_hash("Customer@123!")

        users_data = [
            ("Aditya Verma (Admin)", "admin@brightloop.com", admin_pass, "admin"),
            ("Rohan Mehta (Staff)", "staff@brightloop.com", staff_pass, "staff"),
            ("Priya Nair (Operations)", "priya@brightloop.com", staff_pass, "staff"),
            ("Vikram Patel (Lead)", "customer@brightloop.com", customer_pass, "customer"),
            ("Aarav Singhania", "aarav@techlabs.in", customer_pass, "customer"),
            ("Meera Iyer", "meera@fintechprime.co", customer_pass, "customer"),
            ("Kavita Rao", "kavita@swiggyenterprise.com", customer_pass, "customer"),
            ("Rajesh Pillai", "rajesh@razorcloud.io", customer_pass, "customer"),
            ("Ananya Sharma", "ananya@freshscale.org", customer_pass, "customer"),
            ("Arjun Deshmukh", "arjun@zohomate.in", customer_pass, "customer"),
            ("Sunita Menon", "sunita@nykaadigital.com", customer_pass, "customer")
        ]

        user_ids = {}
        for name, email, pwd, role in users_data:
            cursor.execute("""
                INSERT INTO users (full_name, email, password_hash, role)
                VALUES (?, ?, ?, ?)
            """, (name, email, pwd, role))
            user_ids[email] = cursor.lastrowid

        # --- 2. STAFF ---
        staff_data = [
            (user_ids["staff@brightloop.com"], "Rohan Mehta", "staff@brightloop.com", "Subscription Management", "Senior Subscription Lead"),
            (user_ids["priya@brightloop.com"], "Priya Nair", "priya@brightloop.com", "Billing & Invoicing", "Billing Operations Analyst")
        ]
        for uid, name, email, dept, title in staff_data:
            cursor.execute("""
                INSERT INTO staff (user_id, name, email, department, role_title)
                VALUES (?, ?, ?, ?, ?)
            """, (uid, name, email, dept, title))

        # --- 3. CUSTOMERS ---
        customers_data = [
            (user_ids["customer@brightloop.com"], "Vikram Patel", "customer@brightloop.com", "+91 98201 12345", "Nexus Software Systems", "Cyber Hub, Level 4", "Gurugram", "Haryana", "India", "122002", "07AAACN1234F1Z1", "Net 15 Days"),
            (user_ids["aarav@techlabs.in"], "Aarav Singhania", "aarav@techlabs.in", "+91 98111 22334", "TechLabs Innovations", "Plot 45, Electronic City", "Bengaluru", "Karnataka", "India", "560100", "29AABCT1234E1Z5", "Net 30 Days"),
            (user_ids["meera@fintechprime.co"], "Meera Iyer", "meera@fintechprime.co", "+91 97234 55667", "Fintech Prime India", "Bandra Kurla Complex, Tower B", "Mumbai", "Maharashtra", "India", "400051", "27AABCF5566D1Z2", "Immediate Payment"),
            (user_ids["kavita@swiggyenterprise.com"], "Kavita Rao", "kavita@swiggyenterprise.com", "+91 96321 88990", "Swiggy Enterprise Logistics", "HSR Layout, Sector 6", "Bengaluru", "Karnataka", "India", "560102", "29AADCS9988C1Z9", "Net 15 Days"),
            (user_ids["rajesh@razorcloud.io"], "Rajesh Pillai", "rajesh@razorcloud.io", "+91 95444 33221", "RazorCloud Infrastructure", "Tidel Park, Module 3", "Chennai", "Tamil Nadu", "India", "600113", "33AABCR4433B1Z3", "Net 30 Days"),
            (user_ids["ananya@freshscale.org"], "Ananya Sharma", "ananya@freshscale.org", "+91 94123 66778", "FreshScale Customer Success", "Mindspace IT Park", "Hyderabad", "Telangana", "India", "500081", "36AABCF8877A1Z4", "Immediate Payment"),
            (user_ids["arjun@zohomate.in"], "Arjun Deshmukh", "arjun@zohomate.in", "+91 93222 44556", "ZohoMate Cloud Tools", "Shivajinagar Square", "Pune", "Maharashtra", "India", "411005", "27AADCD2244E1Z8", "Net 15 Days"),
            (user_ids["sunita@nykaadigital.com"], "Sunita Menon", "sunita@nykaadigital.com", "+91 92111 77889", "Nykaa Digital Brands", "Lower Parel Commercial Hub", "Mumbai", "Maharashtra", "India", "400013", "27AACCN9911F1Z0", "Net 30 Days")
        ]

        customer_ids = []
        for uid, name, email, phone, company, addr, city, state, country, pin, tax, terms in customers_data:
            cursor.execute("""
                INSERT INTO customers (user_id, name, email, phone, company, address, city, state, country, postal_code, tax_id, payment_terms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (uid, name, email, phone, company, addr, city, state, country, pin, tax, terms))
            customer_ids.append(cursor.lastrowid)

        # --- 4. PRODUCTS ---
        products_data = [
            ("Brightloop ERP Core", "subscription", 2000.0, 450.0, "Complete enterprise cloud subscription management & automated recurring billing suite.", "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&q=80", 1),
            ("Cloud Analytics & AI Insights", "subscription", 3500.0, 700.0, "Real-time subscription cohort metrics, churn forecast and ARR/MRR predictive analytics.", "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&q=80", 1),
            ("API Gateway & Integrations Hub", "subscription", 1500.0, 300.0, "High-concurrency webhook triggers, Zapier/Odoo synchronizer and REST endpoints.", "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&q=80", 1),
            ("Dedicated Enterprise Onboarding", "service", 12000.0, 4000.0, "1-on-1 migration assistance from legacy Odoo/Stripe, database setup and staff training.", "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&q=80", 1),
            ("Edge Telemetry IoT Gateway", "physical", 8500.0, 5200.0, "Hardware sensor appliance for physical subscription check-ins and device telemetry.", "https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&q=80", 1)
        ]

        prod_ids = []
        for name, ptype, s_price, c_price, desc, img, act in products_data:
            cursor.execute("""
                INSERT INTO products (name, product_type, sales_price, cost_price, description, image_url, active)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (name, ptype, s_price, c_price, desc, img, act))
            prod_ids.append(cursor.lastrowid)

        # --- 5. PRODUCT VARIANTS ---
        variants_data = [
            # Product 1: Brightloop ERP Core (Base: 2000)
            (prod_ids[0], "Basic Edition", "Standard", 0.0, 2000.0, "BL-CORE-BAS"),
            (prod_ids[0], "Professional Edition", "Standard", 1500.0, 3500.0, "BL-CORE-PRO"),
            (prod_ids[0], "Odoo Integrated Brand", "Odoo Brand", 560.0, 2560.0, "BL-CORE-ODOO"),
            # Product 2: AI Insights (Base: 3500)
            (prod_ids[1], "Standard Model", "Brightloop", 0.0, 3500.0, "BL-AI-STD"),
            (prod_ids[1], "Enterprise Predictive Model", "Enterprise Brand", 2500.0, 6000.0, "BL-AI-ENT"),
            # Product 3: API Gateway (Base: 1500)
            (prod_ids[2], "Standard Rate-Limited", "Standard", 0.0, 1500.0, "BL-API-10K"),
            (prod_ids[2], "High-Throughput Unlimited", "Enterprise Brand", 3000.0, 4500.0, "BL-API-UNL")
        ]
        var_ids = []
        for pid, vname, brand, add_price, fin_price, sku in variants_data:
            cursor.execute("""
                INSERT INTO product_variants (product_id, variant_name, brand, additional_price, final_price, sku, active)
                VALUES (?, ?, ?, ?, ?, ?, 1)
            """, (pid, vname, brand, add_price, fin_price, sku))
            var_ids.append(cursor.lastrowid)

        # --- 6. SUBSCRIPTION PLANS ---
        plans_data = [
            ("Starter SaaS Monthly", prod_ids[0], "Essential billing for micro-SaaS and agile startups.", 2560.0, "monthly", 1, "2026-01-01", "2027-12-31", 0, 1, 1, 1, 1),
            ("Growth Business Plan", prod_ids[0], "Advanced subscriptions, custom branding, and webhook automations.", 4999.0, "monthly", 1, "2026-01-01", "2027-12-31", 0, 1, 1, 1, 1),
            ("Enterprise Annual Suite", prod_ids[0], "Uncapped subscriptions, dedicated Odoo connector, priority SLA and audit trail.", 49999.0, "yearly", 1, "2026-01-01", "2027-12-31", 0, 1, 1, 1, 1),
            ("AI Analytics Addon Plan", prod_ids[1], "Monthly subscription cohort & MRR forecast machine learning feed.", 3500.0, "monthly", 1, "2026-01-01", "2027-12-31", 0, 1, 1, 1, 1),
            ("API Micro-Tier Weekly", prod_ids[2], "High frequency weekly subscription for compute-intensive webhook endpoints.", 999.0, "weekly", 1, "2026-01-01", "2027-12-31", 0, 1, 1, 1, 1)
        ]
        plan_ids = []
        for pname, lpid, pdesc, pprice, pfreq, pmin, sdate, edate, aclose, aeclose, apause, arenew, pact in plans_data:
            cursor.execute("""
                INSERT INTO plans (plan_name, linked_product_id, description, price, billing_frequency, min_quantity, start_date, end_date, auto_close, allow_early_closure, allow_pause, allow_renewal, active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (pname, lpid, pdesc, pprice, pfreq, pmin, sdate, edate, aclose, aeclose, apause, arenew, pact))
            plan_ids.append(cursor.lastrowid)

        # --- 7. DISCOUNTS ---
        discounts_data = [
            ("Odoo Hackathon Grand Offer", "HACKATHON2026", "percentage", 20.0, 2000.0, 1, "2026-01-01", "2026-12-31", 500, 28, "ALL", "ALL", 1),
            ("Welcome Business Flat Off", "WELCOME500", "fixed", 500.0, 2500.0, 1, "2026-01-01", "2026-12-31", 1000, 45, "ALL", "ALL", 1),
            ("Enterprise Volume Saver", "ENTERPRISE15", "percentage", 15.0, 10000.0, 2, "2026-01-01", "2027-06-30", 200, 12, "ALL", "ALL", 1)
        ]
        for dname, dcode, dtype, dval, minp, minq, sdate, edate, maxu, curu, approd, appsub, dact in discounts_data:
            cursor.execute("""
                INSERT INTO discounts (name, code, discount_type, discount_value, min_purchase, min_quantity, start_date, end_date, max_usage, current_usage, applicable_products, applicable_subscriptions, active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (dname, dcode, dtype, dval, minp, minq, sdate, edate, maxu, curu, approd, appsub, dact))

        # --- 8. QUOTATIONS ---
        quotations_data = [
            ("QT-2026-0001", customer_ids[0], plan_ids[1], "Growth Business Proposal", "2026-11-20", "Net 15 Days", 4999.0, 500.0, 809.82, 5308.82, "confirmed", "Pre-negotiated contract including priority support."),
            ("QT-2026-0002", customer_ids[1], plan_ids[2], "Enterprise Annual SLA", "2026-11-25", "Net 30 Days", 49999.0, 7499.85, 7649.85, 50149.00, "confirmed", "Includes dedicated onboarding."),
            ("QT-2026-0003", customer_ids[2], plan_ids[0], "Fintech Starter Package", "2026-11-15", "Immediate Payment", 2560.0, 0.0, 460.8, 3020.80, "confirmed", "Standard terms."),
            ("QT-2026-0004", customer_ids[3], plan_ids[1], "Swiggy Fleet Subscription", "2026-12-05", "Net 15 Days", 9998.0, 1999.6, 1439.71, 9438.11, "sent", "Quotation sent for approval by legal team."),
            ("QT-2026-0005", customer_ids[4], plan_ids[4], "RazorCloud API High-Freq", "2026-11-10", "Net 30 Days", 1998.0, 0.0, 359.64, 2357.64, "draft", "Internal draft review.")
        ]

        quote_ids = []
        for qnum, cid, plid, tname, exp, pterms, sub, disc, tax, tot, st, nts in quotations_data:
            cursor.execute("""
                INSERT INTO quotations (quotation_number, customer_id, plan_id, template_name, expiration_date, payment_terms, subtotal, discount_amount, tax_amount, total_amount, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (qnum, cid, plid, tname, exp, pterms, sub, disc, tax, tot, st, nts))
            quote_ids.append(cursor.lastrowid)

        # Quotation lines
        cursor.execute("""
            INSERT INTO quotation_lines (quotation_id, product_id, variant_id, description, quantity, unit_price, tax_percent, discount_percent, total_amount)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (quote_ids[0], prod_ids[0], var_ids[1], "Growth Business Plan - 1 Month", 1, 4999.0, 18.0, 10.0, 5308.82))

        # --- 9. SUBSCRIPTIONS (12 Subscriptions across various statuses) ---
        # Today is 2026-10-31
        subs_data = [
            # 1. Active (Customer 0: Vikram Patel)
            ("SUB-2026-0001", customer_ids[0], plan_ids[1], quote_ids[0], "2026-09-01", "2027-08-31", "2026-11-01", "Net 15 Days", "monthly", 4999.0, 899.82, 0.0, 5898.82, "ACTIVE", 1, "Core ERP for operations."),
            # 2. Active (Customer 1: Aarav Singhania - Due for billing soon!)
            ("SUB-2026-0002", customer_ids[1], plan_ids[2], quote_ids[1], "2026-10-01", "2027-09-30", "2026-11-01", "Net 30 Days", "yearly", 49999.0, 8999.82, 7499.85, 51498.97, "ACTIVE", 1, "Enterprise subscription with Odoo connectors."),
            # 3. Active (Customer 2: Meera Iyer)
            ("SUB-2026-0003", customer_ids[2], plan_ids[0], quote_ids[2], "2026-08-15", "2027-08-14", "2026-11-15", "Immediate Payment", "monthly", 2560.0, 460.80, 0.0, 3020.80, "ACTIVE", 1, "Fintech Prime core subscription."),
            # 4. Active (Customer 3: Kavita Rao)
            ("SUB-2026-0004", customer_ids[3], plan_ids[1], None, "2026-07-01", "2027-06-30", "2026-11-01", "Net 15 Days", "monthly", 4999.0, 899.82, 500.0, 5398.82, "ACTIVE", 1, "Swiggy Logistics analytics plan."),
            # 5. Active (Customer 4: Rajesh Pillai - Weekly API)
            ("SUB-2026-0005", customer_ids[4], plan_ids[4], None, "2026-10-10", "2027-10-09", "2026-11-02", "Net 30 Days", "weekly", 999.0, 179.82, 0.0, 1178.82, "ACTIVE", 1, "High performance webhook compute."),
            # 6. Active (Customer 5: Ananya Sharma - AI Plan)
            ("SUB-2026-0006", customer_ids[5], plan_ids[3], None, "2026-09-10", "2027-09-09", "2026-11-10", "Immediate Payment", "monthly", 3500.0, 630.00, 350.0, 3780.00, "ACTIVE", 1, "Customer analytics cohort engine."),
            # 7. Confirmed (Customer 6: Arjun Deshmukh - ready to activate)
            ("SUB-2026-0007", customer_ids[6], plan_ids[0], None, "2026-11-01", "2027-10-31", "2026-11-01", "Net 15 Days", "monthly", 2560.0, 460.80, 0.0, 3020.80, "CONFIRMED", 1, "Awaiting kickoff deployment."),
            # 8. Quotation stage (Customer 3: Kavita Rao)
            ("SUB-2026-0008", customer_ids[3], plan_ids[1], quote_ids[3], "2026-11-15", "2027-11-14", "2026-11-15", "Net 15 Days", "monthly", 4999.0, 899.82, 0.0, 5898.82, "QUOTATION", 1, "Quotation pending approval."),
            # 9. Draft stage (Customer 7: Sunita Menon)
            ("SUB-2026-0009", customer_ids[7], plan_ids[2], None, "2026-12-01", "2027-11-30", "2026-12-01", "Net 30 Days", "yearly", 49999.0, 8999.82, 0.0, 58998.82, "DRAFT", 1, "Initial negotiation draft."),
            # 10. Paused (Customer 2: Meera Iyer requested maintenance hold)
            ("SUB-2026-0010", customer_ids[2], plan_ids[3], None, "2026-06-01", "2027-05-31", "2026-11-15", "Immediate Payment", "monthly", 3500.0, 630.00, 0.0, 4130.00, "PAUSED", 1, "Temporarily paused on customer request for server migration."),
            # 11. Closed (Customer 5: Ananya Sharma)
            ("SUB-2026-0011", customer_ids[5], plan_ids[0], None, "2025-09-01", "2026-08-31", "2026-08-31", "Immediate Payment", "monthly", 2560.0, 460.80, 0.0, 3020.80, "CLOSED", 0, "Closed voluntarily after contract term ended."),
            # 12. Expired (Customer 6: Arjun Deshmukh)
            ("SUB-2026-0012", customer_ids[6], plan_ids[4], None, "2025-10-01", "2026-10-01", "2026-10-01", "Net 15 Days", "weekly", 999.0, 179.82, 0.0, 1178.82, "EXPIRED", 0, "Grace period passed without renewal.")
        ]

        sub_ids = []
        for snum, cid, plid, qid, sdate, edate, nbdate, pterm, bfreq, sub, tax, disc, tot, stat, arenew, nts in subs_data:
            cursor.execute("""
                INSERT INTO subscriptions (subscription_number, customer_id, plan_id, quotation_id, start_date, expiry_date, next_billing_date, payment_terms, billing_frequency, subtotal, tax_amount, discount_amount, total_amount, status, auto_renew, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (snum, cid, plid, qid, sdate, edate, nbdate, pterm, bfreq, sub, tax, disc, tot, stat, arenew, nts))
            sub_id = cursor.lastrowid
            sub_ids.append(sub_id)

            # Insert subscription lines
            cursor.execute("""
                INSERT INTO subscription_lines (subscription_id, product_id, variant_id, description, quantity, unit_price, tax_percent, total_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (sub_id, prod_ids[0], var_ids[0], "Base Subscription Plan Allocation", 1, sub, 18.0, tot))

        # --- 10. INVOICES (10 realistic invoices across various statuses) ---
        invoices_data = [
            # 1. Paid (Customer 0)
            ("INV-2026-0001", customer_ids[0], sub_ids[0], quote_ids[0], "2026-09-01", "2026-09-16", "2026-09-01", "2026-09-30", 4999.0, 0.0, 899.82, 5898.82, 5898.82, "paid", "Billed via Recurring Engine - Cycle 1"),
            # 2. Paid (Customer 0)
            ("INV-2026-0002", customer_ids[0], sub_ids[0], None, "2026-10-01", "2026-10-16", "2026-10-01", "2026-10-31", 4999.0, 0.0, 899.82, 5898.82, 5898.82, "paid", "Billed via Recurring Engine - Cycle 2"),
            # 3. Paid (Customer 1 - Big Enterprise Annual)
            ("INV-2026-0003", customer_ids[1], sub_ids[1], quote_ids[1], "2026-10-01", "2026-10-31", "2026-10-01", "2027-09-30", 49999.0, 7499.85, 7649.85, 50149.00, 50149.00, "paid", "Enterprise Annual Billing 2026-2027"),
            # 4. Paid (Customer 2)
            ("INV-2026-0004", customer_ids[2], sub_ids[2], quote_ids[2], "2026-09-15", "2026-09-30", "2026-09-15", "2026-10-14", 2560.0, 0.0, 460.80, 3020.80, 3020.80, "paid", "Regular Monthly Cycle"),
            # 5. Confirmed / Partially Paid (Customer 3)
            ("INV-2026-0005", customer_ids[3], sub_ids[3], None, "2026-10-01", "2026-11-05", "2026-10-01", "2026-10-31", 4999.0, 500.0, 809.82, 5308.82, 3000.00, "confirmed", "Partially settled; balance due in 5 days"),
            # 6. Overdue (Customer 4 - past due date 2026-10-25)
            ("INV-2026-0006", customer_ids[4], sub_ids[4], None, "2026-10-10", "2026-10-25", "2026-10-10", "2026-10-17", 999.0, 0.0, 179.82, 1178.82, 0.0, "overdue", "Payment reminder notification dispatched"),
            # 7. Overdue (Customer 2 - past due date 2026-10-29)
            ("INV-2026-0007", customer_ids[2], sub_ids[2], None, "2026-10-15", "2026-10-29", "2026-10-15", "2026-11-14", 2560.0, 0.0, 460.80, 3020.80, 0.0, "overdue", "Pending UPI confirmation from finance desk"),
            # 8. Confirmed (Customer 5 - due in upcoming days)
            ("INV-2026-0008", customer_ids[5], sub_ids[5], None, "2026-10-10", "2026-11-09", "2026-10-10", "2026-11-09", 3500.0, 350.0, 567.00, 3717.00, 0.0, "confirmed", "Upcoming invoice for AI Analytics"),
            # 9. Draft (Customer 0 - newly generated by engine)
            ("INV-2026-0009", customer_ids[0], sub_ids[0], None, "2026-10-31", "2026-11-15", "2026-11-01", "2026-11-30", 4999.0, 0.0, 899.82, 5898.82, 0.0, "draft", "Draft invoice ready for verification"),
            # 10. Cancelled (Customer 6)
            ("INV-2026-0010", customer_ids[6], sub_ids[11], None, "2026-10-01", "2026-10-15", "2026-10-01", "2026-10-08", 999.0, 0.0, 179.82, 1178.82, 0.0, "cancelled", "Cancelled due to subscription lapse")
        ]

        inv_ids = []
        for inum, cid, sid, qid, idate, ddate, pstart, pend, sub, disc, tax, gtot, apaid, pstat, nts in invoices_data:
            cursor.execute("""
                INSERT INTO invoices (invoice_number, customer_id, subscription_id, quotation_id, invoice_date, due_date, billing_period_start, billing_period_end, subtotal, discount_amount, tax_amount, grand_total, amount_paid, payment_status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (inum, cid, sid, qid, idate, ddate, pstart, pend, sub, disc, tax, gtot, apaid, pstat, nts))
            inv_id = cursor.lastrowid
            inv_ids.append(inv_id)

            # Insert invoice line
            cursor.execute("""
                INSERT INTO invoice_lines (invoice_id, product_id, description, quantity, unit_price, tax_percent, line_total)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (inv_id, prod_ids[0], f"Subscription Service Charge ({inum})", 1, sub, 18.0, gtot))

        # --- 11. PAYMENTS (8 realistic payments) ---
        payments_data = [
            ("PAY-2026-0001", customer_ids[0], inv_ids[0], "bank_transfer", 5898.82, "2026-09-05", "NEFT transfer ref #AXIS99321", "completed"),
            ("PAY-2026-0002", customer_ids[0], inv_ids[1], "upi", 5898.82, "2026-10-04", "UPI txn #9820112345@okhdfcbank", "completed"),
            ("PAY-2026-0003", customer_ids[1], inv_ids[2], "bank_transfer", 50149.00, "2026-10-02", "RTGS corporate wire #ICIC882910", "completed"),
            ("PAY-2026-0004", customer_ids[2], inv_ids[3], "card", 3020.80, "2026-09-18", "Corporate Visa Ending in 4921", "completed"),
            ("PAY-2026-0005", customer_ids[3], inv_ids[4], "upi", 3000.00, "2026-10-12", "Part-payment 1 of 2 via PhonePe", "completed"),
            ("PAY-2026-0006", customer_ids[4], inv_ids[5], "online", 500.00, "2026-10-11", "Auto-debit partial batch test", "failed"),
            ("PAY-2026-0007", customer_ids[5], inv_ids[7], "card", 1000.00, "2026-10-28", "Advance token credit for AI suite", "pending"),
            ("PAY-2026-0008", customer_ids[0], inv_ids[0], "cash", 0.0, "2026-09-02", "Counter receipt verification", "completed")
        ]

        for pref, cid, iid, method, amt, pdate, nts, stat in payments_data:
            cursor.execute("""
                INSERT INTO payments (payment_reference, customer_id, invoice_id, payment_method, amount, payment_date, notes, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (pref, cid, iid, method, amt, pdate, nts, stat))

        # --- 12. NOTIFICATIONS ---
        notifs_data = [
            (user_ids["admin@brightloop.com"], "Recurring Invoices Due Today", "3 subscriptions have reached their next billing date (2026-11-01). Click to auto-generate invoices.", "billing", 0, "/invoices"),
            (user_ids["admin@brightloop.com"], "Overdue Invoices Alert", "2 invoices totaling ₹4,199.62 are currently overdue past their payment grace period.", "alert", 0, "/invoices?status=overdue"),
            (user_ids["admin@brightloop.com"], "New Enterprise Subscription", "Aarav Singhania (TechLabs Innovations) confirmed Enterprise Annual Suite for ₹51,498.97.", "subscription", 1, "/subscriptions/SUB-2026-0002"),
            (user_ids["staff@brightloop.com"], "Quotation Approval Request", "Quotation QT-2026-0004 for Swiggy Enterprise requires final review before dispatch.", "quotation", 0, "/quotations"),
            (user_ids["staff@brightloop.com"], "Payment Received", "Payment of ₹50,149.00 recorded for invoice INV-2026-0003.", "payment", 1, "/payments"),
            (user_ids["customer@brightloop.com"], "Subscription Activated", "Welcome to Brightloop ERP! Your Growth Business Plan is now ACTIVE.", "subscription", 0, "/portal"),
            (user_ids["customer@brightloop.com"], "New Invoice Generated", "Invoice INV-2026-0009 for ₹5,898.82 is ready for review.", "billing", 0, "/portal/invoices")
        ]

        for uid, title, msg, cat, is_r, lnk in notifs_data:
            cursor.execute("""
                INSERT INTO notifications (user_id, title, message, category, is_read, link)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (uid, title, msg, cat, is_r, lnk))

        # --- 13. ACTIVITY LOGS ---
        activities_data = [
            (user_ids["admin@brightloop.com"], "Aditya Verma", "CREATE", "subscription", "SUB-2026-0001", "Created subscription for Nexus Software Systems."),
            (user_ids["admin@brightloop.com"], "Aditya Verma", "ACTIVATE", "subscription", "SUB-2026-0001", "Activated subscription and scheduled next billing on 2026-11-01."),
            (user_ids["staff@brightloop.com"], "Rohan Mehta", "GENERATE", "invoice", "INV-2026-0001", "Generated invoice cycle for SUB-2026-0001 for ₹5,898.82."),
            (user_ids["staff@brightloop.com"], "Rohan Mehta", "PAYMENT", "payment", "PAY-2026-0001", "Matched payment of ₹5,898.82 against invoice INV-2026-0001."),
            (user_ids["admin@brightloop.com"], "Aditya Verma", "CREATE", "quotation", "QT-2026-0002", "Generated Enterprise quotation for TechLabs Innovations."),
            (user_ids["admin@brightloop.com"], "Aditya Verma", "CONFIRM", "quotation", "QT-2026-0002", "Quotation confirmed and converted into SUB-2026-0002."),
            (user_ids["customer@brightloop.com"], "Vikram Patel", "PAUSE_REQUEST", "subscription", "SUB-2026-0010", "Customer submitted pause request for maintenance period.")
        ]

        for uid, uname, act, etype, eid, desc in activities_data:
            cursor.execute("""
                INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (uid, uname, act, etype, eid, desc))

        # --- 14. SETTINGS ---
        settings_data = [
            ("company_name", "Brightloop ERP Inc."),
            ("currency", "INR"),
            ("currency_symbol", "₹"),
            ("default_tax_rate", "18.0"),
            ("billing_grace_period_days", "7"),
            ("auto_generate_invoices", "true"),
            ("odoo_api_url", "https://brightloop.odoo.com/jsonrpc"),
            ("odoo_db", "brightloop_production"),
            ("odoo_sync_enabled", "true")
        ]
        for k, v in settings_data:
            cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, v))

    print("Seed data loaded successfully!")

if __name__ == '__main__':
    seed_all()
