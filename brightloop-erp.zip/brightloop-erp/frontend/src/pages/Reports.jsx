import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Download, 
  Filter, 
  Calendar, 
  Repeat, 
  TrendingUp, 
  Receipt, 
  AlertCircle,
  FileSpreadsheet
} from 'lucide-react';
import StatCard from '../components/StatCard';
import StatusBadge from '../components/StatusBadge';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Reports() {
  const [reportType, setReportType] = useState('subscription');
  const [data, setData] = useState([]);
  const [kpis, setKpis] = useState({});
  const [loading, setLoading] = useState(true);

  const toast = useToast();

  const fetchReport = async () => {
    setLoading(true);
    try {
      const res = await api.getAnalytics({ type: reportType });
      if (res.success) {
        setData(res.data || []);
        setKpis(res.kpis || {});
      }
    } catch (e) {
      toast.error('Failed to load report analytics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [reportType]);

  const handleExportCSV = () => {
    window.open(`/api/reports/export?type=${reportType}`, '_blank');
    toast.success(`Exporting ${reportType} report to CSV...`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <BarChart3 className="w-6 h-6 text-brand-600" />
            <span>Executive Analytics & ERP Reports</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Normalized MRR/ARR accounting, aging receivables, and plan performance cohorts
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-md transition-all self-start sm:self-auto"
        >
          <Download className="w-4 h-4 text-brand-400" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Monthly Recurring (MRR)</p>
          <p className="text-xl font-bold text-slate-900 mt-0.5">{formatCurrency(kpis.mrr || 0)}</p>
          <span className="text-[10px] text-slate-500">Normalized recurring flux</span>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Annual Run-Rate (ARR)</p>
          <p className="text-xl font-bold text-brand-600 mt-0.5">{formatCurrency(kpis.arr || 0)}</p>
          <span className="text-[10px] text-slate-500">Projected 12 months</span>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Outstanding Receivables</p>
          <p className="text-xl font-bold text-amber-700 mt-0.5">{formatCurrency(kpis.outstanding_revenue || 0)}</p>
          <span className="text-[10px] text-slate-500">Confirmed open invoices</span>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Overdue Invoices</p>
          <p className="text-xl font-bold text-rose-700 mt-0.5">{kpis.overdue_count || 0}</p>
          <span className="text-[10px] text-rose-600 font-semibold">{formatCurrency(kpis.overdue_amount || 0)} total</span>
        </div>
      </div>

      {/* Report Switcher Tabs */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-1.5 overflow-x-auto text-xs">
        {[
          { id: 'subscription', label: 'Subscription Report' },
          { id: 'revenue', label: 'Revenue Monthly Report' },
          { id: 'payments', label: 'Payment Remittance Report' },
          { id: 'outstanding', label: 'Outstanding Receivables' },
          { id: 'overdue', label: 'Overdue Invoices Aging' },
          { id: 'plan_performance', label: 'Plan Performance & Cohorts' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setReportType(tab.id)}
            className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all ${
              reportType === tab.id
                ? 'bg-brand-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Dynamic Report Table */}
      <div className="erp-card overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm capitalize">
            {reportType.replace('_', ' ')} Dataset ({data.length} records)
          </h3>
          <span className="text-[10px] font-mono text-slate-400">Generated at {new Date().toLocaleTimeString()}</span>
        </div>

        <div className="overflow-x-auto">
          {reportType === 'subscription' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Subscription #</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Plan Name</th>
                  <th className="py-3 px-4">Start Date</th>
                  <th className="py-3 px-4">Next Billing Date</th>
                  <th className="py-3 px-4">Frequency</th>
                  <th className="py-3 px-4">Total Amount</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.map((r, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-brand-600">{r.subscription_number}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{r.customer_name} ({r.company})</td>
                    <td className="py-3 px-4 text-slate-700">{r.plan_name}</td>
                    <td className="py-3 px-4 text-slate-600 font-mono">{formatDate(r.start_date)}</td>
                    <td className="py-3 px-4 text-slate-600 font-mono">{formatDate(r.next_billing_date)}</td>
                    <td className="py-3 px-4 uppercase text-[10px] font-bold text-slate-500">{r.billing_frequency}</td>
                    <td className="py-3 px-4 font-bold text-slate-900 font-mono">{formatCurrency(r.total_amount)}</td>
                    <td className="py-3 px-4"><StatusBadge status={r.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'revenue' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Month Period</th>
                  <th className="py-3 px-4">Transactions Count</th>
                  <th className="py-3 px-4">Total Realized Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.map((r, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-bold text-slate-900 font-mono">{r.month}</td>
                    <td className="py-3 px-4 font-semibold text-slate-700">{r.transaction_count} remittances</td>
                    <td className="py-3 px-4 font-bold text-emerald-700 font-mono text-sm">{formatCurrency(r.total_collected)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'payments' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Ref #</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Invoice #</th>
                  <th className="py-3 px-4">Method</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.map((r, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{r.payment_reference}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{r.customer_name}</td>
                    <td className="py-3 px-4 font-mono text-brand-600 font-bold">{r.invoice_number}</td>
                    <td className="py-3 px-4 uppercase text-[10px] font-bold text-slate-500">{r.payment_method}</td>
                    <td className="py-3 px-4 font-bold text-emerald-700 font-mono">{formatCurrency(r.amount)}</td>
                    <td className="py-3 px-4 text-slate-600 font-mono">{formatDate(r.payment_date)}</td>
                    <td className="py-3 px-4"><StatusBadge status={r.status} type="payment" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'outstanding' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Invoice #</th>
                  <th className="py-3 px-4">Customer & Company</th>
                  <th className="py-3 px-4">Due Date</th>
                  <th className="py-3 px-4">Grand Total</th>
                  <th className="py-3 px-4">Paid</th>
                  <th className="py-3 px-4">Balance Receivable</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.map((r, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-brand-600">{r.invoice_number}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{r.customer_name} ({r.company})</td>
                    <td className="py-3 px-4 text-slate-600 font-mono">{formatDate(r.due_date)}</td>
                    <td className="py-3 px-4 font-mono text-slate-700">{formatCurrency(r.grand_total)}</td>
                    <td className="py-3 px-4 font-mono text-emerald-700">{formatCurrency(r.amount_paid)}</td>
                    <td className="py-3 px-4 font-mono font-bold text-amber-700 text-sm">{formatCurrency(r.balance_due)}</td>
                    <td className="py-3 px-4"><StatusBadge status={r.payment_status} type="invoice" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'overdue' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Invoice #</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Phone Contact</th>
                  <th className="py-3 px-4">Past Due Date</th>
                  <th className="py-3 px-4">Overdue Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.map((r, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-rose-600">{r.invoice_number}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{r.customer_name} ({r.company})</td>
                    <td className="py-3 px-4 text-slate-600">{r.phone || '—'}</td>
                    <td className="py-3 px-4 text-rose-700 font-bold font-mono">{formatDate(r.due_date)}</td>
                    <td className="py-3 px-4 font-bold text-rose-700 font-mono text-sm">{formatCurrency(r.balance_due)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'plan_performance' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Plan Name</th>
                  <th className="py-3 px-4">Recurrence Frequency</th>
                  <th className="py-3 px-4">Price</th>
                  <th className="py-3 px-4">Subscribers Count</th>
                  <th className="py-3 px-4">Active Monthly Recurring Share</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.map((r, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-bold text-slate-900">{r.plan_name}</td>
                    <td className="py-3 px-4 uppercase text-[10px] font-bold text-indigo-700">{r.billing_frequency}</td>
                    <td className="py-3 px-4 font-mono font-semibold text-slate-700">{formatCurrency(r.price)}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">{r.subscriber_count} accounts</td>
                    <td className="py-3 px-4 font-bold text-emerald-700 font-mono text-sm">{formatCurrency(r.active_revenue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
