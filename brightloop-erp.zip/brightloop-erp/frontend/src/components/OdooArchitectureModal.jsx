import React, { useState, useEffect } from 'react';
import { Sparkles, Layers, Database, ArrowRight, Code, Download, Check, Shield } from 'lucide-react';
import Modal from './Modal';
import { api } from '../services/api';

export default function OdooArchitectureModal({ isOpen, onClose }) {
  const [blueprint, setBlueprint] = useState(null);
  const [exportData, setExportData] = useState(null);
  const [activeTab, setActiveTab] = useState('models');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isOpen) {
      api.getOdooBlueprint().then(res => setBlueprint(res.blueprint)).catch(console.error);
      api.getOdooExportSample().then(res => setExportData(res)).catch(console.error);
    }
  }, [isOpen]);

  const handleCopyCode = (code) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Odoo Hackathon: System Architecture & Module Blueprint"
      subtitle="How Brightloop Maps Directly to Odoo Enterprise 17 & 18 ORM & Applications"
      maxWidth="max-w-4xl"
    >
      <div className="space-y-5">
        {/* Banner */}
        <div className="bg-gradient-to-r from-purple-900 to-indigo-900 text-white p-4 rounded-xl flex items-start gap-3 shadow-md">
          <div className="p-2 bg-white/10 rounded-lg shrink-0">
            <Sparkles className="w-5 h-5 text-purple-300" />
          </div>
          <div className="text-xs space-y-1">
            <h4 className="font-bold text-sm text-purple-100">Ready for Custom Odoo Module Conversion</h4>
            <p className="text-purple-200/90 leading-relaxed">
              Brightloop has been purposefully engineered with exact 1-to-1 data relationships matching native Odoo ERP applications: 
              <strong> Contacts (res.partner)</strong>, <strong>Sales & Subscriptions (sale.order)</strong>, <strong>Invoicing (account.move)</strong>, and <strong>Automated Cron Actions (ir.cron)</strong>.
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 gap-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('models')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'models' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Model & Field Mappings</span>
          </button>
          <button
            onClick={() => setActiveTab('cron')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'cron' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Automated Cron Engine</span>
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'code' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>Odoo Python Module Code</span>
          </button>
          <button
            onClick={() => setActiveTab('export')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'export' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Live JSON-RPC Payload</span>
          </button>
        </div>

        {/* Tab 1: Model Mappings */}
        {activeTab === 'models' && blueprint?.models && (
          <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
            {Object.entries(blueprint.models).map(([name, item]) => (
              <div key={name} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/90 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{name}</span>
                    <span className="font-mono text-[11px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded">
                      {item.brightloop_table}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-mono text-[11px] bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded border border-purple-200">
                      {item.odoo_model}
                    </span>
                  </div>
                </div>
                <p className="text-slate-600 leading-relaxed">{item.description}</p>
                <div className="bg-white p-2.5 rounded-lg border border-slate-200/70 font-mono text-[11px]">
                  <p className="text-slate-400 mb-1 font-semibold uppercase text-[10px]">Field Correspondence:</p>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                    {Object.entries(item.field_mappings).map(([blField, odooField]) => (
                      <div key={blField} className="flex items-center justify-between py-0.5 border-b border-slate-100 last:border-0">
                        <span className="text-slate-700">{blField}</span>
                        <span className="text-purple-600 font-medium">{odooField}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Cron Engine */}
        {activeTab === 'cron' && (
          <div className="space-y-4 text-xs leading-relaxed text-slate-700">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <h5 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-600" />
                Scheduled Action: Automated Invoicing Engine (ir.cron)
              </h5>
              <p>
                In native Odoo ERP, recurring subscriptions are billed using a system-level scheduled action defined in XML:
              </p>
              <pre className="bg-slate-950 text-slate-200 p-3.5 rounded-xl font-mono text-[11px] overflow-x-auto">
{`<record id="ir_cron_recurring_invoices" model="ir.cron">
    <field name="name">Sale Subscription: Generate Recurring Invoices</field>
    <field name="model_id" ref="sale.model_sale_order"/>
    <field name="state">code</field>
    <field name="code">model._cron_recurring_create_invoices()</field>
    <field name="interval_number">1</field>
    <field name="interval_type">days</field>
    <field name="numbercall">-1</field>
    <field name="active">True</field>
</record>`}
              </pre>
              <p className="text-slate-600">
                In this Brightloop prototype, our Python backend service <code className="font-mono text-purple-700 font-bold bg-purple-50 px-1 py-0.5 rounded">backend/services/billing_engine.py</code> replicates this exact logic! It evaluates active contracts against their next billing date, generates draft/confirmed invoices, updates the next billing date, and prevents duplicate generation for identical intervals.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Python Snippet */}
        {activeTab === 'code' && (
          <div className="relative">
            <button
              onClick={() => handleCopyCode(blueprint?.sample_odoo_python_snippet || '')}
              className="absolute top-3 right-3 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Code className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Python Code'}</span>
            </button>
            <pre className="bg-slate-950 text-emerald-400 p-4 rounded-xl font-mono text-xs overflow-x-auto leading-relaxed border border-slate-800">
              {blueprint?.sample_odoo_python_snippet}
            </pre>
          </div>
        )}

        {/* Tab 4: Live Payload */}
        {activeTab === 'export' && exportData && (
          <div className="space-y-3">
            <p className="text-xs text-slate-600">
              Below is a sample live export formatted for external Odoo XML-RPC / JSON-RPC migration endpoints:
            </p>
            <pre className="bg-slate-950 text-slate-300 p-4 rounded-xl font-mono text-[11px] overflow-x-auto max-h-72 leading-relaxed border border-slate-800">
              {JSON.stringify(exportData, null, 2)}
            </pre>
          </div>
        )}

        {/* Footer */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Shield className="w-4 h-4 text-emerald-600" />
            <span>Designed for Odoo Hackathon 2026 Evaluation</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl"
          >
            Close Blueprint
          </button>
        </div>
      </div>
    </Modal>
  );
}
