import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Repeat, 
  TrendingUp, 
  Calendar, 
  CreditCard, 
  AlertCircle, 
  Receipt, 
  Clock, 
  Zap, 
  ArrowUpRight, 
  ChevronRight,
  Sparkles,
  Activity,
  Filter
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Legend 
} from 'recharts';
import StatCard from '../components/StatCard';
import StatusBadge from '../components/StatusBadge';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Dashboard({ setCurrentView, setSelectedId }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('30d');
  const [billingRunning, setBillingRunning] = useState(false);
  const toast = useToast();

  const fetchDashboardData = async (range = dateRange) => {
    setLoading(true);
    try {
      const res = await api.getDashboardStats(range);
      if (res.success) {
        setData(res);
      }
    } catch (err) {
      toast.error('Failed to load dashboard metrics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData(dateRange);
  }, [dateRange]);

  const handleGenerateInvoices = async () => {
    setBillingRunning(true);
    try {
      const res = await api.generateDueInvoices();
      if (res.success) {
        toast.success(res.message);
        fetchDashboardData(dateRange);
      }
    } catch (err) {
      toast.error(err.message || 'Invoice generation failed');
    } finally {
      setBillingRunning(false);
    }
  };

  const metrics = data?.metrics || {};
  const charts = data?.charts || {};
  const tables = data?.tables || {};

  const COLORS = ['#6366f1', '#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  return (
    <div className="space-y-6">
      {/* Page Title & Top Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Executive Subscription Dashboard</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time MRR/ARR analytics, automated billing schedules, and contract health
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Date Range Selector */}
          <div className="flex items-center bg-white p-1 rounded-xl border border-slate-200/90 shadow-2xs text-xs font-semibold">
            <span className="text-slate-400 pl-2 pr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
            </span>
            {[
              { id: 'today', label: 'Today' },
              { id: '7d', label: 'Last 7 Days' },
              { id: '30d', label: 'Last 30 Days' },
              { id: '12m', label: 'Last 12 Months' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setDateRange(tab.id)}
                className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                  dateRange === tab.id
                    ? 'bg-brand-600 text-white shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Primary Action Button: GENERATE DUE INVOICES */}
          <button
            onClick={handleGenerateInvoices}
            disabled={billingRunning}
            className="flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all active:scale-98 disabled:opacity-60"
          >
            <Zap className={`w-4 h-4 ${billingRunning ? 'animate-spin' : 'fill-white'}`} />
            <span>{billingRunning ? 'Running Engine...' : 'Generate Due Invoices'}</span>
          </button>
        </div>
      </div>

      {/* 8 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Customers"
          value={metrics.total_customers || 0}
          icon={Users}
          color="blue"
          trend={{ value: '12% this month', positive: true }}
          subtitle="Enterprise accounts"
        />
        <StatCard
          title="Active Subscriptions"
          value={metrics.active_subscriptions || 0}
          icon={Repeat}
          color="emerald"
          trend={{ value: '8.4%', positive: true }}
          subtitle="Live recurring contracts"
        />
        <StatCard
          title="Monthly Recurring (MRR)"
          value={formatCurrency(metrics.mrr || 0)}
          icon={TrendingUp}
          color="indigo"
          trend={{ value: '15.2%', positive: true }}
          subtitle="Normalized monthly revenue"
        />
        <StatCard
          title="Annual Recurring (ARR)"
          value={formatCurrency(metrics.arr || 0)}
          icon={TrendingUp}
          color="purple"
          subtitle="Projected (MRR × 12)"
        />
        <StatCard
          title="Total Collected Revenue"
          value={formatCurrency(metrics.total_revenue || 0)}
          icon={CreditCard}
          color="emerald"
          subtitle="Payments received in period"
        />
        <StatCard
          title="Pending Payments"
          value={formatCurrency(metrics.pending_payments || 0)}
          icon={Receipt}
          color="amber"
          subtitle="Awaiting client settlement"
        />
        <StatCard
          title="Overdue Invoices"
          value={`${metrics.overdue_count || 0} (${formatCurrency(metrics.overdue_amount || 0)})`}
          icon={AlertCircle}
          color="rose"
          subtitle="Requires collection follow-up"
        />
        <StatCard
          title="Upcoming Renewals"
          value={metrics.upcoming_renewals || 0}
          icon={Calendar}
          color="blue"
          subtitle="Contracts expiring in 30 days"
        />
      </div>

      {/* Analytics Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monthly Revenue Chart */}
        <div className="erp-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Monthly Revenue Trend</h3>
              <p className="text-xs text-slate-500">Gross subscription cash flow received by month (₹)</p>
            </div>
            <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-100">
              Live Billing Data
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={charts.monthly_revenue || []}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} tickFormatter={(v) => `₹${v/1000}k`} />
                <Tooltip
                  formatter={(value) => [formatCurrency(value), 'Revenue']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Revenue by Plan Pie Chart */}
        <div className="erp-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Revenue by Plan</h3>
              <p className="text-xs text-slate-500">Active recurring share</p>
            </div>
          </div>
          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={charts.revenue_by_plan || []}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {(charts.revenue_by_plan || []).map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value) => [formatCurrency(value), 'MRR']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-1.5 mt-2">
            {(charts.revenue_by_plan || []).slice(0, 3).map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                  <span className="text-slate-600 truncate max-w-[140px]">{item.name}</span>
                </div>
                <span className="font-bold text-slate-800">{formatCurrency(item.value)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Analytics Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subscription Growth Chart */}
        <div className="erp-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Subscription Growth & Churn</h3>
              <p className="text-xs text-slate-500">Active vs New contracts progression</p>
            </div>
          </div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={charts.subscription_growth || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', color: '#fff', fontSize: '12px' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Line type="monotone" dataKey="active" stroke="#10b981" strokeWidth={2.5} name="Active Subscribers" />
                <Line type="monotone" dataKey="new" stroke="#6366f1" strokeWidth={2} name="New Additions" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Invoicing Status Distribution */}
        <div className="erp-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Invoice Payment Breakdown</h3>
              <p className="text-xs text-slate-500">Settlement status counts</p>
            </div>
          </div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={charts.payment_distribution || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', color: '#fff', fontSize: '12px' }} />
                <Bar dataKey="count" fill="#4f46e5" radius={[6, 6, 0, 0]} name="Invoices" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Operational Data Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Subscriptions */}
        <div className="erp-card p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Repeat className="w-4 h-4 text-brand-600" />
              <h3 className="font-bold text-slate-900 text-sm">Recent Subscriptions</h3>
            </div>
            <button
              onClick={() => setCurrentView('subscriptions')}
              className="text-xs font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
            >
              <span>View all</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold uppercase text-[10px]">
                  <th className="pb-2">Subscription #</th>
                  <th className="pb-2">Customer</th>
                  <th className="pb-2">Plan</th>
                  <th className="pb-2">Amount</th>
                  <th className="pb-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(tables.recent_subscriptions || []).map((sub) => (
                  <tr
                    key={sub.id}
                    onClick={() => {
                      setSelectedId(sub.subscription_number);
                      setCurrentView('subscription_detail');
                    }}
                    className="hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    <td className="py-2.5 font-bold font-mono text-brand-600">{sub.subscription_number}</td>
                    <td className="py-2.5">
                      <p className="font-medium text-slate-800">{sub.customer_name}</p>
                      <p className="text-[10px] text-slate-400">{sub.customer_company}</p>
                    </td>
                    <td className="py-2.5 text-slate-600">{sub.plan_name}</td>
                    <td className="py-2.5 font-semibold text-slate-900">{formatCurrency(sub.total_amount)}</td>
                    <td className="py-2.5"><StatusBadge status={sub.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Payments */}
        <div className="erp-card p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-600" />
              <h3 className="font-bold text-slate-900 text-sm">Recent Payments</h3>
            </div>
            <button
              onClick={() => setCurrentView('payments')}
              className="text-xs font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
            >
              <span>View all</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold uppercase text-[10px]">
                  <th className="pb-2">Payment Ref</th>
                  <th className="pb-2">Customer</th>
                  <th className="pb-2">Method</th>
                  <th className="pb-2">Amount</th>
                  <th className="pb-2">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(tables.recent_payments || []).map((pm) => (
                  <tr key={pm.id} className="hover:bg-slate-50">
                    <td className="py-2.5 font-bold font-mono text-slate-700">{pm.payment_reference}</td>
                    <td className="py-2.5 text-slate-800 font-medium">{pm.customer_name}</td>
                    <td className="py-2.5 uppercase text-[10px] font-bold text-slate-500">{pm.payment_method}</td>
                    <td className="py-2.5 font-semibold text-emerald-700">{formatCurrency(pm.amount)}</td>
                    <td className="py-2.5 text-slate-500">{formatDate(pm.payment_date)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Audit Log / Recent Activities */}
      <div className="erp-card p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-sm">System Audit Trail & Scheduled Activities</h3>
          </div>
          <span className="text-[10px] font-mono text-slate-400">Odoo mail.tracking.value compliance</span>
        </div>
        <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto">
          {(tables.recent_activities || []).map((act) => (
            <div key={act.id} className="py-2.5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                  act.action === 'CREATE' ? 'bg-blue-50 text-blue-700' :
                  act.action === 'ACTIVATE' ? 'bg-emerald-50 text-emerald-700' :
                  act.action === 'PAYMENT' ? 'bg-emerald-50 text-emerald-700' :
                  act.action === 'GENERATE' ? 'bg-purple-50 text-purple-700' : 'bg-slate-100 text-slate-600'
                }`}>
                  {act.action}
                </span>
                <p className="text-slate-700">
                  <span className="font-semibold text-slate-900">{act.user_name}</span>: {act.description}
                </p>
              </div>
              <span className="text-[10px] text-slate-400 font-mono shrink-0">
                {new Date(act.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
