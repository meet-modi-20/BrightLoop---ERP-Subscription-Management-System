import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';
import { useToast } from './context/ToastContext';
import { api } from './services/api';

// Components
import Sidebar from './components/Sidebar';
import TopNav from './components/TopNav';
import Breadcrumbs from './components/Breadcrumbs';
import OdooArchitectureModal from './components/OdooArchitectureModal';
import Modal from './components/Modal';

// Pages
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Subscriptions from './pages/Subscriptions';
import SubscriptionDetail from './pages/SubscriptionDetail';
import Quotations from './pages/Quotations';
import Invoices from './pages/Invoices';
import InvoiceDetail from './pages/InvoiceDetail';
import Payments from './pages/Payments';
import Products from './pages/Products';
import Plans from './pages/Plans';
import Customers from './pages/Customers';
import Discounts from './pages/Discounts';
import Reports from './pages/Reports';
import CustomerPortal from './pages/CustomerPortal';
import Settings from './pages/Settings';

export default function App() {
  const { user, loading } = useAuth();
  const toast = useToast();

  const [authMode, setAuthMode] = useState('login'); // 'login' | 'register'
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedId, setSelectedId] = useState(null);
  const [odooModalOpen, setOdooModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Quick Payment Modal from Invoices
  const [quickPayInv, setQuickPayInv] = useState(null);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('upi');
  const [payNotes, setPayNotes] = useState('');
  const [paying, setPaying] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white text-sm font-semibold">
        <div className="flex items-center gap-3">
          <div className="w-5 h-5 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
          <span>Initializing Brightloop ERP...</span>
        </div>
      </div>
    );
  }

  // Auth gate
  if (!user) {
    return authMode === 'login' ? (
      <Login onSwitchToRegister={() => setAuthMode('register')} />
    ) : (
      <Register onSwitchToLogin={() => setAuthMode('login')} />
    );
  }

  const role = user.role?.toUpperCase() || 'ADMIN';
  const effectiveView = role === 'CUSTOMER' && (currentView === 'dashboard' || currentView === 'settings')
    ? 'portal'
    : currentView;

  // Recurring Billing Action Trigger
  const handleTriggerBilling = async () => {
    try {
      const res = await api.generateDueInvoices();
      if (res.success) {
        toast.success(res.message);
      }
    } catch (err) {
      toast.error(err.message || 'Billing execution failed');
    }
  };

  const openRecordPaymentModal = (invoice) => {
    setQuickPayInv(invoice);
    const bal = Math.max(0, invoice.grand_total - invoice.amount_paid);
    setPayAmount(String(bal));
    setPayMethod('upi');
    setPayNotes('');
  };

  const handleQuickPaymentSubmit = async (e) => {
    e.preventDefault();
    if (!quickPayInv) return;

    setPaying(true);
    try {
      const res = await api.recordPayment({
        invoice_id: quickPayInv.id,
        amount: parseFloat(payAmount),
        payment_method: payMethod,
        notes: payNotes,
        status: 'completed'
      });
      if (res.success) {
        toast.success(res.message);
        setQuickPayInv(null);
      }
    } catch (err) {
      toast.error(err.message || 'Payment recording failed');
    } finally {
      setPaying(false);
    }
  };

  // Breadcrumbs items calculation
  const getBreadcrumbs = () => {
    const list = [];
    if (effectiveView === 'dashboard') {
      list.push({ label: 'Analytics Dashboard' });
    } else if (effectiveView === 'portal') {
      list.push({ label: 'Customer Portal' });
    } else if (effectiveView === 'subscriptions') {
      list.push({ label: 'Subscriptions' });
    } else if (effectiveView === 'subscription_detail') {
      list.push({ label: 'Subscriptions', onClick: () => setCurrentView('subscriptions') });
      list.push({ label: selectedId || 'Detail' });
    } else if (effectiveView === 'invoices') {
      list.push({ label: 'Invoices' });
    } else if (effectiveView === 'invoice_detail') {
      list.push({ label: 'Invoices', onClick: () => setCurrentView('invoices') });
      list.push({ label: selectedId || 'Tax Invoice' });
    } else if (effectiveView === 'quotations') {
      list.push({ label: 'Quotations' });
    } else if (effectiveView === 'payments') {
      list.push({ label: 'Payments' });
    } else if (effectiveView === 'products') {
      list.push({ label: 'Products & Variants' });
    } else if (effectiveView === 'plans') {
      list.push({ label: 'Subscription Plans' });
    } else if (effectiveView === 'customers') {
      list.push({ label: 'Customers' });
    } else if (effectiveView === 'discounts') {
      list.push({ label: 'Discount Rules' });
    } else if (effectiveView === 'reports') {
      list.push({ label: 'Reports & Analytics' });
    } else if (effectiveView === 'settings') {
      list.push({ label: 'System Settings' });
    }
    return list;
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
      {/* Sidebar Navigation */}
      <Sidebar
        currentView={effectiveView}
        setCurrentView={(view) => {
          setCurrentView(view);
          setSelectedId(null);
          setMobileMenuOpen(false);
        }}
        openOdooModal={() => setOdooModalOpen(true)}
      />

      {/* Main App Workspace */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header Navigation */}
        <TopNav
          openOdooModal={() => setOdooModalOpen(true)}
          onTriggerBilling={handleTriggerBilling}
          setCurrentView={setCurrentView}
          onSearch={(query) => {
            if (query && !['subscriptions', 'invoices', 'customers'].includes(effectiveView)) {
              setCurrentView('subscriptions');
            }
          }}
        />

        {/* Scrollable View Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto space-y-4">
            {/* Breadcrumb row */}
            <Breadcrumbs
              items={getBreadcrumbs()}
              onNavigate={(v) => {
                setCurrentView(v);
                setSelectedId(null);
              }}
            />

            {/* View Router */}
            {effectiveView === 'dashboard' && (
              <Dashboard
                setCurrentView={setCurrentView}
                setSelectedId={setSelectedId}
              />
            )}

            {effectiveView === 'portal' && (
              <CustomerPortal
                setCurrentView={setCurrentView}
                setSelectedId={setSelectedId}
              />
            )}

            {effectiveView === 'subscriptions' && (
              <Subscriptions
                setCurrentView={setCurrentView}
                setSelectedId={setSelectedId}
              />
            )}

            {effectiveView === 'subscription_detail' && (
              <SubscriptionDetail
                id={selectedId}
                onBack={() => setCurrentView('subscriptions')}
                setCurrentView={setCurrentView}
                setSelectedId={setSelectedId}
              />
            )}

            {effectiveView === 'quotations' && (
              <Quotations
                setCurrentView={setCurrentView}
                setSelectedId={setSelectedId}
              />
            )}

            {effectiveView === 'invoices' && (
              <Invoices
                setCurrentView={setCurrentView}
                setSelectedId={setSelectedId}
                openRecordPaymentModal={openRecordPaymentModal}
              />
            )}

            {effectiveView === 'invoice_detail' && (
              <InvoiceDetail
                id={selectedId}
                onBack={() => setCurrentView('invoices')}
                onRecordPaymentSuccess={() => {}}
              />
            )}

            {effectiveView === 'payments' && (
              <Payments
                setCurrentView={setCurrentView}
                setSelectedId={setSelectedId}
              />
            )}

            {effectiveView === 'products' && <Products />}

            {effectiveView === 'plans' && <Plans />}

            {effectiveView === 'customers' && (
              <Customers
                setCurrentView={setCurrentView}
                setSelectedId={setSelectedId}
              />
            )}

            {effectiveView === 'discounts' && <Discounts />}

            {effectiveView === 'reports' && <Reports />}

            {effectiveView === 'settings' && (
              <Settings openOdooModal={() => setOdooModalOpen(true)} />
            )}
          </div>
        </main>
      </div>

      {/* Odoo Architecture Modal */}
      <OdooArchitectureModal
        isOpen={odooModalOpen}
        onClose={() => setOdooModalOpen(false)}
      />

      {/* Quick Pay Modal (Triggerable from Invoice list) */}
      {quickPayInv && (
        <Modal
          isOpen={Boolean(quickPayInv)}
          onClose={() => setQuickPayInv(null)}
          title="Record Invoice Settlement"
          subtitle={`Match payment against invoice ${quickPayInv.invoice_number}`}
          maxWidth="max-w-md"
        >
          <form onSubmit={handleQuickPaymentSubmit} className="space-y-4">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex justify-between">
              <div>
                <p className="text-slate-400 text-[10px] uppercase font-bold">Outstanding Balance</p>
                <p className="text-base font-bold text-slate-900 mt-0.5">
                  ₹{Math.max(0, quickPayInv.grand_total - quickPayInv.amount_paid).toLocaleString('en-IN')}
                </p>
              </div>
              <div className="text-right">
                <p className="text-slate-400 text-[10px] uppercase font-bold">Customer</p>
                <p className="font-semibold text-slate-800 mt-0.5">{quickPayInv.customer_name}</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Amount to Record (₹)</label>
              <input
                type="number"
                step="0.01"
                min="1"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Payment Method</label>
              <select
                value={payMethod}
                onChange={(e) => setPayMethod(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              >
                <option value="upi">UPI (GPay / PhonePe / Paytm)</option>
                <option value="bank_transfer">Bank Transfer (NEFT / RTGS)</option>
                <option value="card">Credit / Debit Card</option>
                <option value="online">Online Payment</option>
                <option value="cash">Cash / Cheque</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Reference / Txn Notes</label>
              <input
                type="text"
                value={payNotes}
                onChange={(e) => setPayNotes(e.target.value)}
                placeholder="UTR #AXIS99321 or Cheque #"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setQuickPayInv(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={paying}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20"
              >
                {paying ? 'Processing...' : 'Confirm Remittance'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
