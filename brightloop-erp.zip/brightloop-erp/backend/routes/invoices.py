import datetime
from flask import Blueprint, request, jsonify
from database import get_db
from services.billing_engine import generate_due_invoices, get_due_subscriptions_preview, get_next_invoice_number

invoices_bp = Blueprint('invoices', __name__)

@invoices_bp.route('', methods=['GET'])
def list_invoices():
    status = request.args.get('status')
    customer_id = request.args.get('customer_id')
    search = request.args.get('search', '').strip()

    query = """
        SELECT inv.*, c.name as customer_name, c.company as customer_company, c.email as customer_email,
               s.subscription_number
        FROM invoices inv
        JOIN customers c ON inv.customer_id = c.id
        LEFT JOIN subscriptions s ON inv.subscription_id = s.id
        WHERE 1=1
    """
    params = []

    if status and status != 'ALL':
        query += " AND inv.payment_status = ?"
        params.append(status.lower())

    if customer_id:
        query += " AND inv.customer_id = ?"
        params.append(customer_id)

    if search:
        query += " AND (inv.invoice_number LIKE ? OR c.name LIKE ? OR c.company LIKE ? OR s.subscription_number LIKE ?)"
        wild = f"%{search}%"
        params.extend([wild, wild, wild, wild])

    query += " ORDER BY inv.id DESC"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = [dict(r) for r in cursor.fetchall()]

        # Summary statistics
        cursor.execute("""
            SELECT 
                COUNT(*) as total_count,
                COALESCE(SUM(grand_total), 0.0) as total_amount,
                COALESCE(SUM(amount_paid), 0.0) as total_paid,
                COALESCE(SUM(CASE WHEN payment_status = 'paid' THEN 1 ELSE 0 END), 0) as paid_count,
                COALESCE(SUM(CASE WHEN payment_status = 'overdue' THEN 1 ELSE 0 END), 0) as overdue_count
            FROM invoices
        """)
        summary = dict(cursor.fetchone())

        return jsonify({
            "success": True,
            "count": len(rows),
            "summary": summary,
            "invoices": rows
        })

@invoices_bp.route('/<identifier>', methods=['GET'])
def get_invoice_detail(identifier):
    with get_db() as conn:
        cursor = conn.cursor()

        if identifier.isdigit():
            cursor.execute("SELECT inv.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone, c.company as customer_company, c.address as customer_address, c.city as customer_city, c.state as customer_state, c.country as customer_country, c.postal_code as customer_zip, c.tax_id as customer_tax_id, s.subscription_number, s.billing_frequency FROM invoices inv JOIN customers c ON inv.customer_id = c.id LEFT JOIN subscriptions s ON inv.subscription_id = s.id WHERE inv.id = ?", (identifier,))
        else:
            cursor.execute("SELECT inv.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone, c.company as customer_company, c.address as customer_address, c.city as customer_city, c.state as customer_state, c.country as customer_country, c.postal_code as customer_zip, c.tax_id as customer_tax_id, s.subscription_number, s.billing_frequency FROM invoices inv JOIN customers c ON inv.customer_id = c.id LEFT JOIN subscriptions s ON inv.subscription_id = s.id WHERE inv.invoice_number = ?", (identifier,))

        inv = cursor.fetchone()
        if not inv:
            return jsonify({"success": False, "error": "Invoice not found"}), 404

        inv_data = dict(inv)
        inv_id = inv['id']

        # Get lines
        cursor.execute("""
            SELECT il.*, pr.name as product_name
            FROM invoice_lines il
            LEFT JOIN products pr ON il.product_id = pr.id
            WHERE il.invoice_id = ?
        """, (inv_id,))
        inv_data['lines'] = [dict(l) for l in cursor.fetchall()]

        # Get payments
        cursor.execute("""
            SELECT * FROM payments WHERE invoice_id = ? ORDER BY id DESC
        """, (inv_id,))
        inv_data['payments'] = [dict(p) for p in cursor.fetchall()]

        # Calculate remaining balance
        inv_data['balance_due'] = max(0.0, round(inv_data['grand_total'] - inv_data['amount_paid'], 2))

        return jsonify({"success": True, "invoice": inv_data})

@invoices_bp.route('/generate-due', methods=['POST'])
def trigger_generate_due_invoices():
    """
    Core Action: GENERATE DUE INVOICES
    Batch engine identifies due subscriptions and generates invoices.
    """
    data = request.get_json() or {}
    target_date = data.get('target_date', datetime.date.today().strftime("%Y-%m-%d"))
    force = data.get('force', False)

    try:
        results = generate_due_invoices(target_date=target_date, force=force)
        return jsonify({
            "success": True,
            "message": f"Successfully evaluated billing schedule. Generated {len(results)} invoice(s).",
            "count": len(results),
            "generated_invoices": results
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@invoices_bp.route('/preview-due', methods=['GET'])
def preview_due_invoices_route():
    target_date = request.args.get('target_date', datetime.date.today().strftime("%Y-%m-%d"))
    subs = get_due_subscriptions_preview(target_date)
    return jsonify({
        "success": True,
        "count": len(subs),
        "due_subscriptions": subs
    })

@invoices_bp.route('/<int:inv_id>/confirm', methods=['POST'])
def confirm_invoice(inv_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM invoices WHERE id = ?", (inv_id,))
        inv = cursor.fetchone()
        if not inv:
            return jsonify({"success": False, "error": "Invoice not found"}), 404

        cursor.execute("UPDATE invoices SET payment_status = 'confirmed' WHERE id = ?", (inv_id,))
        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CONFIRM', 'invoice', ?, 'Draft invoice confirmed.')
        """, (inv['invoice_number'],))

        return jsonify({"success": True, "message": "Invoice confirmed."})

@invoices_bp.route('/<int:inv_id>/cancel', methods=['POST'])
def cancel_invoice(inv_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM invoices WHERE id = ?", (inv_id,))
        inv = cursor.fetchone()
        if not inv:
            return jsonify({"success": False, "error": "Invoice not found"}), 404

        cursor.execute("UPDATE invoices SET payment_status = 'cancelled' WHERE id = ?", (inv_id,))
        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CANCEL', 'invoice', ?, 'Invoice marked as cancelled.')
        """, (inv['invoice_number'],))

        return jsonify({"success": True, "message": "Invoice cancelled."})

@invoices_bp.route('/<int:inv_id>/send', methods=['POST'])
def send_invoice(inv_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT inv.*, c.email as customer_email, c.name as customer_name FROM invoices inv JOIN customers c ON inv.customer_id = c.id WHERE inv.id = ?", (inv_id,))
        inv = cursor.fetchone()
        if not inv:
            return jsonify({"success": False, "error": "Invoice not found"}), 404

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'SEND', 'invoice', ?, ?)
        """, (inv['invoice_number'], f"Invoice dispatched to {inv['customer_name']} ({inv['customer_email']})."))

        return jsonify({"success": True, "message": f"Invoice sent successfully to {inv['customer_email']}."})
