import unittest
import json
import os
import datetime
from app import create_app
from seed_data import seed_all

class BrightloopWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Reset and seed pristine database
        seed_all()
        cls.app = create_app()
        cls.client = cls.app.test_client()

    def test_01_authentication_roles_and_validation(self):
        # 1. Admin login
        res = self.client.post('/api/auth/login', json={
            "email": "admin@brightloop.com",
            "password": "Admin@123!"
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['user']['role'], 'admin')

        # 2. Staff login
        res = self.client.post('/api/auth/login', json={
            "email": "staff@brightloop.com",
            "password": "Staff@123!"
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['user']['role'], 'staff')

        # 3. Customer login
        res = self.client.post('/api/auth/login', json={
            "email": "customer@brightloop.com",
            "password": "Customer@123!"
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['user']['role'], 'customer')
        self.assertIsNotNone(data['user']['customer_id'])

        # 4. Weak password validation
        res = self.client.post('/api/auth/register', json={
            "full_name": "Test User",
            "email": "weak@example.com",
            "password": "weak",
            "confirm_password": "weak"
        })
        self.assertEqual(res.status_code, 400)
        self.assertIn("at least 9 characters", res.get_json()['error'])

        # 5. Compliant registration
        res = self.client.post('/api/auth/register', json={
            "full_name": "Divya Deshmukh",
            "email": "divya@chesscorp.com",
            "password": "SecurePass@2026",
            "confirm_password": "SecurePass@2026",
            "company": "ChessCorp Analytics"
        })
        self.assertEqual(res.status_code, 201)
        self.assertEqual(res.get_json()['user']['role'], 'customer')

    def test_02_dashboard_metrics(self):
        res = self.client.get('/api/dashboard/stats?range=30d')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        metrics = data['metrics']
        self.assertGreater(metrics['total_customers'], 0)
        self.assertGreater(metrics['active_subscriptions'], 0)
        self.assertGreater(metrics['mrr'], 0)
        self.assertGreater(metrics['arr'], 0)
        self.assertEqual(round(metrics['arr'], 2), round(metrics['mrr'] * 12, 2))
        self.assertIn('monthly_revenue', data['charts'])
        self.assertIn('subscription_growth', data['charts'])
        self.assertIn('revenue_by_plan', data['charts'])

    def test_03_products_and_plans(self):
        # Create product with variant and additional price
        res = self.client.post('/api/products', json={
            "name": "Cloud Security Shield",
            "product_type": "subscription",
            "sales_price": 2000.0,
            "cost_price": 400.0,
            "description": "Zero-trust network security firewall for subscriptions",
            "variants": [
                {
                    "variant_name": "Odoo Brand Security",
                    "brand": "Odoo Brand",
                    "additional_price": 560.0
                }
            ]
        })
        self.assertEqual(res.status_code, 201)
        prod_id = res.get_json()['product_id']

        # Verify variant calculation
        prod_res = self.client.get(f'/api/products/{prod_id}')
        prod_data = prod_res.get_json()['product']
        self.assertEqual(len(prod_data['variants']), 1)
        self.assertEqual(prod_data['variants'][0]['final_price'], 2560.0)

        # Create plan linked to this product
        plan_res = self.client.post('/api/plans', json={
            "plan_name": "Security Pro Monthly",
            "linked_product_id": prod_id,
            "description": "Monthly security monitoring",
            "price": 2560.0,
            "billing_frequency": "monthly",
            "min_quantity": 1,
            "allow_pause": True,
            "allow_renewal": True
        })
        self.assertEqual(plan_res.status_code, 201)

    def test_04_quotation_to_subscription_flow(self):
        # 1. Create quotation
        res = self.client.post('/api/quotations', json={
            "customer_id": 1,
            "plan_id": 1,
            "template_name": "Standard SaaS Agreement",
            "payment_terms": "Net 15 Days",
            "notes": "Pre-negotiated hackathon deal"
        })
        self.assertEqual(res.status_code, 201)
        q_id = res.get_json()['quotation_id']

        # 2. Confirm quotation -> generates subscription
        conf_res = self.client.post(f'/api/quotations/{q_id}/confirm')
        self.assertEqual(conf_res.status_code, 200)
        sub_id = conf_res.get_json()['subscription_id']
        sub_num = conf_res.get_json()['subscription_number']

        # 3. Verify subscription was created in CONFIRMED status
        sub_res = self.client.get(f'/api/subscriptions/{sub_id}')
        sub_data = sub_res.get_json()['subscription']
        self.assertEqual(sub_data['status'], 'CONFIRMED')

        # 4. Activate subscription
        act_res = self.client.post(f'/api/subscriptions/{sub_id}/activate')
        self.assertEqual(act_res.status_code, 200)

        # 5. Verify active status and calculated next_billing_date
        sub_res2 = self.client.get(f'/api/subscriptions/{sub_id}')
        sub_data2 = sub_res2.get_json()['subscription']
        self.assertEqual(sub_data2['status'], 'ACTIVE')
        self.assertIsNotNone(sub_data2['next_billing_date'])

        # 6. Pause subscription
        pause_res = self.client.post(f'/api/subscriptions/{sub_id}/pause', json={"reason": "Customer migration"})
        self.assertEqual(pause_res.status_code, 200)
        sub_paused = self.client.get(f'/api/subscriptions/{sub_id}').get_json()['subscription']
        self.assertEqual(sub_paused['status'], 'PAUSED')

        # 7. Resume subscription
        resume_res = self.client.post(f'/api/subscriptions/{sub_id}/resume')
        self.assertEqual(resume_res.status_code, 200)
        sub_resumed = self.client.get(f'/api/subscriptions/{sub_id}').get_json()['subscription']
        self.assertEqual(sub_resumed['status'], 'ACTIVE')

    def test_05_recurring_billing_and_payment_flow(self):
        # 1. Trigger generate due invoices for today
        res = self.client.post('/api/invoices/generate-due', json={"target_date": "2026-11-01"})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])

        # 2. Prevent duplicate invoices
        dup_res = self.client.post('/api/invoices/generate-due', json={"target_date": "2026-11-01"})
        self.assertEqual(dup_res.get_json()['count'], 0)

        # 3. Fetch an invoice to test partial payment and full settlement
        inv_list = self.client.get('/api/invoices?status=confirmed').get_json()['invoices']
        self.assertGreater(len(inv_list), 0)
        target_inv = inv_list[0]
        inv_id = target_inv['id']
        total = target_inv['grand_total']

        # Partial payment: half of grand total
        half_amt = round(total / 2.0, 2)
        p_res = self.client.post('/api/payments', json={
            "invoice_id": inv_id,
            "amount": half_amt,
            "payment_method": "upi",
            "notes": "Partial instalment 1"
        })
        self.assertEqual(p_res.status_code, 201)

        # Check balance
        updated_inv = self.client.get(f'/api/invoices/{inv_id}').get_json()['invoice']
        self.assertEqual(round(updated_inv['amount_paid'], 2), half_amt)
        self.assertEqual(updated_inv['payment_status'], 'confirmed')

        # Pay remaining balance
        rem_bal = updated_inv['balance_due']
        p_res2 = self.client.post('/api/payments', json={
            "invoice_id": inv_id,
            "amount": rem_bal,
            "payment_method": "bank_transfer",
            "notes": "Final balance settlement"
        })
        self.assertEqual(p_res2.status_code, 201)

        # Check invoice is now PAID
        final_inv = self.client.get(f'/api/invoices/{inv_id}').get_json()['invoice']
        self.assertEqual(final_inv['payment_status'], 'paid')
        self.assertEqual(final_inv['balance_due'], 0.0)

    def test_06_odoo_architecture_blueprint(self):
        res = self.client.get('/api/odoo/blueprint')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        models = data['blueprint']['models']
        self.assertIn('Customers', models)
        self.assertEqual(models['Customers']['odoo_model'], 'res.partner')
        self.assertEqual(models['Subscriptions']['odoo_model'], 'sale.order (is_subscription=True)')
        self.assertEqual(models['Invoices']['odoo_model'], 'account.move (move_type=\'out_invoice\')')
        self.assertEqual(models['Scheduled Billing Action']['odoo_model'], 'ir.cron')

if __name__ == '__main__':
    unittest.main()
