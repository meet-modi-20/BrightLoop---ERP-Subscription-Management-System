import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Save, 
  Database, 
  RefreshCw, 
  Check, 
  ShieldCheck, 
  Sparkles,
  Link2
} from 'lucide-react';
import { useToast } from '../context/ToastContext';

export default function Settings({ openOdooModal }) {
  const toast = useToast();
  const [saving, setSaving] = useState(false);

  const [settings, setSettings] = useState({
    company_name: 'Brightloop ERP Inc.',
    currency: 'INR',
    currency_symbol: '₹',
    default_tax_rate: '18.0',
    billing_grace_period_days: '7',
    auto_generate_invoices: true,
    odoo_api_url: 'https://brightloop.odoo.com/jsonrpc',
    odoo_db: 'brightloop_production',
    odoo_sync_enabled: true
  });

  const handleSave = (e) => {
    e.preventDefault();
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      toast.success('System settings updated successfully.');
    }, 600);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <SettingsIcon className="w-6 h-6 text-brand-600" />
            <span>System Configurations & ERP Parameters</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Admin global variables, GST tax schedules, and external Odoo 17/18 JSON-RPC connectors
          </p>
        </div>

        <button
          onClick={openOdooModal}
          className="flex items-center gap-2 px-3.5 py-2 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-xl text-xs font-bold transition-all shadow-2xs"
        >
          <Sparkles className="w-4 h-4 text-purple-600" />
          <span>Inspect Odoo ORM Schema</span>
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Company & Currency Settings */}
        <div className="erp-card p-6 space-y-4">
          <h3 className="font-bold text-slate-900 text-sm border-b border-slate-100 pb-2">
            Company Profile & Financial Defaults
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Company Legal Name</label>
              <input
                type="text"
                value={settings.company_name}
                onChange={(e) => setSettings({ ...settings, company_name: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Primary Currency</label>
              <input
                type="text"
                value={`${settings.currency} (${settings.currency_symbol})`}
                disabled
                className="w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs font-medium text-slate-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Standard GST Tax Rate (%)</label>
              <input
                type="number"
                value={settings.default_tax_rate}
                onChange={(e) => setSettings({ ...settings, default_tax_rate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Configured as 9% CGST + 9% SGST</span>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Payment Grace Period (Days)</label>
              <input
                type="number"
                value={settings.billing_grace_period_days}
                onChange={(e) => setSettings({ ...settings, billing_grace_period_days: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              />
            </div>
          </div>
        </div>

        {/* Automated Recurring Billing Rules */}
        <div className="erp-card p-6 space-y-4">
          <h3 className="font-bold text-slate-900 text-sm border-b border-slate-100 pb-2">
            Recurring Billing Scheduler Engine (ir.cron equivalent)
          </h3>
          <div className="space-y-3">
            <label className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200/80 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.auto_generate_invoices}
                onChange={(e) => setSettings({ ...settings, auto_generate_invoices: e.target.checked })}
                className="mt-0.5 rounded text-brand-600 focus:ring-brand-500"
              />
              <div className="text-xs">
                <span className="font-bold text-slate-900">Enable Automated Recurring Engine</span>
                <p className="text-slate-500 mt-0.5 leading-relaxed">
                  When active, subscriptions that reach their Next Billing Date are automatically invoiced with applicable discounts and scheduled for the next interval.
                </p>
              </div>
            </label>
          </div>
        </div>

        {/* Odoo Connector Setup */}
        <div className="erp-card p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div className="flex items-center gap-2">
              <Link2 className="w-4 h-4 text-purple-600" />
              <h3 className="font-bold text-slate-900 text-sm">Odoo JSON-RPC Integration Hook</h3>
            </div>
            <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
              Odoo 17 & 18 Ready
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Odoo Server Endpoint</label>
              <input
                type="text"
                value={settings.odoo_api_url}
                onChange={(e) => setSettings({ ...settings, odoo_api_url: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Target Odoo Database</label>
              <input
                type="text"
                value={settings.odoo_db}
                onChange={(e) => setSettings({ ...settings, odoo_db: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-800"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/25 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving Settings...' : 'Save Configuration'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
