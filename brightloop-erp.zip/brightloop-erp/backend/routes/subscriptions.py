import datetime
from flask import Blueprint, request, jsonify
from database import get_db
from services.billing_engine import calculate_next_billing_date, get_next_invoice_number

subscriptions_bp = Blueprint('subscriptions', __name__)

def generate_sub_number(cursor):
    cursor.execute("SELECT subscription_number FROM subscriptions ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    year = datetime.date.today().year
    if row and row['subscription_number']:
        try:
            parts = row['subscription_number'].split('-')
            seq = int(parts[-1])
            return f"SUB-{year}-{seq + 1:04d}"
        except Exception:
            pass
    return f"SUB-{year}-0001"

@subscriptions_bp.route('', methods=['GET'])
def list_subscriptions():
    status = request.args.get('status')
    customer_id = request.args.get('customer_id')
    search = request.args.get('search', '').strip()

    query = """
        SELECT s.*, c.name as customer_name, c.company as customer_company, c.email as customer_email,
               p.plan_name, p.billing_frequency as plan_frequency, p.price as plan_price
        FROM subscriptions s
        JOIN customers c ON s.customer_id = c.id
        JOIN plans p ON s.plan_id = p.id
        WHERE 1=1
    """
    params = []

    if status and status != 'ALL':
        query += " AND s.status = ?"
        params.append(status.upper())

    if customer_id:
        query += " AND s.customer_id = ?"
        params.append(customer_id)

    if search:
        query += " AND (s.subscription_number LIKE ? OR c.name LIKE ? OR c.company LIKE ? OR p.plan_name LIKE ?)"
        wild = f"%{search}%"
        params.extend([wild, wild, wild, wild])

    query += " ORDER BY s.id DESC"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = [dict(r) for r in cursor.fetchall()]

        return jsonify({
            "success": True,
            "count": len(rows),
            "subscriptions": rows
        })

@subscriptions_bp.route('/<identifier>', methods=['GET'])
def get_subscription_detail(identifier):
    with get_db() as conn:
        cursor = conn.cursor()
        
        # Check by id or number
        if identifier.isdigit():
            cursor.execute("SELECT s.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone, c.company as customer_company, c.address as customer_address, c.tax_id as customer_tax_id, p.plan_name, p.billing_frequency as plan_freq, p.description as plan_desc, p.allow_pause, p.allow_renewal, p.allow_early_closure FROM subscriptions s JOIN customers c ON s.customer_id = c.id JOIN plans p ON s.plan_id = p.id WHERE s.id = ?", (identifier,))
        else:
            cursor.execute("SELECT s.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone, c.company as customer_company, c.address as customer_address, c.tax_id as customer_tax_id, p.plan_name, p.billing_frequency as plan_freq, p.description as plan_desc, p.allow_pause, p.allow_renewal, p.allow_early_closure FROM subscriptions s JOIN customers c ON s.customer_id = c.id JOIN plans p ON s.plan_id = p.id WHERE s.subscription_number = ?", (identifier,))
        
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        sub_data = dict(sub)
        sub_id = sub['id']

        # Get lines
        cursor.execute("""
            SELECT sl.*, pr.name as product_name, pv.variant_name, pv.brand
            FROM subscription_lines sl
            JOIN products pr ON sl.product_id = pr.id
            LEFT JOIN product_variants pv ON sl.variant_id = pv.id
            WHERE sl.subscription_id = ?
        """, (sub_id,))
        sub_data['lines'] = [dict(l) for l in cursor.fetchall()]

        # Get related invoices
        cursor.execute("""
            SELECT id, invoice_number, invoice_date, due_date, grand_total, amount_paid, payment_status
            FROM invoices
            WHERE subscription_id = ?
            ORDER BY id DESC
        """, (sub_id,))
        sub_data['invoices'] = [dict(i) for i in cursor.fetchall()]

        # Get payments related to those invoices
        cursor.execute("""
            SELECT p.*, inv.invoice_number
            FROM payments p
            JOIN invoices inv ON p.invoice_id = inv.id
            WHERE inv.subscription_id = ?
            ORDER BY p.id DESC
        """, (sub_id,))
        sub_data['payments'] = [dict(pm) for pm in cursor.fetchall()]

        # Get activity logs
        cursor.execute("""
            SELECT id, user_name, action, description, created_at
            FROM activity_logs
            WHERE entity_type = 'subscription' AND entity_id = ?
            ORDER BY id DESC
        """, (sub['subscription_number'],))
        sub_data['timeline'] = [dict(t) for t in cursor.fetchall()]

        return jsonify({"success": True, "subscription": sub_data})

@subscriptions_bp.route('', methods=['POST'])
def create_subscription():
    data = request.get_json() or {}
    customer_id = data.get('customer_id')
    plan_id = data.get('plan_id')
    start_date = data.get('start_date') or datetime.date.today().strftime("%Y-%m-%d")
    payment_terms = data.get('payment_terms', 'Net 15 Days')
    notes = data.get('notes', '')
    status = data.get('status', 'DRAFT')

    if not customer_id or not plan_id:
        return jsonify({"success": False, "error": "Customer and Plan are required."}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        
        # Fetch plan info
        cursor.execute("SELECT * FROM plans WHERE id = ?", (plan_id,))
        plan = cursor.fetchone()
        if not plan:
            return jsonify({"success": False, "error": "Plan not found"}), 404

        freq = plan['billing_frequency']
        sub_num = generate_sub_number(cursor)

        start_dt = datetime.datetime.strptime(start_date, "%Y-%m-%d").date()
        next_billing = calculate_next_billing_date(start_dt, freq).strftime("%Y-%m-%d")
        expiry_dt = (start_dt + datetime.timedelta(days=365)).strftime("%Y-%m-%d")

        unit_price = float(plan['price'])
        qty = int(data.get('quantity', 1))
        subtotal = round(unit_price * qty, 2)
        tax_amount = round(subtotal * 0.18, 2)
        total_amount = round(subtotal + tax_amount, 2)

        cursor.execute("""
            INSERT INTO subscriptions (
                subscription_number, customer_id, plan_id, start_date, expiry_date,
                next_billing_date, payment_terms, billing_frequency, subtotal,
                tax_amount, discount_amount, total_amount, status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0.0, ?, ?, ?)
        """, (
            sub_num, customer_id, plan_id, start_date, expiry_dt,
            next_billing, payment_terms, freq, subtotal,
            tax_amount, total_amount, status, notes
        ))
        sub_id = cursor.lastrowid

        # Insert line item
        cursor.execute("""
            INSERT INTO subscription_lines (
                subscription_id, product_id, description, quantity, unit_price, tax_percent, total_amount
            ) VALUES (?, ?, ?, ?, ?, 18.0, ?)
        """, (sub_id, plan['linked_product_id'], f"Base Plan: {plan['plan_name']}", qty, unit_price, total_amount))

        # Log
        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CREATE', 'subscription', ?, ?)
        """, (sub_num, f"Subscription {sub_num} created in {status} state for ₹{total_amount:,.2f}."))

        return jsonify({
            "success": True,
            "message": f"Subscription {sub_num} created successfully.",
            "subscription_id": sub_id,
            "subscription_number": sub_num
        }), 201

# --- LIFECYCLE STATE TRANSITIONS ---

@subscriptions_bp.route('/<int:sub_id>/convert-quotation', methods=['POST'])
def convert_to_quotation(sub_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM subscriptions WHERE id = ?", (sub_id,))
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        cursor.execute("UPDATE subscriptions SET status = 'QUOTATION', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (sub_id,))
        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'QUOTATION', 'subscription', ?, 'Draft converted to Quotation.')
        """, (sub['subscription_number'],))

        return jsonify({"success": True, "message": "Subscription converted to Quotation."})

@subscriptions_bp.route('/<int:sub_id>/confirm', methods=['POST'])
def confirm_subscription(sub_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM subscriptions WHERE id = ?", (sub_id,))
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        cursor.execute("UPDATE subscriptions SET status = 'CONFIRMED', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (sub_id,))
        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CONFIRM', 'subscription', ?, 'Quotation confirmed.')
        """, (sub['subscription_number'],))

        return jsonify({"success": True, "message": "Subscription confirmed."})

@subscriptions_bp.route('/<int:sub_id>/activate', methods=['POST'])
def activate_subscription(sub_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT s.*, p.billing_frequency as plan_freq FROM subscriptions s JOIN plans p ON s.plan_id = p.id WHERE s.id = ?", (sub_id,))
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        today = datetime.date.today()
        freq = sub['billing_frequency'] or sub['plan_freq'] or 'monthly'
        next_billing = calculate_next_billing_date(today, freq).strftime("%Y-%m-%d")

        cursor.execute("""
            UPDATE subscriptions
            SET status = 'ACTIVE', start_date = ?, next_billing_date = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (today.strftime("%Y-%m-%d"), next_billing, sub_id))

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'ACTIVATE', 'subscription', ?, ?)
        """, (sub['subscription_number'], f"Subscription activated! Next billing scheduled for {next_billing}."))

        # Notification
        cursor.execute("SELECT user_id FROM customers WHERE id = ?", (sub['customer_id'],))
        c_user = cursor.fetchone()
        if c_user and c_user['user_id']:
            cursor.execute("""
                INSERT INTO notifications (user_id, title, message, category, link)
                VALUES (?, 'Subscription Activated', ?, 'subscription', ?)
            """, (c_user['user_id'], f"Your subscription {sub['subscription_number']} is now ACTIVE.", f"/subscriptions/{sub['subscription_number']}"))

        return jsonify({"success": True, "message": f"Subscription activated. Next billing: {next_billing}"})

@subscriptions_bp.route('/<int:sub_id>/pause', methods=['POST'])
def pause_subscription(sub_id):
    data = request.get_json() or {}
    reason = data.get('reason', 'Customer requested temporary hold')

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT subscription_number FROM subscriptions WHERE id = ?", (sub_id,))
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        cursor.execute("UPDATE subscriptions SET status = 'PAUSED', notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (reason, sub_id))
        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'PAUSE', 'subscription', ?, ?)
        """, (sub['subscription_number'], f"Subscription paused. Reason: {reason}"))

        return jsonify({"success": True, "message": "Subscription paused."})

@subscriptions_bp.route('/<int:sub_id>/resume', methods=['POST'])
def resume_subscription(sub_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT s.*, p.billing_frequency as plan_freq FROM subscriptions s JOIN plans p ON s.plan_id = p.id WHERE s.id = ?", (sub_id,))
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        today = datetime.date.today()
        freq = sub['billing_frequency'] or sub['plan_freq'] or 'monthly'
        next_billing = calculate_next_billing_date(today, freq).strftime("%Y-%m-%d")

        cursor.execute("""
            UPDATE subscriptions
            SET status = 'ACTIVE', next_billing_date = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (next_billing, sub_id))

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'RESUME', 'subscription', ?, ?)
        """, (sub['subscription_number'], f"Subscription resumed. Next billing set to {next_billing}."))

        return jsonify({"success": True, "message": "Subscription resumed to ACTIVE state."})

@subscriptions_bp.route('/<int:sub_id>/renew', methods=['POST'])
def renew_subscription(sub_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM subscriptions WHERE id = ?", (sub_id,))
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        today = datetime.date.today()
        current_exp = sub['expiry_date']
        if current_exp:
            exp_date = datetime.datetime.strptime(current_exp, "%Y-%m-%d").date()
            new_exp = max(exp_date, today) + datetime.timedelta(days=365)
        else:
            new_exp = today + datetime.timedelta(days=365)

        cursor.execute("""
            UPDATE subscriptions
            SET status = 'ACTIVE', expiry_date = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (new_exp.strftime("%Y-%m-%d"), sub_id))

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'RENEW', 'subscription', ?, ?)
        """, (sub['subscription_number'], f"Subscription renewed until {new_exp.strftime('%Y-%m-%d')}."))

        return jsonify({"success": True, "message": f"Subscription renewed until {new_exp.strftime('%Y-%m-%d')}."})

@subscriptions_bp.route('/<int:sub_id>/close', methods=['POST'])
def close_subscription(sub_id):
    data = request.get_json() or {}
    reason = data.get('reason', 'Terminated by user or policy')

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT subscription_number FROM subscriptions WHERE id = ?", (sub_id,))
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        cursor.execute("""
            UPDATE subscriptions
            SET status = 'CLOSED', cancellation_reason = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (reason, sub_id))

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CLOSE', 'subscription', ?, ?)
        """, (sub['subscription_number'], f"Subscription closed. Reason: {reason}"))

        return jsonify({"success": True, "message": "Subscription closed."})

@subscriptions_bp.route('/<int:sub_id>/generate-invoice', methods=['POST'])
def manual_generate_invoice(sub_id):
    from services.billing_engine import generate_due_invoices
    # Force single invoice generation
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT s.*, c.name as customer_name, p.plan_name FROM subscriptions s JOIN customers c ON s.customer_id = c.id JOIN plans p ON s.plan_id = p.id WHERE s.id = ?", (sub_id,))
        sub = cursor.fetchone()
        if not sub:
            return jsonify({"success": False, "error": "Subscription not found"}), 404

        inv_num = get_next_invoice_number(cursor)
        today = datetime.date.today().strftime("%Y-%m-%d")
        due = (datetime.date.today() + datetime.timedelta(days=15)).strftime("%Y-%m-%d")

        cursor.execute("""
            INSERT INTO invoices (
                invoice_number, customer_id, subscription_id, invoice_date, due_date,
                subtotal, discount_amount, tax_amount, grand_total, amount_paid, payment_status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0.0, 'confirmed', ?)
        """, (
            inv_num, sub['customer_id'], sub_id, today, due,
            sub['subtotal'], sub['discount_amount'], sub['tax_amount'], sub['total_amount'],
            f"Manually triggered recurring invoice for {sub['subscription_number']}"
        ))
        inv_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO invoice_lines (invoice_id, product_id, description, quantity, unit_price, tax_percent, line_total)
            VALUES (?, NULL, ?, 1, ?, 18.0, ?)
        """, (inv_id, f"Plan billing - {sub['plan_name']}", sub['subtotal'], sub['total_amount']))

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'GENERATE', 'invoice', ?, ?)
        """, (inv_num, f"Manually generated invoice {inv_num} for subscription {sub['subscription_number']}."))

        return jsonify({
            "success": True,
            "message": f"Invoice {inv_num} generated successfully.",
            "invoice_number": inv_num,
            "invoice_id": inv_id
        })
