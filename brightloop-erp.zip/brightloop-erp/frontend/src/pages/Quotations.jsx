import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Plus, 
  Search, 
  CheckCircle2, 
  Copy, 
  XCircle, 
  Eye, 
  ChevronRight,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Quotations({ setCurrentView, setSelectedId }) {
  const [quotations, setQuotations] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [createModal, setCreateModal] = useState(false);
  const [viewModal, setViewModal] = useState(null);

  // New quotation form
  const [newQuote, setNewQuote] = useState({
    customer_id: '',
    plan_id: '',
    template_name: 'Standard SaaS Agreement',
    payment_terms: 'Net 15 Days',
    discount_amount: 0,
    notes: ''
  });

  const toast = useToast();

  const fetchQuotations = async () => {
    setLoading(true);
    try {
      const res = await api.getQuotations({ search: searchTerm });
      if (res.success) {
        setQuotations(res.quotations || []);
      }
    } catch (e) {
      toast.error('Failed to load quotations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQuotations();
  }, [searchTerm]);

  useEffect(() => {
    Promise.all([api.getCustomers(), api.getPlans()]).then(([cRes, pRes]) => {
      if (cRes.success) setCustomers(cRes.customers || []);
      if (pRes.success) setPlans(pRes.plans || []);
    });
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const res = await api.createQuotation(newQuote);
      if (res.success) {
        toast.success(res.message);
        setCreateModal(false);
        fetchQuotations();
      }
    } catch (err) {
      toast.error(err.message || 'Creation failed');
    }
  };

  const handleConfirm = async (qId) => {
    try {
      const res = await api.confirmQuotation(qId);
      if (res.success) {
        toast.success(res.message);
        fetchQuotations();
        if (res.subscription_number) {
          setSelectedId(res.subscription_number);
          setCurrentView('subscription_detail');
        }
      }
    } catch (err) {
      toast.error(err.message || 'Confirmation failed');
    }
  };

  const handleDuplicate = async (qId) => {
    try {
      const res = await api.duplicateQuotation(qId);
      if (res.success) {
        toast.success(res.message);
        fetchQuotations();
      }
    } catch (err) {
      toast.error('Duplication failed');
    }
  };

  const handleCancel = async (qId) => {
    try {
      const res = await api.cancelQuotation(qId);
      if (res.success) {
        toast.success(res.message);
        fetchQuotations();
      }
    } catch (err) {
      toast.error('Cancellation failed');
    }
  };

  const selectedPlan = plans.find(p => String(p.id) === String(newQuote.plan_id));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-brand-600" />
            <span>Quotation Management</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Pre-sales proposals, negotiation terms, and 1-click conversion to live subscriptions
          </p>
        </div>

        <button
          onClick={() => setCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
        >
          <Plus className="w-4 h-4" />
          <span>New Quotation</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs flex justify-between items-center">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search quotation #, customer, company..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-100/80 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
          />
        </div>
        <span className="text-xs text-slate-500 hidden sm:inline">{quotations.length} total quotes</span>
      </div>

      {/* Table */}
      <div className="erp-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Quote #</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Template & Plan</th>
                <th className="py-3 px-4">Expiration</th>
                <th className="py-3 px-4">Total Amount</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-8 text-center text-slate-400">Loading quotations...</td>
                </tr>
              ) : quotations.length === 0 ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-400">No quotations found.</td>
                </tr>
              ) : (
                quotations.map((q) => (
                  <tr key={q.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-brand-600">{q.quotation_number}</td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-slate-900">{q.customer_name}</p>
                      <p className="text-[10px] text-slate-400">{q.customer_company}</p>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-medium text-slate-800">{q.template_name}</p>
                      <span className="text-[10px] text-purple-600 font-semibold">{q.plan_name || 'Custom Bundle'}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-mono">{formatDate(q.expiration_date)}</td>
                    <td className="py-3 px-4 font-bold text-slate-900 font-mono">{formatCurrency(q.total_amount)}</td>
                    <td className="py-3 px-4"><StatusBadge status={q.status} /></td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {q.status !== 'confirmed' && q.status !== 'cancelled' && (
                          <button
                            onClick={() => handleConfirm(q.id)}
                            className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold rounded-lg text-[11px] border border-emerald-200 transition-colors"
                            title="Confirm & Convert to Subscription"
                          >
                            Confirm → Sub
                          </button>
                        )}
                        <button
                          onClick={() => handleDuplicate(q.id)}
                          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg"
                          title="Duplicate"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        {q.status !== 'cancelled' && q.status !== 'confirmed' && (
                          <button
                            onClick={() => handleCancel(q.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                            title="Cancel"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Modal */}
      {createModal && (
        <Modal
          isOpen={createModal}
          onClose={() => setCreateModal(false)}
          title="Create New Quotation"
          subtitle="Generate a formal proposal for a prospective client"
          maxWidth="max-w-xl"
        >
          <form onSubmit={handleCreate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Customer</label>
              <select
                value={newQuote.customer_id}
                onChange={(e) => setNewQuote({ ...newQuote, customer_id: e.target.value })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              >
                <option value="">-- Select Customer --</option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.company})</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Plan Package</label>
                <select
                  value={newQuote.plan_id}
                  onChange={(e) => setNewQuote({ ...newQuote, plan_id: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="">-- Select Plan --</option>
                  {plans.map(p => (
                    <option key={p.id} value={p.id}>{p.plan_name} ({formatCurrency(p.price)})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Quotation Template</label>
                <select
                  value={newQuote.template_name}
                  onChange={(e) => setNewQuote({ ...newQuote, template_name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="Standard SaaS Agreement">Standard SaaS Agreement</option>
                  <option value="Enterprise Custom SLA">Enterprise Custom SLA</option>
                  <option value="Startup Accelerator Tier">Startup Accelerator Tier</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Payment Terms</label>
                <select
                  value={newQuote.payment_terms}
                  onChange={(e) => setNewQuote({ ...newQuote, payment_terms: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="Immediate Payment">Immediate Payment</option>
                  <option value="Net 15 Days">Net 15 Days</option>
                  <option value="Net 30 Days">Net 30 Days</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Discount (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={newQuote.discount_amount}
                  onChange={(e) => setNewQuote({ ...newQuote, discount_amount: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>
            </div>

            {selectedPlan && (
              <div className="p-3 bg-purple-50 rounded-xl text-xs space-y-1 text-purple-900 border border-purple-100">
                <div className="flex justify-between">
                  <span>Base Plan Price:</span>
                  <span>{formatCurrency(selectedPlan.price)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Discount:</span>
                  <span>- {formatCurrency(newQuote.discount_amount)}</span>
                </div>
                <div className="flex justify-between">
                  <span>GST (18%):</span>
                  <span>{formatCurrency(Math.max(0, selectedPlan.price - newQuote.discount_amount) * 0.18)}</span>
                </div>
                <div className="flex justify-between font-bold pt-1 border-t border-purple-200 text-sm">
                  <span>Total Proposal Amount:</span>
                  <span>{formatCurrency(Math.max(0, selectedPlan.price - newQuote.discount_amount) * 1.18)}</span>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Proposal Notes</label>
              <textarea
                value={newQuote.notes}
                onChange={(e) => setNewQuote({ ...newQuote, notes: e.target.value })}
                placeholder="Specific deliverables, service credits, or integration support..."
                rows="2"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCreateModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
              >
                Create Quotation
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
