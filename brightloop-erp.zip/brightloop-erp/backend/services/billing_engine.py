import datetime
from dateutil.relativedelta import relativedelta
from database import get_db

def calculate_next_billing_date(base_date, frequency):
    if isinstance(base_date, str):
        base_date = datetime.datetime.strptime(base_date, "%Y-%m-%d").date()
    elif isinstance(base_date, datetime.datetime):
        base_date = base_date.date()

    if frequency == 'daily':
        return base_date + datetime.timedelta(days=1)
    elif frequency == 'weekly':
        return base_date + datetime.timedelta(days=7)
    elif frequency == 'monthly':
        return base_date + relativedelta(months=1)
    elif frequency == 'yearly':
        return base_date + relativedelta(years=1)
    else:
        return base_date + relativedelta(months=1)

def get_next_invoice_number(cursor):
    cursor.execute("SELECT invoice_number FROM invoices ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    year = datetime.date.today().year
    if row and row['invoice_number']:
        last_num = row['invoice_number']
        try:
            parts = last_num.split('-')
            last_seq = int(parts[-1])
            return f"INV-{year}-{last_seq + 1:04d}"
        except Exception:
            pass
    return f"INV-{year}-0001"

def find_applicable_discount(cursor, customer_id, subtotal, quantity):
    today = datetime.date.today().strftime("%Y-%m-%d")
    cursor.execute("""
        SELECT * FROM discounts
        WHERE active = 1
          AND (start_date IS NULL OR start_date <= ?)
          AND (end_date IS NULL OR end_date >= ?)
          AND current_usage < max_usage
          AND min_purchase <= ?
          AND min_quantity <= ?
        ORDER BY discount_value DESC
        LIMIT 1
    """, (today, today, subtotal, quantity))
    return cursor.fetchone()

def generate_due_invoices(target_date=None, force=False):
    """
    Core Recurring Billing Engine:
    Identifies all ACTIVE subscriptions whose next_billing_date is on or before target_date.
    Generates invoices, prevents duplicates, computes taxes & discounts,
    advances the next_billing_date, and records notifications & logs.
    """
    if target_date is None:
        target_date = datetime.date.today()
    elif isinstance(target_date, str):
        target_date = datetime.datetime.strptime(target_date, "%Y-%m-%d").date()

    target_date_str = target_date.strftime("%Y-%m-%d")
    generated_invoices = []

    with get_db() as conn:
        cursor = conn.cursor()

        # Find active subscriptions due
        cursor.execute("""
            SELECT s.*, c.name as customer_name, c.email as customer_email, c.payment_terms,
                   p.plan_name, p.billing_frequency as plan_freq
            FROM subscriptions s
            JOIN customers c ON s.customer_id = c.id
            JOIN plans p ON s.plan_id = p.id
            WHERE s.status = 'ACTIVE'
              AND s.next_billing_date <= ?
            ORDER BY s.next_billing_date ASC
        """, (target_date_str,))
        due_subs = cursor.fetchall()

        for sub in due_subs:
            sub_id = sub['id']
            sub_num = sub['subscription_number']
            cid = sub['customer_id']
            billing_start = sub['next_billing_date']
            freq = sub['billing_frequency'] or sub['plan_freq'] or 'monthly'
            billing_start_date = datetime.datetime.strptime(billing_start, "%Y-%m-%d").date()
            billing_end_date = calculate_next_billing_date(billing_start_date, freq) - datetime.timedelta(days=1)

            # Prevent duplicate invoices for the same subscription in the same period
            if not force:
                cursor.execute("""
                    SELECT id FROM invoices
                    WHERE subscription_id = ?
                      AND billing_period_start = ?
                      AND payment_status != 'cancelled'
                """, (sub_id, billing_start))
                existing = cursor.fetchone()
                if existing:
                    # Already generated for this period, advance date if needed
                    next_date = calculate_next_billing_date(billing_start_date, freq)
                    cursor.execute("""
                        UPDATE subscriptions
                        SET next_billing_date = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    """, (next_date.strftime("%Y-%m-%d"), sub_id))
                    continue

            # Fetch subscription lines
            cursor.execute("""
                SELECT sl.*, pr.name as product_name
                FROM subscription_lines sl
                JOIN products pr ON sl.product_id = pr.id
                WHERE sl.subscription_id = ?
            """, (sub_id,))
            lines = cursor.fetchall()

            if not lines:
                # Fallback to subtotal on subscription
                subtotal = sub['subtotal'] or sub['total_amount'] or 0.0
                total_qty = 1
            else:
                subtotal = sum(l['quantity'] * l['unit_price'] for l in lines)
                total_qty = sum(l['quantity'] for l in lines)

            # Evaluate eligible discount
            discount = find_applicable_discount(cursor, cid, subtotal, total_qty)
            discount_amount = 0.0
            discount_id = None
            if discount:
                discount_id = discount['id']
                if discount['discount_type'] == 'percentage':
                    discount_amount = round((subtotal * discount['discount_value']) / 100.0, 2)
                else:
                    discount_amount = min(discount['discount_value'], subtotal)

            taxable_amount = max(0.0, subtotal - discount_amount)
            tax_rate = 18.0  # 18% standard GST
            tax_amount = round((taxable_amount * tax_rate) / 100.0, 2)
            grand_total = round(taxable_amount + tax_amount, 2)

            inv_number = get_next_invoice_number(cursor)
            inv_date = target_date.strftime("%Y-%m-%d")
            
            # Due date calculation based on terms
            due_days = 15
            terms = (sub['payment_terms'] or '').lower()
            if 'immediate' in terms:
                due_days = 0
            elif '30' in terms:
                due_days = 30
            due_date = (target_date + datetime.timedelta(days=due_days)).strftime("%Y-%m-%d")

            # Create invoice record
            cursor.execute("""
                INSERT INTO invoices (
                    invoice_number, customer_id, subscription_id, invoice_date, due_date,
                    billing_period_start, billing_period_end, subtotal, discount_amount,
                    tax_amount, grand_total, amount_paid, payment_status, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0.0, 'confirmed', ?)
            """, (
                inv_number, cid, sub_id, inv_date, due_date,
                billing_start, billing_end_date.strftime("%Y-%m-%d"),
                subtotal, discount_amount, tax_amount, grand_total,
                f"Auto-generated recurring invoice for period {billing_start} to {billing_end_date.strftime('%Y-%m-%d')}"
            ))
            inv_id = cursor.lastrowid

            # Insert invoice lines
            if lines:
                for line in lines:
                    cursor.execute("""
                        INSERT INTO invoice_lines (invoice_id, product_id, description, quantity, unit_price, tax_percent, line_total)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        inv_id, line['product_id'],
                        f"{line['product_name']} - {sub['plan_name']}",
                        line['quantity'], line['unit_price'], line['tax_percent'],
                        round(line['quantity'] * line['unit_price'] * 1.18, 2)
                    ))
            else:
                cursor.execute("""
                    INSERT INTO invoice_lines (invoice_id, product_id, description, quantity, unit_price, tax_percent, line_total)
                    VALUES (?, NULL, ?, 1, ?, 18.0, ?)
                """, (inv_id, f"Subscription Fee - {sub['plan_name']}", subtotal, grand_total))

            # Record discount usage if applied
            if discount_id and discount_amount > 0:
                cursor.execute("""
                    INSERT INTO discount_usage (discount_id, customer_id, invoice_id, discount_amount)
                    VALUES (?, ?, ?, ?)
                """, (discount_id, cid, inv_id, discount_amount))
                cursor.execute("""
                    UPDATE discounts SET current_usage = current_usage + 1 WHERE id = ?
                """, (discount_id,))

            # Advance subscription next_billing_date
            next_date = calculate_next_billing_date(billing_start_date, freq)
            cursor.execute("""
                UPDATE subscriptions
                SET next_billing_date = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (next_date.strftime("%Y-%m-%d"), sub_id))

            # Activity log
            cursor.execute("""
                INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
                VALUES (1, 'Recurring Billing Engine', 'GENERATE', 'invoice', ?, ?)
            """, (inv_number, f"Auto-billed subscription {sub_num} for ₹{grand_total:,.2f}."))

            # In-App Notification for customer
            cursor.execute("SELECT user_id FROM customers WHERE id = ?", (cid,))
            c_user = cursor.fetchone()
            if c_user and c_user['user_id']:
                cursor.execute("""
                    INSERT INTO notifications (user_id, title, message, category, link)
                    VALUES (?, 'New Recurring Invoice Ready', ?, 'billing', ?)
                """, (c_user['user_id'], f"Invoice {inv_number} for ₹{grand_total:,.2f} has been generated.", f"/invoices/{inv_number}"))

            generated_invoices.append({
                "invoice_id": inv_id,
                "invoice_number": inv_number,
                "subscription_number": sub_num,
                "customer_name": sub['customer_name'],
                "amount": grand_total,
                "due_date": due_date,
                "next_billing_date": next_date.strftime("%Y-%m-%d")
            })

    return generated_invoices

def get_due_subscriptions_preview(target_date=None):
    """Returns preview of subscriptions due for billing"""
    if target_date is None:
        target_date = datetime.date.today()
    elif isinstance(target_date, str):
        target_date = datetime.datetime.strptime(target_date, "%Y-%m-%d").date()

    target_date_str = target_date.strftime("%Y-%m-%d")

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.*, c.name as customer_name, c.email as customer_email,
                   p.plan_name, p.price as plan_price
            FROM subscriptions s
            JOIN customers c ON s.customer_id = c.id
            JOIN plans p ON s.plan_id = p.id
            WHERE s.status = 'ACTIVE'
              AND s.next_billing_date <= ?
            ORDER BY s.next_billing_date ASC
        """, (target_date_str,))
        rows = [dict(r) for r in cursor.fetchall()]
        return rows
