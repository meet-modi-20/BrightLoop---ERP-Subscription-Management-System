from flask import Blueprint, jsonify
from services.odoo_mapping import get_odoo_architecture_blueprint
from database import get_db

odoo_bp = Blueprint('odoo', __name__)

@odoo_bp.route('/blueprint', methods=['GET'])
def odoo_blueprint():
    blueprint = get_odoo_architecture_blueprint()
    return jsonify({"success": True, "blueprint": blueprint})

@odoo_bp.route('/export-sample', methods=['GET'])
def odoo_export_sample():
    with get_db() as conn:
        cursor = conn.cursor()
        
        # Format sample partners (Odoo res.partner)
        cursor.execute("SELECT * FROM customers LIMIT 3")
        partners = []
        for c in cursor.fetchall():
            partners.append({
                "model": "res.partner",
                "values": {
                    "name": c['name'],
                    "email": c['email'],
                    "phone": c['phone'],
                    "is_company": True,
                    "street": c['address'],
                    "city": c['city'],
                    "vat": c['tax_id']
                }
            })

        # Format sample subscriptions (Odoo sale.order)
        cursor.execute("""
            SELECT s.*, c.name as partner_name, p.plan_name
            FROM subscriptions s
            JOIN customers c ON s.customer_id = c.id
            JOIN plans p ON s.plan_id = p.id
            LIMIT 3
        """)
        subscriptions = []
        for s in cursor.fetchall():
            subscriptions.append({
                "model": "sale.order",
                "values": {
                    "name": s['subscription_number'],
                    "partner_id": s['partner_name'],
                    "is_subscription": True,
                    "start_date": s['start_date'],
                    "next_invoice_date": s['next_billing_date'],
                    "amount_total": s['total_amount'],
                    "state": "sale" if s['status'] == 'ACTIVE' else "draft"
                }
            })

        return jsonify({
            "success": True,
            "export_format": "Odoo 17/18 External ID / JSON-RPC Structure",
            "res_partner_payload": partners,
            "sale_order_payload": subscriptions
        })
