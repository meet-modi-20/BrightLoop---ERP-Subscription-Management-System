import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Plus, 
  Search, 
  Building, 
  Mail, 
  Phone, 
  MapPin, 
  Repeat, 
  Receipt, 
  CreditCard,
  ChevronRight
} from 'lucide-react';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Customers({ setCurrentView, setSelectedId }) {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [createModal, setCreateModal] = useState(false);
  const [selectedCust, setSelectedCust] = useState(null);

  // Form
  const [custForm, setCustForm] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    address: '',
    city: '',
    state: '',
    tax_id: '',
    payment_terms: 'Net 15 Days'
  });

  const toast = useToast();

  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const res = await api.getCustomers({ search: searchTerm });
      if (res.success) {
        setCustomers(res.customers || []);
      }
    } catch (e) {
      toast.error('Failed to load customers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, [searchTerm]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const res = await api.createCustomer(custForm);
      if (res.success) {
        toast.success(res.message);
        setCreateModal(false);
        setCustForm({
          name: '',
          email: '',
          phone: '',
          company: '',
          address: '',
          city: '',
          state: '',
          tax_id: '',
          payment_terms: 'Net 15 Days'
        });
        fetchCustomers();
      }
    } catch (err) {
      toast.error(err.message || 'Creation failed');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Users className="w-6 h-6 text-brand-600" />
            <span>Customers & Accounts CRM</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Enterprise clients, billing contacts and GST tax profiles (Odoo res.partner)
          </p>
        </div>

        <button
          onClick={() => setCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
        >
          <Plus className="w-4 h-4" />
          <span>New Customer</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs flex justify-between items-center">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search customer, company, GSTIN, city..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-100/80 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
          />
        </div>
        <span className="text-xs text-slate-500 hidden sm:inline">{customers.length} total clients</span>
      </div>

      {/* Customers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-400">Loading customers...</div>
        ) : customers.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-400">No customers found.</div>
        ) : (
          customers.map((c) => (
            <div key={c.id} className="erp-card p-5 flex flex-col justify-between group">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base group-hover:text-brand-600 transition-colors">
                      {c.name}
                    </h3>
                    <p className="text-xs font-semibold text-slate-600 flex items-center gap-1.5 mt-0.5">
                      <Building className="w-3.5 h-3.5 text-slate-400" />
                      <span>{c.company || 'Enterprise Account'}</span>
                    </p>
                  </div>
                  <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
                    {c.payment_terms || 'Net 15'}
                  </span>
                </div>

                <div className="space-y-1 text-xs text-slate-500">
                  <p className="flex items-center gap-1.5 truncate">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{c.email}</span>
                  </p>
                  {c.phone && (
                    <p className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{c.phone}</span>
                    </p>
                  )}
                  {c.city && (
                    <p className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{c.city}, {c.state || 'India'}</span>
                    </p>
                  )}
                  {c.tax_id && (
                    <p className="text-[11px] font-mono text-slate-700 pt-1">
                      GSTIN: <span className="font-semibold">{c.tax_id}</span>
                    </p>
                  )}
                </div>

                {/* Key Metrics */}
                <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-100 text-xs">
                  <div className="p-2 bg-slate-50 rounded-xl">
                    <span className="text-[10px] text-slate-400 font-semibold uppercase block">Active Subs</span>
                    <span className="font-bold text-slate-900 text-sm">{c.active_subs || 0} contracts</span>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-xl">
                    <span className="text-[10px] text-slate-400 font-semibold uppercase block">Total Settled</span>
                    <span className="font-bold text-emerald-700 text-sm font-mono">{formatCurrency(c.total_revenue || 0)}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                {c.overdue_invoices > 0 ? (
                  <span className="text-rose-600 font-semibold text-[11px]">
                    ⚠️ {c.overdue_invoices} overdue invoice(s)
                  </span>
                ) : (
                  <span className="text-emerald-600 font-medium text-[11px]">✓ Account Good Standing</span>
                )}
                <button
                  onClick={() => {
                    setCurrentView('subscriptions');
                  }}
                  className="text-brand-600 hover:text-brand-700 font-semibold flex items-center gap-1"
                >
                  <span>Subscriptions</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Create Customer Modal */}
      {createModal && (
        <Modal
          isOpen={createModal}
          onClose={() => setCreateModal(false)}
          title="Add New Enterprise Customer"
          subtitle="Create customer contact record (res.partner)"
          maxWidth="max-w-xl"
        >
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Contact Person Name</label>
                <input
                  type="text"
                  value={custForm.name}
                  onChange={(e) => setCustForm({ ...custForm, name: e.target.value })}
                  placeholder="e.g. Vikram Patel"
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Company / Entity</label>
                <input
                  type="text"
                  value={custForm.company}
                  onChange={(e) => setCustForm({ ...custForm, company: e.target.value })}
                  placeholder="e.g. Nexus Software Systems"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={custForm.email}
                  onChange={(e) => setCustForm({ ...custForm, email: e.target.value })}
                  placeholder="name@company.com"
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={custForm.phone}
                  onChange={(e) => setCustForm({ ...custForm, phone: e.target.value })}
                  placeholder="+91 98201 12345"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">City</label>
                <input
                  type="text"
                  value={custForm.city}
                  onChange={(e) => setCustForm({ ...custForm, city: e.target.value })}
                  placeholder="Bengaluru"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">GSTIN / Tax ID</label>
                <input
                  type="text"
                  value={custForm.tax_id}
                  onChange={(e) => setCustForm({ ...custForm, tax_id: e.target.value })}
                  placeholder="29AABCT1234E1Z5"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Payment Terms</label>
                <select
                  value={custForm.payment_terms}
                  onChange={(e) => setCustForm({ ...custForm, payment_terms: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="Immediate Payment">Immediate Payment</option>
                  <option value="Net 15 Days">Net 15 Days</option>
                  <option value="Net 30 Days">Net 30 Days</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Street Address</label>
              <textarea
                value={custForm.address}
                onChange={(e) => setCustForm({ ...custForm, address: e.target.value })}
                placeholder="Plot 45, Cyber Hub, Electronic City..."
                rows="2"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCreateModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
              >
                Save Customer
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
