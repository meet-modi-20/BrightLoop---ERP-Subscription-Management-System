import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Bell, 
  HelpCircle, 
  User, 
  CheckCheck, 
  Sparkles, 
  ChevronDown,
  Clock,
  ShieldCheck,
  UserCheck,
  LogOut,
  ExternalLink,
  Zap
} from 'lucide-react';
import { useAuth, DEMO_ACCOUNTS } from '../context/AuthContext';
import { api } from '../services/api';
import { useToast } from '../context/ToastContext';

export default function TopNav({ onSearch, openOdooModal, onTriggerBilling, setCurrentView }) {
  const { user, switchRole, logout } = useAuth();
  const toast = useToast();
  
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifOpen, setNotifOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [roleSwitcherOpen, setRoleSwitcherOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [helpOpen, setHelpOpen] = useState(false);

  const notifRef = useRef(null);
  const userRef = useRef(null);

  const fetchNotifs = async () => {
    try {
      const res = await api.getNotifications(user?.id);
      if (res.success) {
        setNotifications(res.notifications || []);
        setUnreadCount(res.unread_count || 0);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchNotifs();
    const interval = setInterval(fetchNotifs, 15000);
    return () => clearInterval(interval);
  }, [user]);

  // Handle outside click
  useEffect(() => {
    function handleClickOutside(e) {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setNotifOpen(false);
      }
      if (userRef.current && !userRef.current.contains(e.target)) {
        setUserDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMarkAllRead = async () => {
    try {
      await api.markAllNotificationsRead(user?.id);
      setUnreadCount(0);
      setNotifications(prev => prev.map(n => ({ ...n, is_read: 1 })));
      toast.success('All notifications marked as read');
    } catch (e) {
      toast.error('Failed to mark notifications read');
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (onSearch) onSearch(searchQuery);
  };

  return (
    <>
      <header className="h-16 bg-white border-b border-slate-200/80 px-6 flex items-center justify-between z-20 sticky top-0 shadow-xs">
        {/* Left: Global Search */}
        <div className="flex items-center gap-4 flex-1 max-w-md">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (onSearch) onSearch(e.target.value);
              }}
              placeholder="Search subscriptions, customers, invoices (Press / to search)..."
              className="w-full pl-10 pr-4 py-2 bg-slate-100/80 border border-slate-200/80 rounded-xl text-xs placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 transition-all"
            />
          </form>
        </div>

        {/* Right: Actions, Notifications, Role Switcher, Profile */}
        <div className="flex items-center gap-3">
          {/* Quick Action: Recurring Billing Trigger (Admin/Staff) */}
          {user?.role !== 'customer' && (
            <button
              onClick={onTriggerBilling}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-brand-50 hover:bg-brand-100 text-brand-700 border border-brand-200/80 rounded-lg text-xs font-semibold transition-all shadow-xs"
              title="Execute recurring billing engine immediately"
            >
              <Zap className="w-3.5 h-3.5 text-brand-600 fill-brand-600" />
              <span>Generate Due Invoices</span>
            </button>
          )}

          {/* Odoo Architecture Pill */}
          <button
            onClick={openOdooModal}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-lg text-xs font-semibold transition-all shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span className="hidden md:inline">Odoo Blueprint</span>
          </button>

          {/* Role Switcher Pill for Hackathon Demo */}
          <div className="relative">
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
              <span className="text-[10px] uppercase font-bold text-slate-500 px-2 hidden sm:inline">Role:</span>
              <button
                onClick={() => switchRole('admin')}
                className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition-all ${
                  user?.role === 'admin' ? 'bg-white text-indigo-700 shadow-xs border border-slate-200/60' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Admin
              </button>
              <button
                onClick={() => switchRole('staff')}
                className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition-all ${
                  user?.role === 'staff' ? 'bg-white text-emerald-700 shadow-xs border border-slate-200/60' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Staff
              </button>
              <button
                onClick={() => switchRole('customer')}
                className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition-all ${
                  user?.role === 'customer' ? 'bg-white text-purple-700 shadow-xs border border-slate-200/60' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Client
              </button>
            </div>
          </div>

          {/* Notifications Dropdown */}
          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setNotifOpen(!notifOpen)}
              className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-500 text-white text-[9px] font-extrabold rounded-full flex items-center justify-center ring-2 ring-white animate-pulse">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>

            {notifOpen && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 py-3 z-50">
                <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Notifications</h4>
                    <p className="text-[11px] text-slate-500">{unreadCount} unread alert(s)</p>
                  </div>
                  {unreadCount > 0 && (
                    <button
                      onClick={handleMarkAllRead}
                      className="text-xs text-brand-600 hover:text-brand-700 font-medium flex items-center gap-1"
                    >
                      <CheckCheck className="w-3.5 h-3.5" />
                      Mark all read
                    </button>
                  )}
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-slate-400 text-xs">
                      No notifications right now
                    </div>
                  ) : (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        className={`p-3.5 hover:bg-slate-50 transition-colors flex items-start gap-3 ${
                          !n.is_read ? 'bg-indigo-50/40' : ''
                        }`}
                      >
                        <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${!n.is_read ? 'bg-brand-500 ring-2 ring-brand-200' : 'bg-transparent'}`} />
                        <div className="flex-1">
                          <p className="text-xs font-semibold text-slate-800">{n.title}</p>
                          <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{n.message}</p>
                          <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-400">
                            <Clock className="w-3 h-3" />
                            <span>{new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Help Icon */}
          <button
            onClick={() => setHelpOpen(true)}
            className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
            title="System Documentation & Guide"
          >
            <HelpCircle className="w-5 h-5" />
          </button>

          {/* User Profile */}
          <div className="relative" ref={userRef}>
            <button
              onClick={() => setUserDropdownOpen(!userDropdownOpen)}
              className="flex items-center gap-2.5 p-1.5 pl-2 rounded-xl hover:bg-slate-100 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-brand-500 to-indigo-600 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
              </div>
              <div className="text-left hidden lg:block">
                <p className="text-xs font-bold text-slate-800 leading-tight">{user?.name || 'Administrator'}</p>
                <p className="text-[10px] text-slate-500 leading-tight">{user?.email || 'admin@brightloop.com'}</p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {userDropdownOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50">
                <div className="px-4 py-2 border-b border-slate-100">
                  <p className="text-xs font-bold text-slate-900">{user?.name}</p>
                  <p className="text-[11px] text-slate-500">{user?.email}</p>
                  <span className="inline-block mt-1 text-[10px] font-bold text-brand-600 bg-brand-50 px-2 py-0.5 rounded-full border border-brand-200">
                    Role: {user?.role?.toUpperCase()}
                  </span>
                </div>
                <div className="p-1">
                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      openOdooModal();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 rounded-lg"
                  >
                    <Sparkles className="w-4 h-4 text-purple-600" />
                    <span>Odoo Integration Guide</span>
                  </button>
                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      setHelpOpen(true);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 rounded-lg"
                  >
                    <HelpCircle className="w-4 h-4 text-slate-500" />
                    <span>Documentation</span>
                  </button>
                  <button
                    onClick={logout}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 rounded-lg mt-1 border-t border-slate-100"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Help Modal */}
      {helpOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-brand-50 rounded-xl text-brand-600">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 text-base">Brightloop ERP System Guide</h3>
              </div>
              <button onClick={() => setHelpOpen(false)} className="text-slate-400 hover:text-slate-600 text-xl font-bold">×</button>
            </div>
            <div className="py-4 space-y-3 text-xs text-slate-600 leading-relaxed max-h-96 overflow-y-auto">
              <p className="font-semibold text-slate-800">Welcome to Brightloop Subscription ERP prototype built for the Odoo Hackathon 2026.</p>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <p className="font-bold text-slate-900">Demo User Credentials:</p>
                <p>• <span className="font-mono text-indigo-700 font-semibold">Admin:</span> admin@brightloop.com / Admin@123!</p>
                <p>• <span className="font-mono text-emerald-700 font-semibold">Staff:</span> staff@brightloop.com / Staff@123!</p>
                <p>• <span className="font-mono text-purple-700 font-semibold">Customer:</span> customer@brightloop.com / Customer@123!</p>
              </div>
              <p><span className="font-bold text-slate-800">Recurring Billing:</span> Click the <span className="font-semibold text-brand-600">"Generate Due Invoices"</span> button in the top bar to run the engine. Subscriptions on or past due dates will automatically generate draft/confirmed invoices and advance their next billing schedule.</p>
              <p><span className="font-bold text-slate-800">Role Switching:</span> You can switch active roles at any time using the header pill selector.</p>
            </div>
            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setHelpOpen(false)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
