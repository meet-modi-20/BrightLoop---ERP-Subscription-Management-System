import datetime
from flask import Blueprint, request, jsonify
from database import get_db
from services.billing_engine import calculate_next_billing_date

quotations_bp = Blueprint('quotations', __name__)

def generate_quotation_number(cursor):
    cursor.execute("SELECT quotation_number FROM quotations ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    year = datetime.date.today().year
    if row and row['quotation_number']:
        try:
            parts = row['quotation_number'].split('-')
            seq = int(parts[-1])
            return f"QT-{year}-{seq + 1:04d}"
        except Exception:
            pass
    return f"QT-{year}-0001"

@quotations_bp.route('', methods=['GET'])
def list_quotations():
    status = request.args.get('status')
    search = request.args.get('search', '').strip()

    query = """
        SELECT q.*, c.name as customer_name, c.company as customer_company, p.plan_name
        FROM quotations q
        JOIN customers c ON q.customer_id = c.id
        LEFT JOIN plans p ON q.plan_id = p.id
        WHERE 1=1
    """
    params = []
    if status and status != 'ALL':
        query += " AND q.status = ?"
        params.append(status.lower())

    if search:
        query += " AND (q.quotation_number LIKE ? OR c.name LIKE ? OR c.company LIKE ?)"
        wild = f"%{search}%"
        params.extend([wild, wild, wild])

    query += " ORDER BY q.id DESC"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = [dict(r) for r in cursor.fetchall()]
        return jsonify({"success": True, "quotations": rows})

@quotations_bp.route('/<int:q_id>', methods=['GET'])
def get_quotation_detail(q_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT q.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone,
                   c.company as customer_company, c.address as customer_address, p.plan_name
            FROM quotations q
            JOIN customers c ON q.customer_id = c.id
            LEFT JOIN plans p ON q.plan_id = p.id
            WHERE q.id = ?
        """, (q_id,))
        quote = cursor.fetchone()
        if not quote:
            return jsonify({"success": False, "error": "Quotation not found"}), 404

        quote_data = dict(quote)
        cursor.execute("""
            SELECT ql.*, pr.name as product_name
            FROM quotation_lines ql
            JOIN products pr ON ql.product_id = pr.id
            WHERE ql.quotation_id = ?
        """, (q_id,))
        quote_data['lines'] = [dict(l) for l in cursor.fetchall()]

        return jsonify({"success": True, "quotation": quote_data})

@quotations_bp.route('', methods=['POST'])
def create_quotation():
    data = request.get_json() or {}
    customer_id = data.get('customer_id')
    plan_id = data.get('plan_id')
    template_name = data.get('template_name', 'Standard SaaS Agreement')
    expiration_date = data.get('expiration_date') or (datetime.date.today() + datetime.timedelta(days=30)).strftime("%Y-%m-%d")
    payment_terms = data.get('payment_terms', 'Net 15 Days')
    notes = data.get('notes', '')
    lines = data.get('lines', [])

    if not customer_id:
        return jsonify({"success": False, "error": "Customer is required."}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        q_num = generate_quotation_number(cursor)

        subtotal = 0.0
        tax_amount = 0.0
        if lines:
            for l in lines:
                sub = float(l.get('unit_price', 0)) * int(l.get('quantity', 1))
                subtotal += sub
                tax_amount += sub * (float(l.get('tax_percent', 18.0)) / 100.0)
        else:
            # Fallback to plan price
            if plan_id:
                cursor.execute("SELECT price FROM plans WHERE id = ?", (plan_id,))
                p = cursor.fetchone()
                if p:
                    subtotal = float(p['price'])
                    tax_amount = subtotal * 0.18

        discount_amount = float(data.get('discount_amount', 0.0))
        total_amount = round(max(0.0, subtotal - discount_amount) + tax_amount, 2)

        cursor.execute("""
            INSERT INTO quotations (
                quotation_number, customer_id, plan_id, template_name, expiration_date,
                payment_terms, subtotal, discount_amount, tax_amount, total_amount, status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?)
        """, (
            q_num, customer_id, plan_id, template_name, expiration_date,
            payment_terms, round(subtotal, 2), round(discount_amount, 2),
            round(tax_amount, 2), total_amount, notes
        ))
        q_id = cursor.lastrowid

        if lines:
            for l in lines:
                qty = int(l.get('quantity', 1))
                u_price = float(l.get('unit_price', 0))
                cursor.execute("""
                    INSERT INTO quotation_lines (quotation_id, product_id, description, quantity, unit_price, tax_percent, total_amount)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (q_id, l.get('product_id'), l.get('description', 'SaaS Product'), qty, u_price, float(l.get('tax_percent', 18.0)), round(qty * u_price * 1.18, 2)))
        elif plan_id:
            cursor.execute("SELECT linked_product_id, plan_name, price FROM plans WHERE id = ?", (plan_id,))
            p = cursor.fetchone()
            if p:
                cursor.execute("""
                    INSERT INTO quotation_lines (quotation_id, product_id, description, quantity, unit_price, tax_percent, total_amount)
                    VALUES (?, ?, ?, 1, ?, 18.0, ?)
                """, (q_id, p['linked_product_id'], f"Plan: {p['plan_name']}", p['price'], total_amount))

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CREATE', 'quotation', ?, ?)
        """, (q_num, f"Quotation {q_num} created for total ₹{total_amount:,.2f}."))

        return jsonify({
            "success": True,
            "message": f"Quotation {q_num} created.",
            "quotation_id": q_id,
            "quotation_number": q_num
        }), 201

@quotations_bp.route('/<int:q_id>/confirm', methods=['POST'])
def confirm_quotation_and_create_subscription(q_id):
    """
    Confirms quotation and generates linked Subscription!
    """
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM quotations WHERE id = ?", (q_id,))
        quote = cursor.fetchone()
        if not quote:
            return jsonify({"success": False, "error": "Quotation not found"}), 404

        # Update quotation status
        cursor.execute("UPDATE quotations SET status = 'confirmed' WHERE id = ?", (q_id,))

        # Generate Subscription
        from routes.subscriptions import generate_sub_number
        sub_num = generate_sub_number(cursor)
        today = datetime.date.today()
        plan_id = quote['plan_id']
        
        freq = 'monthly'
        if plan_id:
            cursor.execute("SELECT billing_frequency FROM plans WHERE id = ?", (plan_id,))
            p = cursor.fetchone()
            if p:
                freq = p['billing_frequency']

        next_billing = calculate_next_billing_date(today, freq).strftime("%Y-%m-%d")
        exp_date = (today + datetime.timedelta(days=365)).strftime("%Y-%m-%d")

        cursor.execute("""
            INSERT INTO subscriptions (
                subscription_number, customer_id, plan_id, quotation_id, start_date,
                expiry_date, next_billing_date, payment_terms, billing_frequency,
                subtotal, tax_amount, discount_amount, total_amount, status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CONFIRMED', ?)
        """, (
            sub_num, quote['customer_id'], plan_id or 1, q_id,
            today.strftime("%Y-%m-%d"), exp_date, next_billing,
            quote['payment_terms'], freq, quote['subtotal'], quote['tax_amount'],
            quote['discount_amount'], quote['total_amount'], f"Generated from confirmed quotation {quote['quotation_number']}"
        ))
        sub_id = cursor.lastrowid

        # Copy lines
        cursor.execute("SELECT * FROM quotation_lines WHERE quotation_id = ?", (q_id,))
        lines = cursor.fetchall()
        for l in lines:
            cursor.execute("""
                INSERT INTO subscription_lines (subscription_id, product_id, description, quantity, unit_price, tax_percent, total_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (sub_id, l['product_id'], l['description'], l['quantity'], l['unit_price'], l['tax_percent'], l['total_amount']))

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CONFIRM', 'quotation', ?, ?)
        """, (quote['quotation_number'], f"Quotation confirmed! Spawned subscription {sub_num} in CONFIRMED status."))

        return jsonify({
            "success": True,
            "message": f"Quotation confirmed and converted into Subscription {sub_num}.",
            "subscription_id": sub_id,
            "subscription_number": sub_num
        })

@quotations_bp.route('/<int:q_id>/duplicate', methods=['POST'])
def duplicate_quotation(q_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM quotations WHERE id = ?", (q_id,))
        quote = cursor.fetchone()
        if not quote:
            return jsonify({"success": False, "error": "Quotation not found"}), 404

        new_num = generate_quotation_number(cursor)
        exp_date = (datetime.date.today() + datetime.timedelta(days=30)).strftime("%Y-%m-%d")

        cursor.execute("""
            INSERT INTO quotations (
                quotation_number, customer_id, plan_id, template_name, expiration_date,
                payment_terms, subtotal, discount_amount, tax_amount, total_amount, status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?)
        """, (
            new_num, quote['customer_id'], quote['plan_id'], quote['template_name'],
            exp_date, quote['payment_terms'], quote['subtotal'], quote['discount_amount'],
            quote['tax_amount'], quote['total_amount'], f"Duplicated from {quote['quotation_number']}"
        ))
        new_id = cursor.lastrowid

        cursor.execute("SELECT * FROM quotation_lines WHERE quotation_id = ?", (q_id,))
        lines = cursor.fetchall()
        for l in lines:
            cursor.execute("""
                INSERT INTO quotation_lines (quotation_id, product_id, description, quantity, unit_price, tax_percent, total_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (new_id, l['product_id'], l['description'], l['quantity'], l['unit_price'], l['tax_percent'], l['total_amount']))

        return jsonify({"success": True, "message": f"Quotation duplicated as {new_num}.", "new_id": new_id})

@quotations_bp.route('/<int:q_id>/cancel', methods=['POST'])
def cancel_quotation(q_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE quotations SET status = 'cancelled' WHERE id = ?", (q_id,))
        return jsonify({"success": True, "message": "Quotation cancelled."})
