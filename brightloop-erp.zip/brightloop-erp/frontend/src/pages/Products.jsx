import React, { useState, useEffect } from 'react';
import { 
  Package, 
  Plus, 
  Search, 
  Tag, 
  Layers, 
  Edit, 
  Trash2, 
  Check, 
  Image as ImageIcon,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [createModal, setCreateModal] = useState(false);
  const [selectedProd, setSelectedProd] = useState(null);

  // Form state
  const [prodForm, setProdForm] = useState({
    name: '',
    product_type: 'subscription',
    sales_price: '',
    cost_price: '',
    description: '',
    image_url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&q=80',
    brand: 'Brightloop Edition',
    variant_name: 'Standard Edition',
    additional_price: 0
  });

  const toast = useToast();

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const res = await api.getProducts({ type: typeFilter, search: searchTerm });
      if (res.success) {
        setProducts(res.products || []);
      }
    } catch (e) {
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [typeFilter, searchTerm]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        name: prodForm.name,
        product_type: prodForm.product_type,
        sales_price: parseFloat(prodForm.sales_price) || 0,
        cost_price: parseFloat(prodForm.cost_price) || 0,
        description: prodForm.description,
        image_url: prodForm.image_url,
        variants: [
          {
            variant_name: prodForm.variant_name || 'Standard',
            brand: prodForm.brand || 'Standard',
            additional_price: parseFloat(prodForm.additional_price) || 0
          }
        ]
      };

      const res = await api.createProduct(payload);
      if (res.success) {
        toast.success(res.message);
        setCreateModal(false);
        setProdForm({
          name: '',
          product_type: 'subscription',
          sales_price: '',
          cost_price: '',
          description: '',
          image_url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&q=80',
          brand: 'Brightloop Edition',
          variant_name: 'Standard Edition',
          additional_price: 0
        });
        fetchProducts();
      }
    } catch (err) {
      toast.error(err.message || 'Creation failed');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to deactivate this product?')) return;
    try {
      const res = await api.deleteProduct(id);
      if (res.success) {
        toast.success(res.message);
        fetchProducts();
      }
    } catch (e) {
      toast.error('Deactivation failed');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Package className="w-6 h-6 text-brand-600" />
            <span>Product Catalog & Variants</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Subscription software, services, and hardware with attribute brand variants (Odoo product.template)
          </p>
        </div>

        <button
          onClick={() => setCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
        >
          <Plus className="w-4 h-4" />
          <span>New Product</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto text-xs">
          {[
            { id: '', label: 'All Products' },
            { id: 'subscription', label: 'Subscription Services' },
            { id: 'service', label: 'Professional Services' },
            { id: 'physical', label: 'Physical Appliances' }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setTypeFilter(t.id)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                typeFilter === t.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search products, descriptions..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-100/80 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
          />
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-400">Loading product catalog...</div>
        ) : products.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-400">No products found.</div>
        ) : (
          products.map((prod) => (
            <div key={prod.id} className="erp-card overflow-hidden flex flex-col justify-between group">
              <div>
                {/* Product Image Header */}
                <div className="h-40 w-full overflow-hidden relative bg-slate-100">
                  <img
                    src={prod.image_url || 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&q=80'}
                    alt={prod.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 right-3">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase shadow-sm ${
                      prod.product_type === 'subscription' ? 'bg-indigo-600 text-white' :
                      prod.product_type === 'service' ? 'bg-emerald-600 text-white' :
                      'bg-slate-800 text-white'
                    }`}>
                      {prod.product_type}
                    </span>
                  </div>
                </div>

                {/* Details */}
                <div className="p-5 space-y-3">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base group-hover:text-brand-600 transition-colors">
                      {prod.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {prod.description}
                    </p>
                  </div>

                  {/* Pricing */}
                  <div className="flex items-baseline justify-between pt-2 border-t border-slate-100">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">Base Price</span>
                      <p className="text-lg font-black text-slate-900 font-mono">{formatCurrency(prod.sales_price)}</p>
                    </div>
                    {prod.cost_price > 0 && (
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-semibold">Cost</span>
                        <p className="text-xs font-mono text-slate-500">{formatCurrency(prod.cost_price)}</p>
                      </div>
                    )}
                  </div>

                  {/* Variants pill list */}
                  {(prod.variants || []).length > 0 && (
                    <div className="pt-2 border-t border-slate-100 space-y-1.5">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Available Variants & Brands:</p>
                      <div className="space-y-1">
                        {prod.variants.map((v) => (
                          <div key={v.id} className="flex items-center justify-between text-xs p-1.5 bg-slate-50 rounded-lg">
                            <div>
                              <span className="font-semibold text-slate-800">{v.variant_name}</span>
                              <span className="text-[10px] text-purple-600 ml-1.5 font-bold">({v.brand})</span>
                            </div>
                            <span className="font-mono font-bold text-slate-900">{formatCurrency(v.final_price)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[10px] text-slate-400 font-mono">ID: #{prod.id}</span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleDelete(prod.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-white transition-colors"
                    title="Deactivate product"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Create Product Modal */}
      {createModal && (
        <Modal
          isOpen={createModal}
          onClose={() => setCreateModal(false)}
          title="Create New ERP Product"
          subtitle="Add software subscription, professional service or physical appliance"
          maxWidth="max-w-xl"
        >
          <form onSubmit={handleCreate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Product Name</label>
              <input
                type="text"
                value={prodForm.name}
                onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })}
                placeholder="e.g. Business Software Cloud"
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Product Type</label>
                <select
                  value={prodForm.product_type}
                  onChange={(e) => setProdForm({ ...prodForm, product_type: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="subscription">Subscription</option>
                  <option value="service">Service</option>
                  <option value="physical">Physical Product</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Sales Price (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={prodForm.sales_price}
                  onChange={(e) => setProdForm({ ...prodForm, sales_price: e.target.value })}
                  placeholder="2000"
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Cost Price (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={prodForm.cost_price}
                  onChange={(e) => setProdForm({ ...prodForm, cost_price: e.target.value })}
                  placeholder="500"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Description</label>
              <textarea
                value={prodForm.description}
                onChange={(e) => setProdForm({ ...prodForm, description: e.target.value })}
                placeholder="Key features, SLAs, user limits..."
                rows="2"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium resize-none"
              />
            </div>

            {/* Variant / Brand Initial Config */}
            <div className="p-3 bg-purple-50/70 border border-purple-100 rounded-xl space-y-2 text-xs">
              <p className="font-bold text-purple-900 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                <span>Default Variant & Brand Attribute:</span>
              </p>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] text-purple-700 font-semibold block mb-0.5">Variant Tier</label>
                  <input
                    type="text"
                    value={prodForm.variant_name}
                    onChange={(e) => setProdForm({ ...prodForm, variant_name: e.target.value })}
                    placeholder="Premium / Pro"
                    className="w-full px-2 py-1 bg-white border border-purple-200 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-purple-700 font-semibold block mb-0.5">Brand Attribute</label>
                  <input
                    type="text"
                    value={prodForm.brand}
                    onChange={(e) => setProdForm({ ...prodForm, brand: e.target.value })}
                    placeholder="Odoo Brand / Enterprise"
                    className="w-full px-2 py-1 bg-white border border-purple-200 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-purple-700 font-semibold block mb-0.5">Addl. Price (₹)</label>
                  <input
                    type="number"
                    value={prodForm.additional_price}
                    onChange={(e) => setProdForm({ ...prodForm, additional_price: e.target.value })}
                    placeholder="560"
                    className="w-full px-2 py-1 bg-white border border-purple-200 rounded-lg text-xs font-mono font-bold"
                  />
                </div>
              </div>
              <p className="text-[10px] text-purple-700 italic">
                Example: Base ₹{prodForm.sales_price || 0} + Addl. ₹{prodForm.additional_price || 0} = Final Variant Price: {formatCurrency((parseFloat(prodForm.sales_price) || 0) + (parseFloat(prodForm.additional_price) || 0))}
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCreateModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
              >
                Save Product
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
