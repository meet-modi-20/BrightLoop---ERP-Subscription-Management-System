# Brightloop ERP – Subscription Management System
> **Odoo Hackathon 2026 Prototype**  
> A Modern, Interactive Enterprise Subscription Management ERP Web Application demonstrating the complete lifecycle of a SaaS recurring revenue business.

---

## 🌟 Executive Summary

**Brightloop ERP** is an enterprise-grade prototype designed to replicate and extend Odoo's native subscription and recurring invoicing capabilities. It bridges sales proposals, recurring contract management, automated billing schedules (`ir.cron`), tax accounting, payment matching, and customer self-service into an intuitive experience styled with inspiration from **Odoo ERP, Stripe Dashboard, and Linear**.

All pricing and financial figures are rendered in **Indian Rupees (INR ₹)**.

---

## 🚀 Key Implemented Modules & Features

### 1. Authentication & Role-Based Access Control (RBAC)
- **Multi-Role RBAC**:
  - **ADMIN**: Complete system access, product catalog, subscription plans, automated discount rules, staff management, full billing audit, reports, and system settings.
  - **STAFF**: Operational access for customer management, quotations, subscription lifecycle actions, invoice generation, and payment matching. Restricted from administrative discount rules and settings.
  - **CUSTOMER**: Dedicated client portal interface with personal active subscriptions, upcoming billing dates, tax invoice inspection, and self-service requests (pause, cancellation, renewal).
- **Security Validation**:
  - Enforces minimum 9 characters, at least 1 uppercase letter, 1 lowercase letter, and 1 special character (`[!@#$%^&*...]`).
  - Real-time password strength progress meter.
  - Password visibility toggle (`Eye` / `EyeOff`) and "Remember me for 30 days".
- **Instant Demo Switcher**:
  - One-click demo sign-in buttons on the login screen for **Admin**, **Staff**, and **Customer**.
  - Header role pill allowing judges to switch active roles instantly without logging out.

### 2. Executive Analytics Dashboard
- **8 Live Financial KPI Summary Cards**:
  - Total Customers
  - Active Subscriptions
  - **MRR (Monthly Recurring Revenue)**: Dynamically normalized across daily (`×30`), weekly (`×4.333`), monthly (`×1`), and yearly (`÷12`) subscriptions.
  - **ARR (Annual Recurring Revenue)**: Computed as `MRR × 12`.
  - Total Collected Revenue
  - Pending Receivables
  - Overdue Invoices (count & amount)
  - Upcoming Contract Renewals (next 30 days)
- **Interactive Recharts Visualizations**:
  - **Monthly Revenue Area Chart**: Revenue trend over the last 6 months with custom gradient fills and tooltips.
  - **Subscription Growth Line Chart**: Active subscribers vs new additions progression.
  - **Revenue by Plan Pie Chart**: MRR contribution breakdown by tier.
  - **Invoice Payment Status Distribution Bar Chart**: Visual breakdown of Paid, Confirmed, Overdue, and Cancelled invoices.
- **Audit & Quick Actions**:
  - **"Generate Due Invoices"** button directly on the dashboard to trigger the recurring billing engine.
  - Date range filters: `Today`, `Last 7 Days`, `Last 30 Days`, `Last 12 Months`.
  - Recent Subscriptions, Recent Payments, Upcoming Renewals, and Overdue Invoices tables.
  - System activity timeline complying with `mail.tracking.value`.

### 3. Subscription Management (Core Lifecycle Engine)
- **Unique Contract Numbers**: Auto-generated format: `SUB-2026-0001`.
- **Contract Lifecycle State Machine**:
  - `DRAFT` ➔ `QUOTATION` ➔ `CONFIRMED` ➔ `ACTIVE` ➔ `PAUSED` ➔ `CLOSED` / `EXPIRED`.
- **Lifecycle Actions**:
  - **Convert to Quotation**: Advances initial draft into formal quote.
  - **Confirm Quotation**: Validates contract line allocations and customer acceptance.
  - **Activate**: Calculates contract start date and computes exact `next_billing_date`.
  - **Pause**: Halts recurring invoice generation with customer-provided hold reason.
  - **Resume**: Re-enables recurring billing schedule from current date.
  - **Renew**: Extends contract expiration date by 1 calendar year.
  - **Close**: Voluntary or involuntary contract termination with cancellation reason.
  - **Manual Invoice**: On-demand invoice generation for individual contracts.
- **Detailed 360° Subscription Page**:
  - Client Dossier & GSTIN information.
  - Plan pricing and recurrence specs.
  - Line items breakdown with 18% GST calculation.
  - Complete invoice history generated for the contract.
  - Remittances matched against contract invoices.
  - Visual audit trail log with timestamps.

### 4. Automatic Recurring Billing Engine (`ir.cron` Equivalent)
- **Automated Billing Engine (`services/billing_engine.py`)**:
  - Evaluates all `ACTIVE` subscriptions where `next_billing_date <= today`.
  - **Duplicate Prevention**: Strictly verifies that an invoice has not already been generated for that subscription and billing period.
  - Computes subtotal, promotional discounts, and applicable GST (18%).
  - Generates tax invoice `INV-2026-XXXX`.
  - Advances subscription's `next_billing_date` based on billing frequency (Daily, Weekly, Monthly, Yearly).
  - Emits in-app notification to the customer and logs audit trail.
- **Batch Action**:
  - Admin button **"Generate Due Invoices"** executes the engine across all contracts and returns detailed generation metrics.

### 5. Quotation Management
- **Quotation System**:
  - Format: `QT-2026-0001`.
  - Supports proposal templates (Standard SaaS, Enterprise Custom SLA, Startup Accelerator).
  - Discount lines and payment terms (`Immediate Payment`, `Net 15 Days`, `Net 30 Days`).
  - **1-Click Conversion**: Confirming a quotation immediately spawns a linked `sale.order` subscription in `CONFIRMED` status.
  - Quotation duplication and cancellation workflows.

### 6. Invoice & Tax Receipt Management
- **Enterprise Invoices**:
  - Format: `INV-2026-0001`.
  - Statuses: `Draft`, `Confirmed`, `Paid`, `Overdue`, `Cancelled`.
  - Multi-line tax invoice layout showing Subtotal, CGST (9%), SGST (9%), Promotional Discounts, and Grand Total.
  - **Print / PDF Layout**: CSS `@media print` clean layout for printing or saving official PDF receipts.
  - Partial payments support: tracks `amount_paid` and maintains real-time `balance_due`.

### 7. Payment Tracking & Remittance Reconciliation
- **Payment Records**:
  - Format: `PAY-2026-0001`.
  - Payment methods: **UPI (GPay / PhonePe / Paytm)**, **Bank Transfer (NEFT / RTGS / IMPS)**, **Credit/Debit Card**, **Online Gateway**, and **Cash/Cheque**.
  - Direct invoice reconciliation: entering partial or full payment updates invoice `amount_paid`. If `amount_paid >= grand_total`, invoice is marked `PAID`.
  - Method-based analytics and audit notes.

### 8. Product & Variant Catalog
- **Products**:
  - Types: **Subscription**, **Service**, and **Physical Product**.
  - Sales price, cost price, description, image URL, and active status.
- **Variants & Attributes**:
  - Configurable attributes (e.g. Brand: "Odoo Brand", "Enterprise Brand", "Standard").
  - Dynamic additional price addition (e.g. Base ₹2,000 + Odoo Brand ₹560 = Final ₹2,560).
  - SKU tracking.

### 9. Subscription Plan Management
- **Flexible Recurrence**: Daily, Weekly, Monthly, and Yearly frequencies.
- **Card & Table Views**: Attractive cards with pricing breakdown, subscriber counts, and policy checklists.
- **Policy Toggles**: Allow Pause, Allow Renewal, Allow Early Closure, and Auto-Close flags.

### 10. Promotional Discount Rules Engine
- **Discount Rules**:
  - Types: **Percentage (%)** or **Fixed Amount (₹)**.
  - Restrictions: Minimum purchase amount, minimum seats, validity date range, and maximum redemptions limit.
  - Real-time redemption progress bar.
  - Automatically evaluated by the recurring billing engine.

### 11. Customer Self-Service Portal
- Client dashboard with active subscriptions, upcoming billing dates, total paid, and outstanding balance.
- Client action requests: **Request Pause**, **Request Cancellation**, **Request Renewal**.
- Self-service invoice downloading and remittance history.
- Strict data isolation ensuring customers only see their own records.

### 12. Executive Reporting & CSV Export
- 6 Dedicated Reports:
  1. **Subscription Report**: Contract status, dates, recurrence, and value.
  2. **Revenue Report**: Monthly gross collected funds.
  3. **Payment Report**: Remittance references, methods, and customer entities.
  4. **Outstanding Receivables Report**: Aging open balances.
  5. **Overdue Invoices Report**: Overdue balances requiring collections.
  6. **Plan Performance & Cohorts**: Plan subscribers and MRR contribution.
- **CSV Export**: Direct one-click CSV generation for all reports.

### 13. In-App Notification Center
- Bell icon in header with unread count badge.
- Real-time notifications for: recurring invoice generated, payment received, subscription activated, and upcoming billings.
- Mark individual or all notifications as read.

---

## 🏛️ Odoo Hackathon 2026 Architecture Alignment

Brightloop was engineered to demonstrate a clean 1-to-1 correspondence with native Odoo 17 & 18 Enterprise/Community applications.

| Brightloop Module | Brightloop Table | Native Odoo Model | Odoo Field / Logic Equivalent |
| :--- | :--- | :--- | :--- |
| **Customers / Contacts** | `customers` | `res.partner` | `name`, `email`, `phone`, `parent_id`, `street`, `vat` (GSTIN), `property_payment_term_id` |
| **Products & Catalog** | `products` | `product.template` | `name`, `detailed_type` (`service`/`consu`), `list_price`, `recurring_invoice=True` |
| **Variants & Attributes** | `product_variants` | `product.product` | `product_tmpl_id`, `attribute_line_ids`, `price_extra`, `default_code` |
| **Subscription Plans** | `plans` | `sale.subscription.plan` | `name`, `billing_period_unit` (`months`/`years`), `pricing_ids`, `user_closable` |
| **Subscriptions** | `subscriptions` | `sale.order` (`is_subscription=True`) | `partner_id`, `plan_id`, `start_date`, `next_invoice_date`, `subscription_state` |
| **Subscription Lines** | `subscription_lines` | `sale.order.line` | `order_id`, `product_id`, `product_uom_qty`, `price_unit`, `tax_id` |
| **Quotations** | `quotations` | `sale.order` (`state='draft'`) | `partner_id`, `validity_date`, `payment_term_id`, `action_confirm()` |
| **Invoices** | `invoices` | `account.move` (`move_type='out_invoice'`) | `partner_id`, `invoice_date`, `invoice_date_due`, `payment_state`, `line_ids` |
| **Payments** | `payments` | `account.payment` | `partner_id`, `amount`, `payment_method_line_id`, `reconciled_invoice_ids` |
| **Recurring Engine** | `services/billing_engine.py` | `ir.cron` | Scheduled action calling `sale.subscription._cron_recurring_create_invoices()` |
| **Audit Log** | `activity_logs` | `mail.tracking.value` / `mail.message` | Field audit trails and message chatter |
| **User Access** | `users` | `res.users` / `res.groups` | `group_system` (Admin), `group_sale_salesman` (Staff), `group_portal` (Customer) |

An interactive **"Odoo Blueprint"** modal is accessible directly from the application header and sidebar, presenting live mappings, Odoo Python extension snippets, and exportable JSON-RPC payloads.

---

## 🔑 Demo Login Credentials

The database is pre-seeded with realistic enterprise data. You can log in manually or click any demo preset button on the login screen:

| Role | Email Address | Password | Permissions & Scope |
| :--- | :--- | :--- | :--- |
| **ADMIN** | `admin@brightloop.com` | `Admin@123!` | Complete access across all modules, products, plans, discounts, settings, and billing engine. |
| **STAFF** | `staff@brightloop.com` | `Staff@123!` | Manages customers, creates quotations, activates subscriptions, generates invoices, and records payments. Restricted from discount rule creation and settings. |
| **CUSTOMER** | `customer@brightloop.com` | `Customer@123!` | Self-service portal access for Vikram Patel (Nexus Software Systems). Views own subscriptions, tax receipts, and submits renewal/pause requests. |

*(Additional customer accounts: `aarav@techlabs.in`, `meera@fintechprime.co`, `kavita@swiggyenterprise.com`, `rajesh@razorcloud.io` - password: `Customer@123!`)*

---

## 💻 Tech Stack

- **Frontend**: React.js (v18), Vite (v6), Tailwind CSS (v3), Lucide React Icons, Recharts (v2).
- **Backend**: Python 3, Flask 3, RESTful APIs, SQLite 3 (relational schema configured with foreign keys and indexes for easy PostgreSQL migration).
- **Architecture**: Modular Python service layer (`billing_engine.py`, `odoo_mapping.py`), decoupled React component tree, centralized token client.

---

## 🛠️ Installation & Running Locally

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm

### Option 1: Unified Single-Server Mode (Recommended)
The Flask backend is configured to serve both the REST API and the production-built React frontend from port **5000**.

1. **Navigate to the backend directory**:
   ```powershell
   cd "C:\Users\Meet Modi\.gemini\antigravity\scratch\brightloop-erp\backend"
   ```

2. **Run database migrations & seed data**:
   ```powershell
   python seed_data.py
   ```

3. **Start the Brightloop server**:
   ```powershell
   python app.py
   ```

4. **Open your browser**:
   Visit: **[http://localhost:5000](http://localhost:5000)**

---

### Option 2: Development Mode (Vite Dev Server + Flask API)
For active frontend development with Hot Module Replacement (HMR):

1. **Start the Flask Backend API (Port 5000)**:
   ```powershell
   cd "C:\Users\Meet Modi\.gemini\antigravity\scratch\brightloop-erp\backend"
   python app.py
   ```

2. **In a second terminal, start the Vite Dev Server (Port 5173)**:
   ```powershell
   cd "C:\Users\Meet Modi\.gemini\antigravity\scratch\brightloop-erp\frontend"
   npm run dev
   ```

3. **Open your browser**:
   Visit: **[http://localhost:5173](http://localhost:5173)** (API requests are automatically proxied to port 5000).

---

### Running the Automated Test Suite
To verify all 6 end-to-end enterprise workflows:
```powershell
cd "C:\Users\Meet Modi\.gemini\antigravity\scratch\brightloop-erp\backend"
python -m unittest test_workflows.py
```

Expected output:
```
......
----------------------------------------------------------------------
Ran 6 tests in 1.70s

OK
```

---

## 📋 Implemented Feature Matrix

| Requirement Area | Status | Implementation Details |
| :--- | :---: | :--- |
| **Design System** | ✅ Complete | Deep navy sidebar, purple/blue primary accents, clean cards, responsive layout, status badges. |
| **Authentication & RBAC** | ✅ Complete | Admin, Staff, Customer roles, password rules validation, visibility toggle, demo credentials pills. |
| **Admin Dashboard** | ✅ Complete | 8 summary cards (MRR, ARR, etc.), 4 Recharts graphs, 4 date range filters, recent tables. |
| **Product Management** | ✅ Complete | Subscription, Service, Physical products with brand attributes and calculated variant pricing. |
| **Plan Management** | ✅ Complete | Daily, weekly, monthly, yearly recurrence, card & table view, pause/renewal policy flags. |
| **Subscription Lifecycle** | ✅ Complete | Full state machine: Draft ➔ Quotation ➔ Confirmed ➔ Active ➔ Paused ➔ Renewed ➔ Closed. |
| **Quotation Management** | ✅ Complete | Creation, templates, duplication, and direct 1-click conversion to live subscriptions. |
| **Recurring Billing Engine** | ✅ Complete | `generate_due_invoices` detects due dates, computes GST/discounts, updates next billing date, prevents duplicate invoices. |
| **Invoice Management** | ✅ Complete | Unique numbers (`INV-2026-XXXX`), professional printable tax receipt layout, send, confirm, cancel. |
| **Payment Reconciliation** | ✅ Complete | UPI, Bank Transfer, Card, Cash methods. Partial payments track remaining invoice balances. |
| **Discount Rule Engine** | ✅ Complete | Admin-only fixed/percentage discounts with usage thresholds and date boundaries. |
| **Customer Portal** | ✅ Complete | Separate self-service view for active subscriptions, tax receipts, and pause/renewal requests. |
| **Analytics & Reports** | ✅ Complete | 6 specialized reports, KPI metrics, dynamic tables, and CSV exports. |
| **Notification Center** | ✅ Complete | In-app alerts for renewals, invoices, activations, and payments with unread badge. |
| **Odoo ERP Alignment** | ✅ Complete | Native Odoo 17/18 models (`res.partner`, `sale.order`, `account.move`, `ir.cron`) with live schema viewer. |

---

## 🔮 Production Roadmap & Odoo Module Packaging

1. **Native Odoo Addon (`brightloop_subscription`)**:
   - Package the schema into an Odoo Python module with XML views and security access rules (`ir.model.access.csv`).
2. **PostgreSQL Migration**:
   - Switch database connection string from SQLite to PostgreSQL 16+ with row-level security.
3. **Payment Gateway Webhooks**:
   - Integrate live Razorpay / Stripe webhook endpoints for automated reconciliation of instant UPI and card mandates.
4. **Automated Dunning Management**:
   - Automated email reminder escalation sequence for overdue invoices past 7, 14, and 30 days.

---

*Brightloop ERP – Built with pride for the Odoo Hackathon 2026.*
