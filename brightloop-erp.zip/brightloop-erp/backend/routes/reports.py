import csv
import io
import datetime
from flask import Blueprint, request, jsonify, Response
from database import get_db

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/analytics', methods=['GET'])
def get_analytics():
    report_type = request.args.get('type', 'subscription')
    status_filter = request.args.get('status')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    with get_db() as conn:
        cursor = conn.cursor()

        # Overall Key Performance Indicators (KPIs)
        cursor.execute("""
            SELECT s.total_amount, s.billing_frequency, p.billing_frequency as plan_freq
            FROM subscriptions s
            JOIN plans p ON s.plan_id = p.id
            WHERE s.status = 'ACTIVE'
        """)
        active_subs = cursor.fetchall()
        mrr = 0.0
        for sub in active_subs:
            freq = sub['billing_frequency'] or sub['plan_freq'] or 'monthly'
            amt = sub['total_amount'] or 0.0
            if freq == 'monthly':
                mrr += amt
            elif freq == 'weekly':
                mrr += amt * 4.333
            elif freq == 'daily':
                mrr += amt * 30.0
            elif freq == 'yearly':
                mrr += amt / 12.0
        mrr = round(mrr, 2)
        arr = round(mrr * 12.0, 2)

        # Outstanding Revenue
        cursor.execute("""
            SELECT COALESCE(SUM(grand_total - amount_paid), 0.0) as outstanding
            FROM invoices
            WHERE payment_status IN ('confirmed', 'overdue')
        """)
        outstanding_rev = round(cursor.fetchone()['outstanding'], 2)

        # Overdue Invoices
        today_str = datetime.date.today().strftime("%Y-%m-%d")
        cursor.execute("""
            SELECT COUNT(*) as count, COALESCE(SUM(grand_total - amount_paid), 0.0) as amount
            FROM invoices
            WHERE payment_status = 'overdue' OR (payment_status = 'confirmed' AND due_date < ?)
        """, (today_str,))
        overdue_data = dict(cursor.fetchone())

        # Now fetch specific report dataset
        data_rows = []
        if report_type == 'subscription':
            cursor.execute("""
                SELECT s.subscription_number, c.name as customer_name, c.company, p.plan_name,
                       s.start_date, s.expiry_date, s.next_billing_date, s.billing_frequency,
                       s.total_amount, s.status
                FROM subscriptions s
                JOIN customers c ON s.customer_id = c.id
                JOIN plans p ON s.plan_id = p.id
                ORDER BY s.id DESC
            """)
            data_rows = [dict(r) for r in cursor.fetchall()]

        elif report_type == 'revenue':
            cursor.execute("""
                SELECT strftime('%Y-%m', p.payment_date) as month,
                       COUNT(p.id) as transaction_count,
                       COALESCE(SUM(p.amount), 0.0) as total_collected
                FROM payments p
                WHERE p.status = 'completed'
                GROUP BY month
                ORDER BY month DESC
            """)
            data_rows = [dict(r) for r in cursor.fetchall()]

        elif report_type == 'payments':
            cursor.execute("""
                SELECT p.payment_reference, p.payment_date, c.name as customer_name,
                       inv.invoice_number, p.payment_method, p.amount, p.status
                FROM payments p
                JOIN customers c ON p.customer_id = c.id
                JOIN invoices inv ON p.invoice_id = inv.id
                ORDER BY p.id DESC
            """)
            data_rows = [dict(r) for r in cursor.fetchall()]

        elif report_type == 'outstanding':
            cursor.execute("""
                SELECT inv.invoice_number, c.name as customer_name, c.company,
                       inv.invoice_date, inv.due_date, inv.grand_total, inv.amount_paid,
                       (inv.grand_total - inv.amount_paid) as balance_due, inv.payment_status
                FROM invoices inv
                JOIN customers c ON inv.customer_id = c.id
                WHERE inv.payment_status IN ('confirmed', 'overdue')
                ORDER BY inv.due_date ASC
            """)
            data_rows = [dict(r) for r in cursor.fetchall()]

        elif report_type == 'overdue':
            cursor.execute("""
                SELECT inv.invoice_number, c.name as customer_name, c.company, c.phone,
                       inv.invoice_date, inv.due_date, (inv.grand_total - inv.amount_paid) as balance_due
                FROM invoices inv
                JOIN customers c ON inv.customer_id = c.id
                WHERE inv.payment_status = 'overdue' OR (inv.payment_status = 'confirmed' AND inv.due_date < ?)
                ORDER BY inv.due_date ASC
            """, (today_str,))
            data_rows = [dict(r) for r in cursor.fetchall()]

        elif report_type == 'plan_performance':
            cursor.execute("""
                SELECT p.id, p.plan_name, p.billing_frequency, p.price,
                       COUNT(s.id) as subscriber_count,
                       COALESCE(SUM(CASE WHEN s.status = 'ACTIVE' THEN s.total_amount ELSE 0 END), 0.0) as active_revenue
                FROM plans p
                LEFT JOIN subscriptions s ON p.id = s.plan_id
                GROUP BY p.id
                ORDER BY active_revenue DESC
            """)
            data_rows = [dict(r) for r in cursor.fetchall()]

        return jsonify({
            "success": True,
            "kpis": {
                "mrr": mrr,
                "arr": arr,
                "outstanding_revenue": outstanding_rev,
                "overdue_count": overdue_data['count'],
                "overdue_amount": round(overdue_data['amount'], 2)
            },
            "report_type": report_type,
            "data": data_rows
        })

@reports_bp.route('/export', methods=['GET'])
def export_csv():
    report_type = request.args.get('type', 'subscription')

    output = io.StringIO()
    writer = csv.writer(output)

    with get_db() as conn:
        cursor = conn.cursor()

        if report_type == 'subscription':
            writer.writerow(['Subscription #', 'Customer Name', 'Company', 'Plan', 'Start Date', 'Expiry Date', 'Next Billing Date', 'Frequency', 'Total Amount (INR)', 'Status'])
            cursor.execute("""
                SELECT s.subscription_number, c.name, c.company, p.plan_name, s.start_date, s.expiry_date, s.next_billing_date, s.billing_frequency, s.total_amount, s.status
                FROM subscriptions s
                JOIN customers c ON s.customer_id = c.id
                JOIN plans p ON s.plan_id = p.id
                ORDER BY s.id DESC
            """)
            for r in cursor.fetchall():
                writer.writerow(list(r))

        elif report_type == 'payments':
            writer.writerow(['Payment Ref', 'Date', 'Customer Name', 'Invoice #', 'Method', 'Amount (INR)', 'Status'])
            cursor.execute("""
                SELECT p.payment_reference, p.payment_date, c.name, inv.invoice_number, p.payment_method, p.amount, p.status
                FROM payments p
                JOIN customers c ON p.customer_id = c.id
                JOIN invoices inv ON p.invoice_id = inv.id
                ORDER BY p.id DESC
            """)
            for r in cursor.fetchall():
                writer.writerow(list(r))

        else: # Invoices
            writer.writerow(['Invoice #', 'Customer Name', 'Company', 'Invoice Date', 'Due Date', 'Grand Total (INR)', 'Amount Paid (INR)', 'Status'])
            cursor.execute("""
                SELECT inv.invoice_number, c.name, c.company, inv.invoice_date, inv.due_date, inv.grand_total, inv.amount_paid, inv.payment_status
                FROM invoices inv
                JOIN customers c ON inv.customer_id = c.id
                ORDER BY inv.id DESC
            """)
            for r in cursor.fetchall():
                writer.writerow(list(r))

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename=brightloop_{report_type}_report.csv"}
    )
