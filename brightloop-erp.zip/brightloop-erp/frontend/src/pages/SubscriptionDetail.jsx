import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Repeat, 
  Calendar, 
  User, 
  Building, 
  CreditCard, 
  Clock, 
  Receipt, 
  Play, 
  Pause, 
  RotateCw, 
  XCircle, 
  Zap, 
  FileCheck, 
  History, 
  CheckCircle2,
  AlertTriangle,
  ChevronRight
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import ConfirmDialog from '../components/ConfirmDialog';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function SubscriptionDetail({ id, onBack, setCurrentView, setSelectedId }) {
  const [sub, setSub] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  
  // Dialogs
  const [pauseModal, setPauseModal] = useState(false);
  const [closeModal, setCloseModal] = useState(false);
  const [reason, setReason] = useState('');
  
  const toast = useToast();

  const fetchDetail = async () => {
    setLoading(true);
    try {
      const res = await api.getSubscription(id);
      if (res.success) {
        setSub(res.subscription);
      }
    } catch (e) {
      toast.error('Failed to load subscription details');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) fetchDetail();
  }, [id]);

  const handleAction = async (actionFn, ...args) => {
    setActionLoading(true);
    try {
      const res = await actionFn(sub.id, ...args);
      if (res.success) {
        toast.success(res.message);
        fetchDetail();
      }
    } catch (e) {
      toast.error(e.message || 'Action failed');
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return <div className="p-12 text-center text-slate-400">Loading subscription {id}...</div>;
  }

  if (!sub) {
    return (
      <div className="p-12 text-center space-y-3">
        <p className="text-slate-600 font-bold">Subscription not found.</p>
        <button onClick={onBack} className="text-xs text-brand-600 font-semibold underline">Go back</button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Header & Actions Bar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl font-extrabold text-slate-900 font-mono tracking-tight">{sub.subscription_number}</h1>
              <StatusBadge status={sub.status} />
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Client: <span className="font-semibold text-slate-800">{sub.customer_name}</span> ({sub.customer_company})
            </p>
          </div>
        </div>

        {/* Dynamic Action Buttons based on Lifecycle state */}
        <div className="flex items-center gap-2 flex-wrap">
          {sub.status === 'DRAFT' && (
            <button
              onClick={() => handleAction(api.convertQuotation)}
              disabled={actionLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              <FileCheck className="w-4 h-4" />
              <span>Convert to Quotation</span>
            </button>
          )}

          {sub.status === 'QUOTATION' && (
            <button
              onClick={() => handleAction(api.confirmSubscription)}
              disabled={actionLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm Quotation</span>
            </button>
          )}

          {sub.status === 'CONFIRMED' && (
            <button
              onClick={() => handleAction(api.activateSubscription)}
              disabled={actionLoading}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Activate Subscription</span>
            </button>
          )}

          {sub.status === 'ACTIVE' && (
            <>
              <button
                onClick={() => handleAction(api.manualGenerateInvoice)}
                disabled={actionLoading}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-brand-50 hover:bg-brand-100 text-brand-700 border border-brand-200 rounded-xl text-xs font-bold transition-all"
              >
                <Zap className="w-3.5 h-3.5 text-brand-600" />
                <span>Generate Invoice</span>
              </button>

              <button
                onClick={() => { setReason(''); setPauseModal(true); }}
                disabled={actionLoading}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-xl text-xs font-bold transition-all"
              >
                <Pause className="w-3.5 h-3.5 text-purple-600" />
                <span>Pause</span>
              </button>

              <button
                onClick={() => handleAction(api.renewSubscription)}
                disabled={actionLoading}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Renew</span>
              </button>

              <button
                onClick={() => { setReason(''); setCloseModal(true); }}
                disabled={actionLoading}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition-all"
              >
                <XCircle className="w-3.5 h-3.5 text-rose-600" />
                <span>Close</span>
              </button>
            </>
          )}

          {sub.status === 'PAUSED' && (
            <button
              onClick={() => handleAction(api.resumeSubscription)}
              disabled={actionLoading}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Resume Active Billing</span>
            </button>
          )}

          {['CLOSED', 'EXPIRED'].includes(sub.status) && (
            <button
              onClick={() => handleAction(api.renewSubscription)}
              disabled={actionLoading}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              <RotateCw className="w-4 h-4" />
              <span>Reactivate / Renew Contract</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Details & Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Contract Info, Product Lines, Invoices */}
        <div className="lg:col-span-2 space-y-6">
          {/* Key Contract Summary Banner */}
          <div className="erp-card p-5">
            <h3 className="font-bold text-slate-900 text-sm mb-4">Subscription Plan & Billing Specs</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-slate-400 font-medium">Assigned Plan</p>
                <p className="font-bold text-slate-900 text-sm mt-0.5">{sub.plan_name}</p>
                <span className="text-[10px] text-brand-600 uppercase font-semibold">{sub.billing_frequency} recurring</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-slate-400 font-medium">Next Billing Date</p>
                <p className="font-bold text-emerald-700 text-sm mt-0.5 font-mono">{formatDate(sub.next_billing_date)}</p>
                <span className="text-[10px] text-slate-400">Recurring scheduler trigger</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-slate-400 font-medium">Recurring Total</p>
                <p className="font-bold text-slate-900 text-sm mt-0.5">{formatCurrency(sub.total_amount)}</p>
                <span className="text-[10px] text-slate-400">Incl. 18% GST</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-slate-400 font-medium">Start Date</p>
                <p className="font-semibold text-slate-800 mt-0.5">{formatDate(sub.start_date)}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-slate-400 font-medium">Expiration Date</p>
                <p className="font-semibold text-slate-800 mt-0.5">{formatDate(sub.expiry_date)}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-slate-400 font-medium">Payment Terms</p>
                <p className="font-semibold text-slate-800 mt-0.5">{sub.payment_terms || 'Net 15 Days'}</p>
              </div>
            </div>

            {sub.notes && (
              <div className="mt-4 p-3 bg-amber-50/70 border border-amber-200/60 rounded-xl text-xs text-amber-900">
                <span className="font-bold">Contract Notes: </span>
                <span>{sub.notes}</span>
              </div>
            )}
          </div>

          {/* Subscription Product Lines */}
          <div className="erp-card p-5">
            <h3 className="font-bold text-slate-900 text-sm mb-3">Subscription Line Allocations</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-semibold uppercase text-[10px]">
                    <th className="pb-2">Product Description</th>
                    <th className="pb-2">Qty</th>
                    <th className="pb-2">Unit Price</th>
                    <th className="pb-2">Taxes</th>
                    <th className="pb-2 text-right">Line Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {(sub.lines || []).map((line, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-2.5">
                        <p className="font-semibold text-slate-900">{line.product_name || line.description}</p>
                        {line.variant_name && (
                          <p className="text-[10px] text-purple-600 font-medium">{line.brand} - {line.variant_name}</p>
                        )}
                      </td>
                      <td className="py-2.5 text-slate-700 font-medium">{line.quantity}</td>
                      <td className="py-2.5 text-slate-700 font-mono">{formatCurrency(line.unit_price)}</td>
                      <td className="py-2.5 text-slate-500 font-mono">{line.tax_percent}% GST</td>
                      <td className="py-2.5 text-right font-bold text-slate-900 font-mono">{formatCurrency(line.total_amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Subtotals & Taxes breakdown */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
              <div className="w-64 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-500">
                  <span>Subtotal:</span>
                  <span className="font-mono text-slate-800">{formatCurrency(sub.subtotal)}</span>
                </div>
                {sub.discount_amount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-medium">
                    <span>Discount Applied:</span>
                    <span className="font-mono">- {formatCurrency(sub.discount_amount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-500">
                  <span>GST (18%):</span>
                  <span className="font-mono text-slate-800">{formatCurrency(sub.tax_amount)}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 pt-2 border-t border-slate-200 text-sm">
                  <span>Cycle Amount:</span>
                  <span className="font-mono text-brand-600">{formatCurrency(sub.total_amount)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Related Invoices History */}
          <div className="erp-card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-brand-600" />
                <h3 className="font-bold text-slate-900 text-sm">Recurring Invoices Generated</h3>
              </div>
              <span className="text-xs text-slate-400">{sub.invoices?.length || 0} invoice(s)</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-semibold uppercase text-[10px]">
                    <th className="pb-2">Invoice #</th>
                    <th className="pb-2">Invoice Date</th>
                    <th className="pb-2">Due Date</th>
                    <th className="pb-2">Grand Total</th>
                    <th className="pb-2">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {(sub.invoices || []).length === 0 ? (
                    <tr>
                      <td colSpan="5" className="py-4 text-center text-slate-400">No invoices generated yet.</td>
                    </tr>
                  ) : (
                    sub.invoices.map((inv) => (
                      <tr
                        key={inv.id}
                        onClick={() => {
                          setSelectedId(inv.invoice_number);
                          setCurrentView('invoice_detail');
                        }}
                        className="hover:bg-slate-50 cursor-pointer"
                      >
                        <td className="py-2.5 font-mono font-bold text-brand-600 hover:underline">{inv.invoice_number}</td>
                        <td className="py-2.5 text-slate-600">{formatDate(inv.invoice_date)}</td>
                        <td className="py-2.5 text-slate-600">{formatDate(inv.due_date)}</td>
                        <td className="py-2.5 font-bold text-slate-900 font-mono">{formatCurrency(inv.grand_total)}</td>
                        <td className="py-2.5"><StatusBadge status={inv.payment_status} /></td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Customer Dossier & Activity Timeline */}
        <div className="space-y-6">
          {/* Customer CRM card */}
          <div className="erp-card p-5">
            <h3 className="font-bold text-slate-900 text-sm mb-3 flex items-center gap-2">
              <User className="w-4 h-4 text-brand-600" />
              <span>Customer Information</span>
            </h3>
            <div className="space-y-2 text-xs">
              <div>
                <p className="text-slate-400 text-[10px] uppercase font-semibold">Contact Person</p>
                <p className="font-bold text-slate-900 text-sm">{sub.customer_name}</p>
              </div>
              <div>
                <p className="text-slate-400 text-[10px] uppercase font-semibold">Company / Entity</p>
                <p className="font-semibold text-slate-800">{sub.customer_company || 'Independent Enterprise'}</p>
              </div>
              <div>
                <p className="text-slate-400 text-[10px] uppercase font-semibold">Email</p>
                <p className="text-brand-600 font-medium">{sub.customer_email}</p>
              </div>
              {sub.customer_phone && (
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-semibold">Phone</p>
                  <p className="text-slate-700">{sub.customer_phone}</p>
                </div>
              )}
              {sub.customer_tax_id && (
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-semibold">GSTIN / Tax ID</p>
                  <p className="font-mono text-slate-800">{sub.customer_tax_id}</p>
                </div>
              )}
              {sub.customer_address && (
                <div>
                  <p className="text-slate-400 text-[10px] uppercase font-semibold">Billing Address</p>
                  <p className="text-slate-600 leading-relaxed">{sub.customer_address}</p>
                </div>
              )}
            </div>
          </div>

          {/* Activity Log / Timeline */}
          <div className="erp-card p-5">
            <h3 className="font-bold text-slate-900 text-sm mb-4 flex items-center gap-2">
              <History className="w-4 h-4 text-purple-600" />
              <span>Audit Trail Timeline</span>
            </h3>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {(sub.timeline || []).length === 0 ? (
                <p className="text-xs text-slate-400">No events logged yet.</p>
              ) : (
                sub.timeline.map((item, idx) => (
                  <div key={idx} className="flex gap-3 text-xs relative">
                    <div className="w-2 h-2 rounded-full bg-brand-500 mt-1.5 shrink-0 ring-4 ring-brand-100" />
                    <div>
                      <p className="font-semibold text-slate-900">{item.action}: {item.description}</p>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5 font-mono">
                        <span>{item.user_name}</span>
                        <span>•</span>
                        <span>{new Date(item.created_at).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Pause Modal */}
      {pauseModal && (
        <Modal
          isOpen={pauseModal}
          onClose={() => setPauseModal(false)}
          title="Pause Subscription"
          subtitle={`Temporarily hold recurring billing for ${sub.subscription_number}`}
          maxWidth="max-w-md"
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-600">
              Pausing will stop automatic recurring invoice generation until explicitly resumed.
            </p>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Reason for Pause</label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Server maintenance, seasonal hiatus..."
                rows="3"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium resize-none"
              />
            </div>
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setPauseModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setPauseModal(false);
                  handleAction(api.pauseSubscription, reason);
                }}
                className="px-4 py-1.5 bg-purple-600 text-white rounded-xl text-xs font-bold"
              >
                Confirm Pause
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Close Modal */}
      {closeModal && (
        <Modal
          isOpen={closeModal}
          onClose={() => setCloseModal(false)}
          title="Terminate / Close Subscription"
          subtitle={`Permanently close contract ${sub.subscription_number}`}
          maxWidth="max-w-md"
        >
          <div className="space-y-4">
            <p className="text-xs text-rose-600 font-semibold">
              Warning: Closing this subscription will mark the contract as terminated and discontinue automated renewals.
            </p>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Cancellation Reason</label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Customer migrated, contract finished..."
                rows="3"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium resize-none"
              />
            </div>
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setCloseModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setCloseModal(false);
                  handleAction(api.closeSubscription, reason);
                }}
                className="px-4 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-bold"
              >
                Close Contract
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
