import React, { useState, useEffect } from 'react';
import { 
  Receipt, 
  Search, 
  Filter, 
  Calendar, 
  Plus, 
  Zap, 
  Download, 
  Printer, 
  CheckCircle2, 
  ChevronRight,
  Clock,
  AlertTriangle,
  CreditCard
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Invoices({ setCurrentView, setSelectedId, openRecordPaymentModal }) {
  const [invoices, setInvoices] = useState([]);
  const [summary, setSummary] = useState({});
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [generating, setGenerating] = useState(false);

  const toast = useToast();

  const fetchInvoices = async () => {
    setLoading(true);
    try {
      const res = await api.getInvoices({ status: statusFilter, search: searchTerm });
      if (res.success) {
        setInvoices(res.invoices || []);
        setSummary(res.summary || {});
      }
    } catch (e) {
      toast.error('Failed to load invoices');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, [statusFilter, searchTerm]);

  const handleGenerateDue = async () => {
    setGenerating(true);
    try {
      const res = await api.generateDueInvoices();
      if (res.success) {
        toast.success(res.message);
        fetchInvoices();
      }
    } catch (err) {
      toast.error(err.message || 'Generation failed');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Receipt className="w-6 h-6 text-brand-600" />
            <span>Customer Invoices & Billing</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Automated recurring invoices, tax schedules, accounts receivable, and settlement status
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleGenerateDue}
            disabled={generating}
            className="flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all active:scale-98 disabled:opacity-60"
          >
            <Zap className={`w-4 h-4 ${generating ? 'animate-spin' : 'fill-white'}`} />
            <span>{generating ? 'Running...' : 'Generate Due Invoices'}</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Total Billed</p>
          <p className="text-lg font-bold text-slate-900 mt-0.5">{formatCurrency(summary.total_amount || 0)}</p>
          <span className="text-[10px] text-slate-500">{summary.total_count || 0} invoices</span>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Total Collected</p>
          <p className="text-lg font-bold text-emerald-700 mt-0.5">{formatCurrency(summary.total_paid || 0)}</p>
          <span className="text-[10px] text-emerald-600 font-semibold">{summary.paid_count || 0} settled</span>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Outstanding Receivable</p>
          <p className="text-lg font-bold text-amber-700 mt-0.5">
            {formatCurrency(Math.max(0, (summary.total_amount || 0) - (summary.total_paid || 0)))}
          </p>
          <span className="text-[10px] text-slate-500">Confirmed balance</span>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs">
          <p className="text-[10px] font-bold uppercase text-slate-400">Overdue Invoices</p>
          <p className="text-lg font-bold text-rose-700 mt-0.5">{summary.overdue_count || 0}</p>
          <span className="text-[10px] text-rose-600 font-semibold">Requires follow-up</span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
        {/* Status Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 text-xs">
          {['ALL', 'CONFIRMED', 'PAID', 'OVERDUE', 'DRAFT', 'CANCELLED'].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                statusFilter === s
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search invoice #, customer..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-100/80 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
          />
        </div>
      </div>

      {/* Table */}
      <div className="erp-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Invoice #</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Linked Subscription</th>
                <th className="py-3 px-4">Invoice Date</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4">Grand Total</th>
                <th className="py-3 px-4">Balance Due</th>
                <th className="py-3 px-4">Payment Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan="9" className="py-8 text-center text-slate-400">Loading invoices...</td>
                </tr>
              ) : invoices.length === 0 ? (
                <tr>
                  <td colSpan="9" className="py-12 text-center text-slate-400">No invoices found.</td>
                </tr>
              ) : (
                invoices.map((inv) => {
                  const bal = Math.max(0, inv.grand_total - inv.amount_paid);
                  return (
                    <tr
                      key={inv.id}
                      onClick={() => {
                        setSelectedId(inv.invoice_number);
                        setCurrentView('invoice_detail');
                      }}
                      className="hover:bg-slate-50/80 cursor-pointer transition-colors group"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-brand-600 group-hover:underline">
                        {inv.invoice_number}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-bold text-slate-900">{inv.customer_name}</p>
                        <p className="text-[10px] text-slate-400">{inv.customer_company}</p>
                      </td>
                      <td className="py-3 px-4">
                        {inv.subscription_number ? (
                          <span className="font-mono text-[11px] text-indigo-600 font-semibold bg-indigo-50 px-2 py-0.5 rounded">
                            {inv.subscription_number}
                          </span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-600 font-mono">{formatDate(inv.invoice_date)}</td>
                      <td className="py-3 px-4 text-slate-600 font-mono">{formatDate(inv.due_date)}</td>
                      <td className="py-3 px-4 font-bold text-slate-900 font-mono">{formatCurrency(inv.grand_total)}</td>
                      <td className="py-3 px-4 font-mono font-semibold">
                        <span className={bal > 0 ? 'text-amber-700' : 'text-slate-400'}>
                          {formatCurrency(bal)}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge status={inv.payment_status} type="invoice" />
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                          {bal > 0 && inv.payment_status !== 'cancelled' && (
                            <button
                              onClick={() => {
                                if (openRecordPaymentModal) openRecordPaymentModal(inv);
                              }}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold rounded-lg text-[11px] border border-emerald-200 transition-colors flex items-center gap-1"
                              title="Record Customer Payment"
                            >
                              <CreditCard className="w-3 h-3" />
                              <span>Pay</span>
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setSelectedId(inv.invoice_number);
                              setCurrentView('invoice_detail');
                            }}
                            className="p-1.5 text-slate-400 hover:text-brand-600 rounded-lg hover:bg-slate-100"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
