from flask import Blueprint, request, jsonify
from database import get_db

plans_bp = Blueprint('plans', __name__)

@plans_bp.route('', methods=['GET'])
def list_plans():
    freq = request.args.get('frequency')
    active_only = request.args.get('active', 'true').lower() == 'true'
    search = request.args.get('search', '').strip()

    query = """
        SELECT p.*, pr.name as linked_product_name, pr.sales_price as product_base_price,
               (SELECT COUNT(*) FROM subscriptions s WHERE s.plan_id = p.id AND s.status = 'ACTIVE') as active_subscriber_count
        FROM plans p
        LEFT JOIN products pr ON p.linked_product_id = pr.id
        WHERE 1=1
    """
    params = []

    if active_only:
        query += " AND p.active = 1"

    if freq:
        query += " AND p.billing_frequency = ?"
        params.append(freq.lower())

    if search:
        query += " AND (p.plan_name LIKE ? OR p.description LIKE ?)"
        wild = f"%{search}%"
        params.extend([wild, wild])

    query += " ORDER BY p.id ASC"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        plans = [dict(p) for p in cursor.fetchall()]
        return jsonify({"success": True, "count": len(plans), "plans": plans})

@plans_bp.route('/<int:plan_id>', methods=['GET'])
def get_plan(plan_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.*, pr.name as linked_product_name
            FROM plans p
            LEFT JOIN products pr ON p.linked_product_id = pr.id
            WHERE p.id = ?
        """, (plan_id,))
        plan = cursor.fetchone()
        if not plan:
            return jsonify({"success": False, "error": "Plan not found"}), 404

        return jsonify({"success": True, "plan": dict(plan)})

@plans_bp.route('', methods=['POST'])
def create_plan():
    data = request.get_json() or {}
    plan_name = data.get('plan_name', '').strip()
    linked_product_id = data.get('linked_product_id')
    description = data.get('description', '')
    price = float(data.get('price', 0.0))
    billing_frequency = data.get('billing_frequency', 'monthly').lower()
    min_quantity = int(data.get('min_quantity', 1))
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    auto_close = 1 if data.get('auto_close') else 0
    allow_early_closure = 1 if data.get('allow_early_closure', True) else 0
    allow_pause = 1 if data.get('allow_pause', True) else 0
    allow_renewal = 1 if data.get('allow_renewal', True) else 0

    if not plan_name or price <= 0:
        return jsonify({"success": False, "error": "Plan name and valid price are required."}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO plans (
                plan_name, linked_product_id, description, price, billing_frequency,
                min_quantity, start_date, end_date, auto_close, allow_early_closure,
                allow_pause, allow_renewal, active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        """, (
            plan_name, linked_product_id, description, price, billing_frequency,
            min_quantity, start_date, end_date, auto_close, allow_early_closure,
            allow_pause, allow_renewal
        ))
        plan_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CREATE', 'plan', ?, ?)
        """, (str(plan_id), f"Plan '{plan_name}' ({billing_frequency}) created for ₹{price:,.2f}."))

        return jsonify({"success": True, "message": "Subscription plan created.", "plan_id": plan_id}), 201

@plans_bp.route('/<int:plan_id>', methods=['PUT'])
def update_plan(plan_id):
    data = request.get_json() or {}
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM plans WHERE id = ?", (plan_id,))
        if not cursor.fetchone():
            return jsonify({"success": False, "error": "Plan not found"}), 404

        cursor.execute("""
            UPDATE plans
            SET plan_name = COALESCE(?, plan_name),
                linked_product_id = COALESCE(?, linked_product_id),
                description = COALESCE(?, description),
                price = COALESCE(?, price),
                billing_frequency = COALESCE(?, billing_frequency),
                min_quantity = COALESCE(?, min_quantity),
                allow_pause = COALESCE(?, allow_pause),
                allow_renewal = COALESCE(?, allow_renewal),
                active = COALESCE(?, active)
            WHERE id = ?
        """, (
            data.get('plan_name'), data.get('linked_product_id'), data.get('description'),
            data.get('price'), data.get('billing_frequency'), data.get('min_quantity'),
            data.get('allow_pause'), data.get('allow_renewal'), data.get('active'), plan_id
        ))

        return jsonify({"success": True, "message": "Plan updated successfully."})

@plans_bp.route('/<int:plan_id>/archive', methods=['POST'])
def archive_plan(plan_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE plans SET active = CASE WHEN active = 1 THEN 0 ELSE 1 END WHERE id = ?", (plan_id,))
        return jsonify({"success": True, "message": "Plan status toggled."})
