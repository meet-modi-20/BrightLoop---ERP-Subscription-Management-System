import sqlite3
import os
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "brightloop.db")

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

@contextmanager
def get_db():
    conn = get_db_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with get_db() as conn:
        cursor = conn.cursor()
        
        # 1. Users table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT CHECK(role IN ('admin', 'staff', 'customer')) NOT NULL DEFAULT 'customer',
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 2. Customers (Odoo res.partner equivalent)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            company TEXT,
            address TEXT,
            city TEXT,
            state TEXT,
            country TEXT DEFAULT 'India',
            postal_code TEXT,
            tax_id TEXT,
            payment_terms TEXT DEFAULT 'Immediate Payment',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        );
        """)

        # 3. Staff table (Odoo hr.employee / internal user)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS staff (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            department TEXT DEFAULT 'Subscription Ops',
            role_title TEXT DEFAULT 'Operations Specialist',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        """)

        # 4. Products (Odoo product.template)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            product_type TEXT CHECK(product_type IN ('subscription', 'service', 'physical')) NOT NULL DEFAULT 'subscription',
            sales_price REAL NOT NULL DEFAULT 0.0,
            cost_price REAL NOT NULL DEFAULT 0.0,
            description TEXT,
            image_url TEXT,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 5. Product Variants (Odoo product.product)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS product_variants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            variant_name TEXT NOT NULL,
            brand TEXT DEFAULT 'Brightloop Edition',
            additional_price REAL NOT NULL DEFAULT 0.0,
            final_price REAL NOT NULL DEFAULT 0.0,
            sku TEXT UNIQUE,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        """)

        # 6. Plans (Odoo sale.subscription.plan)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plan_name TEXT NOT NULL,
            linked_product_id INTEGER,
            description TEXT,
            price REAL NOT NULL DEFAULT 0.0,
            billing_frequency TEXT CHECK(billing_frequency IN ('daily', 'weekly', 'monthly', 'yearly')) NOT NULL DEFAULT 'monthly',
            min_quantity INTEGER NOT NULL DEFAULT 1,
            start_date DATE,
            end_date DATE,
            auto_close INTEGER NOT NULL DEFAULT 0,
            allow_early_closure INTEGER NOT NULL DEFAULT 1,
            allow_pause INTEGER NOT NULL DEFAULT 1,
            allow_renewal INTEGER NOT NULL DEFAULT 1,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (linked_product_id) REFERENCES products(id) ON DELETE SET NULL
        );
        """)

        # 7. Quotations (Odoo sale.order in draft/sent state)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS quotations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quotation_number TEXT UNIQUE NOT NULL,
            customer_id INTEGER NOT NULL,
            plan_id INTEGER,
            template_name TEXT DEFAULT 'Standard SaaS Agreement',
            expiration_date DATE,
            payment_terms TEXT DEFAULT 'Net 15 Days',
            subtotal REAL NOT NULL DEFAULT 0.0,
            discount_amount REAL NOT NULL DEFAULT 0.0,
            tax_amount REAL NOT NULL DEFAULT 0.0,
            total_amount REAL NOT NULL DEFAULT 0.0,
            status TEXT CHECK(status IN ('draft', 'sent', 'confirmed', 'cancelled')) NOT NULL DEFAULT 'draft',
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
            FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE SET NULL
        );
        """)

        # 8. Quotation Lines (Odoo sale.order.line)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS quotation_lines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quotation_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            variant_id INTEGER,
            description TEXT,
            quantity INTEGER NOT NULL DEFAULT 1,
            unit_price REAL NOT NULL DEFAULT 0.0,
            tax_percent REAL NOT NULL DEFAULT 18.0,
            discount_percent REAL NOT NULL DEFAULT 0.0,
            total_amount REAL NOT NULL DEFAULT 0.0,
            FOREIGN KEY (quotation_id) REFERENCES quotations(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE SET NULL
        );
        """)

        # 9. Subscriptions (Odoo sale.subscription / sale.order recurring)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subscription_number TEXT UNIQUE NOT NULL,
            customer_id INTEGER NOT NULL,
            plan_id INTEGER NOT NULL,
            quotation_id INTEGER,
            start_date DATE NOT NULL,
            expiry_date DATE,
            next_billing_date DATE NOT NULL,
            payment_terms TEXT DEFAULT 'Net 15 Days',
            billing_frequency TEXT NOT NULL DEFAULT 'monthly',
            subtotal REAL NOT NULL DEFAULT 0.0,
            tax_amount REAL NOT NULL DEFAULT 0.0,
            discount_amount REAL NOT NULL DEFAULT 0.0,
            total_amount REAL NOT NULL DEFAULT 0.0,
            status TEXT CHECK(status IN ('DRAFT', 'QUOTATION', 'CONFIRMED', 'ACTIVE', 'PAUSED', 'CLOSED', 'EXPIRED')) NOT NULL DEFAULT 'DRAFT',
            auto_renew INTEGER NOT NULL DEFAULT 1,
            cancellation_reason TEXT,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
            FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE RESTRICT,
            FOREIGN KEY (quotation_id) REFERENCES quotations(id) ON DELETE SET NULL
        );
        """)

        # 10. Subscription Lines
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS subscription_lines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subscription_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            variant_id INTEGER,
            description TEXT,
            quantity INTEGER NOT NULL DEFAULT 1,
            unit_price REAL NOT NULL DEFAULT 0.0,
            tax_percent REAL NOT NULL DEFAULT 18.0,
            total_amount REAL NOT NULL DEFAULT 0.0,
            FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE SET NULL
        );
        """)

        # 11. Invoices (Odoo account.move type='out_invoice')
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS invoices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_number TEXT UNIQUE NOT NULL,
            customer_id INTEGER NOT NULL,
            subscription_id INTEGER,
            quotation_id INTEGER,
            invoice_date DATE NOT NULL,
            due_date DATE NOT NULL,
            billing_period_start DATE,
            billing_period_end DATE,
            subtotal REAL NOT NULL DEFAULT 0.0,
            discount_amount REAL NOT NULL DEFAULT 0.0,
            tax_amount REAL NOT NULL DEFAULT 0.0,
            grand_total REAL NOT NULL DEFAULT 0.0,
            amount_paid REAL NOT NULL DEFAULT 0.0,
            payment_status TEXT CHECK(payment_status IN ('draft', 'confirmed', 'paid', 'overdue', 'cancelled')) NOT NULL DEFAULT 'draft',
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
            FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE SET NULL,
            FOREIGN KEY (quotation_id) REFERENCES quotations(id) ON DELETE SET NULL
        );
        """)

        # 12. Invoice Lines (Odoo account.move.line)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS invoice_lines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id INTEGER NOT NULL,
            product_id INTEGER,
            description TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            unit_price REAL NOT NULL DEFAULT 0.0,
            tax_percent REAL NOT NULL DEFAULT 18.0,
            line_total REAL NOT NULL DEFAULT 0.0,
            FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
        );
        """)

        # 13. Discounts (Odoo loyalty.program / coupon)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS discounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            code TEXT UNIQUE,
            discount_type TEXT CHECK(discount_type IN ('fixed', 'percentage')) NOT NULL DEFAULT 'percentage',
            discount_value REAL NOT NULL DEFAULT 0.0,
            min_purchase REAL NOT NULL DEFAULT 0.0,
            min_quantity INTEGER NOT NULL DEFAULT 1,
            start_date DATE,
            end_date DATE,
            max_usage INTEGER NOT NULL DEFAULT 100,
            current_usage INTEGER NOT NULL DEFAULT 0,
            applicable_products TEXT DEFAULT 'ALL',
            applicable_subscriptions TEXT DEFAULT 'ALL',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 14. Discount Usage
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS discount_usage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            discount_id INTEGER NOT NULL,
            customer_id INTEGER NOT NULL,
            invoice_id INTEGER NOT NULL,
            discount_amount REAL NOT NULL,
            used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (discount_id) REFERENCES discounts(id) ON DELETE CASCADE,
            FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
            FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
        );
        """)

        # 15. Payments (Odoo account.payment)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payment_reference TEXT UNIQUE NOT NULL,
            customer_id INTEGER NOT NULL,
            invoice_id INTEGER NOT NULL,
            payment_method TEXT CHECK(payment_method IN ('cash', 'bank_transfer', 'upi', 'card', 'online')) NOT NULL DEFAULT 'upi',
            amount REAL NOT NULL DEFAULT 0.0,
            payment_date DATE NOT NULL,
            notes TEXT,
            status TEXT CHECK(status IN ('completed', 'pending', 'failed')) NOT NULL DEFAULT 'completed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
            FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
        );
        """)

        # 16. In-App Notifications (Odoo mail.message / activity)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            category TEXT DEFAULT 'general',
            is_read INTEGER NOT NULL DEFAULT 0,
            link TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        """)

        # 17. Activity Logs / Audit Trail (Odoo mail.tracking.value)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            user_name TEXT,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT,
            description TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 18. System Settings
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # Create Indexes for high-performance lookup & subscription lifecycle
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_subs_customer ON subscriptions(customer_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_subs_status ON subscriptions(status);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_subs_next_billing ON subscriptions(next_billing_date);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(payment_status);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_invoices_sub ON invoices(subscription_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_payments_invoice ON payments(invoice_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notifs_user ON notifications(user_id, is_read);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_activity_logs ON activity_logs(created_at DESC);")

if __name__ == '__main__':
    init_db()
    print("Brightloop database initialized successfully.")
