import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, ArrowRight, ShieldCheck, UserCheck, Users, Sparkles } from 'lucide-react';
import { useAuth, DEMO_ACCOUNTS } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function Login({ onSwitchToRegister }) {
  const { login } = useAuth();
  const toast = useToast();

  const [email, setEmail] = useState('admin@brightloop.com');
  const [password, setPassword] = useState('Admin@123!');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [forgotModal, setForgotModal] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Please enter both email and password.');
      return;
    }

    setLoading(true);
    try {
      const user = await login(email, password);
      toast.success(`Welcome back, ${user.name}!`);
    } catch (err) {
      toast.error(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (roleKey) => {
    const acc = DEMO_ACCOUNTS[roleKey];
    if (acc) {
      setEmail(acc.email);
      setPassword(acc.password);
      toast.info(`Filled demo credentials for ${acc.role}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center items-center p-4 relative overflow-hidden">
      {/* Background glowing effects */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-brand-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md relative z-10">
        {/* Brand Logo & Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-brand-600 via-indigo-500 to-purple-500 text-white font-extrabold text-2xl shadow-xl shadow-brand-500/20 mb-3">
            BL
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Brightloop ERP</h1>
          <p className="text-xs text-slate-400 mt-1">Enterprise Subscription Management & Recurring Billing</p>
          <div className="inline-flex items-center gap-1.5 mt-2 px-2.5 py-1 rounded-full bg-slate-800/80 border border-slate-700/60 text-[11px] text-purple-300">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Odoo Hackathon 2026 Prototype</span>
          </div>
        </div>

        {/* Quick Demo Credentials Bar */}
        <div className="bg-slate-800/80 backdrop-blur-md rounded-2xl p-3 border border-slate-700/80 mb-4 shadow-lg">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 text-center mb-2">
            Instant Demo Sign-in
          </p>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => fillDemo('admin')}
              className="flex flex-col items-center gap-1 p-2 rounded-xl bg-slate-900/60 hover:bg-indigo-950/60 border border-slate-700 hover:border-indigo-500/50 text-slate-300 hover:text-white transition-all text-xs group"
            >
              <ShieldCheck className="w-4 h-4 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span className="font-semibold text-[11px]">Admin</span>
            </button>
            <button
              type="button"
              onClick={() => fillDemo('staff')}
              className="flex flex-col items-center gap-1 p-2 rounded-xl bg-slate-900/60 hover:bg-emerald-950/60 border border-slate-700 hover:border-emerald-500/50 text-slate-300 hover:text-white transition-all text-xs group"
            >
              <UserCheck className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span className="font-semibold text-[11px]">Staff</span>
            </button>
            <button
              type="button"
              onClick={() => fillDemo('customer')}
              className="flex flex-col items-center gap-1 p-2 rounded-xl bg-slate-900/60 hover:bg-purple-950/60 border border-slate-700 hover:border-purple-500/50 text-slate-300 hover:text-white transition-all text-xs group"
            >
              <Users className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
              <span className="font-semibold text-[11px]">Customer</span>
            </button>
          </div>
        </div>

        {/* Main Login Card */}
        <div className="bg-slate-800/90 backdrop-blur-xl rounded-2xl border border-slate-700 p-6 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@brightloop.com"
                  required
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">Password</label>
                <button
                  type="button"
                  onClick={() => setForgotModal(true)}
                  className="text-xs text-brand-400 hover:text-brand-300 font-medium"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="•••••••••"
                  required
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-900/80 border border-slate-700 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1 text-slate-400 hover:text-slate-200 absolute right-3 top-1/2 -translate-y-1/2"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded bg-slate-900 border-slate-700 text-brand-600 focus:ring-brand-500 focus:ring-offset-slate-900"
                />
                <span>Remember me for 30 days</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold tracking-wide shadow-lg shadow-brand-500/25 flex items-center justify-center gap-2 transition-all mt-2"
            >
              <span>{loading ? 'Authenticating...' : 'Sign In to Brightloop'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-slate-700/80 text-center">
            <p className="text-xs text-slate-400">
              New client onboarding?{' '}
              <button
                type="button"
                onClick={onSwitchToRegister}
                className="text-brand-400 hover:text-brand-300 font-bold transition-colors"
              >
                Create Customer Account
              </button>
            </p>
          </div>
        </div>
      </div>

      {/* Forgot Password Dialog */}
      {forgotModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl p-6 max-w-sm w-full text-slate-300 space-y-3">
            <h3 className="font-bold text-white text-base">Password Reset Information</h3>
            <p className="text-xs text-slate-400">
              In this hackathon prototype environment, predefined demo accounts are managed via seed data. Please use:
            </p>
            <div className="p-3 bg-slate-900 rounded-xl font-mono text-xs space-y-1 text-slate-300 border border-slate-700">
              <p><span className="text-indigo-400">Admin:</span> Admin@123!</p>
              <p><span className="text-emerald-400">Staff:</span> Staff@123!</p>
              <p><span className="text-purple-400">Customer:</span> Customer@123!</p>
            </div>
            <button
              onClick={() => setForgotModal(false)}
              className="w-full py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-semibold"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
