import datetime
from flask import Blueprint, request, jsonify
from database import get_db

payments_bp = Blueprint('payments', __name__)

def generate_payment_reference(cursor):
    cursor.execute("SELECT payment_reference FROM payments ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    year = datetime.date.today().year
    if row and row['payment_reference']:
        try:
            parts = row['payment_reference'].split('-')
            seq = int(parts[-1])
            return f"PAY-{year}-{seq + 1:04d}"
        except Exception:
            pass
    return f"PAY-{year}-0001"

@payments_bp.route('', methods=['GET'])
def list_payments():
    customer_id = request.args.get('customer_id')
    invoice_id = request.args.get('invoice_id')
    method = request.args.get('method')
    search = request.args.get('search', '').strip()

    query = """
        SELECT p.*, c.name as customer_name, c.company as customer_company,
               inv.invoice_number, inv.grand_total as invoice_total
        FROM payments p
        JOIN customers c ON p.customer_id = c.id
        JOIN invoices inv ON p.invoice_id = inv.id
        WHERE 1=1
    """
    params = []

    if customer_id:
        query += " AND p.customer_id = ?"
        params.append(customer_id)

    if invoice_id:
        query += " AND p.invoice_id = ?"
        params.append(invoice_id)

    if method:
        query += " AND p.payment_method = ?"
        params.append(method.lower())

    if search:
        query += " AND (p.payment_reference LIKE ? OR c.name LIKE ? OR inv.invoice_number LIKE ?)"
        wild = f"%{search}%"
        params.extend([wild, wild, wild])

    query += " ORDER BY p.id DESC"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = [dict(r) for r in cursor.fetchall()]

        cursor.execute("""
            SELECT 
                COUNT(*) as total_count,
                COALESCE(SUM(amount), 0.0) as total_collected,
                COALESCE(SUM(CASE WHEN payment_method = 'upi' THEN amount ELSE 0 END), 0.0) as upi_total,
                COALESCE(SUM(CASE WHEN payment_method = 'bank_transfer' THEN amount ELSE 0 END), 0.0) as bank_total,
                COALESCE(SUM(CASE WHEN payment_method = 'card' THEN amount ELSE 0 END), 0.0) as card_total
            FROM payments
            WHERE status = 'completed'
        """)
        stats = dict(cursor.fetchone())

        return jsonify({
            "success": True,
            "count": len(rows),
            "stats": stats,
            "payments": rows
        })

@payments_bp.route('', methods=['POST'])
def record_payment():
    data = request.get_json() or {}
    invoice_id = data.get('invoice_id')
    amount = float(data.get('amount', 0.0))
    payment_method = data.get('payment_method', 'upi').lower()
    payment_date = data.get('payment_date') or datetime.date.today().strftime("%Y-%m-%d")
    notes = data.get('notes', '')
    status = data.get('status', 'completed')

    if not invoice_id or amount <= 0:
        return jsonify({"success": False, "error": "Valid invoice and positive amount are required."}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM invoices WHERE id = ?", (invoice_id,))
        inv = cursor.fetchone()
        if not inv:
            return jsonify({"success": False, "error": "Invoice not found."}), 404

        cid = inv['customer_id']
        pref = generate_payment_reference(cursor)

        # Record payment
        cursor.execute("""
            INSERT INTO payments (
                payment_reference, customer_id, invoice_id, payment_method,
                amount, payment_date, notes, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (pref, cid, invoice_id, payment_method, amount, payment_date, notes, status))
        payment_id = cursor.lastrowid

        # Update invoice balance and status if payment is completed
        if status == 'completed':
            new_paid = round(float(inv['amount_paid']) + amount, 2)
            grand_total = float(inv['grand_total'])
            
            new_status = 'confirmed'
            if new_paid >= grand_total:
                new_status = 'paid'
            elif new_paid > 0:
                new_status = 'confirmed'

            cursor.execute("""
                UPDATE invoices
                SET amount_paid = ?, payment_status = ?
                WHERE id = ?
            """, (new_paid, new_status, invoice_id))

            # Activity log
            cursor.execute("""
                INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
                VALUES (1, 'Admin', 'PAYMENT', 'payment', ?, ?)
            """, (pref, f"Payment {pref} of ₹{amount:,.2f} recorded for invoice {inv['invoice_number']} via {payment_method.upper()}."))

            # Customer notification
            cursor.execute("SELECT user_id FROM customers WHERE id = ?", (cid,))
            c_user = cursor.fetchone()
            if c_user and c_user['user_id']:
                cursor.execute("""
                    INSERT INTO notifications (user_id, title, message, category, link)
                    VALUES (?, 'Payment Confirmed', ?, 'payment', ?)
                """, (c_user['user_id'], f"We received your payment of ₹{amount:,.2f} for {inv['invoice_number']}.", f"/invoices/{inv['invoice_number']}"))

        return jsonify({
            "success": True,
            "message": f"Payment {pref} recorded successfully.",
            "payment_id": payment_id,
            "payment_reference": pref
        }), 201
