import React from 'react';
import { ChevronRight, Home } from 'lucide-react';

export default function Breadcrumbs({ items = [], onNavigate }) {
  return (
    <nav className="flex items-center gap-1.5 text-xs text-slate-500 mb-2">
      <button
        onClick={() => onNavigate && onNavigate('dashboard')}
        className="flex items-center gap-1 hover:text-slate-900 transition-colors"
      >
        <Home className="w-3.5 h-3.5" />
        <span>Home</span>
      </button>
      {items.map((item, index) => {
        const isLast = index === items.length - 1;
        return (
          <React.Fragment key={index}>
            <ChevronRight className="w-3 h-3 text-slate-400" />
            {isLast || !item.onClick ? (
              <span className="font-semibold text-slate-800">{item.label}</span>
            ) : (
              <button
                onClick={item.onClick}
                className="hover:text-slate-900 transition-colors"
              >
                {item.label}
              </button>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
}
