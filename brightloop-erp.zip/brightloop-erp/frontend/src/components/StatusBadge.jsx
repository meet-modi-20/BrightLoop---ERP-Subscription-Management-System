import React from 'react';

export default function StatusBadge({ status, type = 'subscription' }) {
  if (!status) return null;
  const s = status.toUpperCase();

  let styles = 'bg-slate-100 text-slate-700 border-slate-200';
  let dot = 'bg-slate-400';

  // Subscriptions
  if (s === 'ACTIVE' || s === 'PAID' || s === 'COMPLETED') {
    styles = 'bg-emerald-50 text-emerald-700 border-emerald-200/80';
    dot = 'bg-emerald-500';
  } else if (s === 'CONFIRMED') {
    styles = 'bg-blue-50 text-blue-700 border-blue-200/80';
    dot = 'bg-blue-500';
  } else if (s === 'QUOTATION' || s === 'SENT' || s === 'PENDING') {
    styles = 'bg-amber-50 text-amber-700 border-amber-200/80';
    dot = 'bg-amber-500';
  } else if (s === 'PAUSED') {
    styles = 'bg-purple-50 text-purple-700 border-purple-200/80';
    dot = 'bg-purple-500';
  } else if (s === 'OVERDUE' || s === 'CLOSED' || s === 'CANCELLED' || s === 'FAILED') {
    styles = 'bg-rose-50 text-rose-700 border-rose-200/80';
    dot = 'bg-rose-500';
  } else if (s === 'DRAFT') {
    styles = 'bg-slate-100 text-slate-600 border-slate-200';
    dot = 'bg-slate-400';
  } else if (s === 'EXPIRED') {
    styles = 'bg-zinc-100 text-zinc-600 border-zinc-300';
    dot = 'bg-zinc-400';
  }

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${styles}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
      {s}
    </span>
  );
}
