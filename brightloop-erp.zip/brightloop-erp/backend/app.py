import os
import sys
from flask import Flask, jsonify, request, send_from_directory
from database import init_db

# Import blueprints
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.subscriptions import subscriptions_bp
from routes.quotations import quotations_bp
from routes.invoices import invoices_bp
from routes.payments import payments_bp
from routes.products import products_bp
from routes.plans import plans_bp
from routes.customers import customers_bp
from routes.discounts import discounts_bp
from routes.reports import reports_bp
from routes.notifications import notifications_bp
from routes.odoo import odoo_bp

def create_app():
    # Frontend build folder path
    dist_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend", "dist")

    app = Flask(__name__, static_folder=dist_dir, static_url_path="/")
    app.config['SECRET_KEY'] = 'brightloop-odoo-hackathon-secret-key-2026'

    # Ensure DB is initialized
    init_db()

    # Universal CORS handling (no external package needed)
    @app.before_request
    def handle_preflight():
        if request.method == "OPTIONS":
            response = app.make_default_options_response()
            response.headers["Access-Control-Allow-Origin"] = "*"
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS, PATCH"
            response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-Requested-With"
            return response

    @app.after_request
    def add_cors_headers(response):
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS, PATCH"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-Requested-With"
        return response

    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    app.register_blueprint(subscriptions_bp, url_prefix='/api/subscriptions')
    app.register_blueprint(quotations_bp, url_prefix='/api/quotations')
    app.register_blueprint(invoices_bp, url_prefix='/api/invoices')
    app.register_blueprint(payments_bp, url_prefix='/api/payments')
    app.register_blueprint(products_bp, url_prefix='/api/products')
    app.register_blueprint(plans_bp, url_prefix='/api/plans')
    app.register_blueprint(customers_bp, url_prefix='/api/customers')
    app.register_blueprint(discounts_bp, url_prefix='/api/discounts')
    app.register_blueprint(reports_bp, url_prefix='/api/reports')
    app.register_blueprint(notifications_bp, url_prefix='/api/notifications')
    app.register_blueprint(odoo_bp, url_prefix='/api/odoo')

    @app.route('/api/health', methods=['GET'])
    def health_check():
        return jsonify({
            "status": "healthy",
            "service": "Brightloop Subscription Management ERP",
            "hackathon": "Odoo Hackathon 2026",
            "version": "1.0.0"
        })

    # Serve React SPA if dist exists
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve_frontend(path):
        if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
            return send_from_directory(app.static_folder, path)
        if os.path.exists(os.path.join(app.static_folder, 'index.html')):
            return send_from_directory(app.static_folder, 'index.html')
        return jsonify({
            "status": "online",
            "app": "Brightloop ERP Backend API",
            "docs": "/api/health",
            "frontend_note": "Frontend Vite dev server is running on port 5173"
        })

    return app

app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    print(f"🚀 Brightloop ERP Server starting on http://127.0.0.1:{port}")
    app.run(host='0.0.0.0', port=port, debug=False)
