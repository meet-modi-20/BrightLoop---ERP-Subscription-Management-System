import React, { useState, useEffect } from 'react';
import { 
  Repeat, 
  Plus, 
  Search, 
  Filter, 
  Calendar, 
  ArrowRight, 
  Play, 
  Pause, 
  RotateCw, 
  XCircle, 
  Receipt, 
  FileText,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Subscriptions({ setCurrentView, setSelectedId }) {
  const [subscriptions, setSubscriptions] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [createModal, setCreateModal] = useState(false);
  const [creating, setCreating] = useState(false);

  // New Subscription Form State
  const [newSub, setNewSub] = useState({
    customer_id: '',
    plan_id: '',
    quantity: 1,
    payment_terms: 'Net 15 Days',
    status: 'ACTIVE',
    notes: ''
  });

  const toast = useToast();

  const fetchSubscriptions = async () => {
    setLoading(true);
    try {
      const res = await api.getSubscriptions({ status: statusFilter, search: searchTerm });
      if (res.success) {
        setSubscriptions(res.subscriptions || []);
      }
    } catch (e) {
      toast.error('Failed to load subscriptions');
    } finally {
      setLoading(false);
    }
  };

  const loadAuxData = async () => {
    try {
      const [cRes, pRes] = await Promise.all([api.getCustomers(), api.getPlans()]);
      if (cRes.success) setCustomers(cRes.customers || []);
      if (pRes.success) setPlans(pRes.plans || []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchSubscriptions();
  }, [statusFilter, searchTerm]);

  useEffect(() => {
    loadAuxData();
  }, []);

  const handleCreateSubscription = async (e) => {
    e.preventDefault();
    if (!newSub.customer_id || !newSub.plan_id) {
      toast.error('Please select both a Customer and a Plan.');
      return;
    }

    setCreating(true);
    try {
      const res = await api.createSubscription(newSub);
      if (res.success) {
        toast.success(res.message);
        setCreateModal(false);
        setNewSub({
          customer_id: '',
          plan_id: '',
          quantity: 1,
          payment_terms: 'Net 15 Days',
          status: 'ACTIVE',
          notes: ''
        });
        fetchSubscriptions();
        if (res.subscription_number) {
          setSelectedId(res.subscription_number);
          setCurrentView('subscription_detail');
        }
      }
    } catch (err) {
      toast.error(err.message || 'Creation failed');
    } finally {
      setCreating(false);
    }
  };

  const selectedPlanObj = plans.find(p => String(p.id) === String(newSub.plan_id));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Repeat className="w-6 h-6 text-brand-600" />
            <span>Subscription Contracts</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Lifecycle management from Draft to Quotation, Confirmation, Active Billing & Renewal
          </p>
        </div>

        <button
          onClick={() => setCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Subscription</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
        {/* Status Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 text-xs">
          {['ALL', 'ACTIVE', 'CONFIRMED', 'QUOTATION', 'DRAFT', 'PAUSED', 'CLOSED', 'EXPIRED'].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                statusFilter === s
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search number, customer, plan..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-100/80 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
          />
        </div>
      </div>

      {/* Table */}
      <div className="erp-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Subscription #</th>
                <th className="py-3 px-4">Customer & Account</th>
                <th className="py-3 px-4">Plan & Cycle</th>
                <th className="py-3 px-4">Next Billing Date</th>
                <th className="py-3 px-4">Recurring Total</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-8 text-center text-slate-400">Loading subscriptions...</td>
                </tr>
              ) : subscriptions.length === 0 ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-400">
                    <p className="font-semibold text-slate-600">No subscriptions found</p>
                    <p className="text-[11px] mt-1">Try resetting your search filter or create a new contract.</p>
                  </td>
                </tr>
              ) : (
                subscriptions.map((sub) => (
                  <tr
                    key={sub.id}
                    onClick={() => {
                      setSelectedId(sub.subscription_number);
                      setCurrentView('subscription_detail');
                    }}
                    className="hover:bg-slate-50/80 cursor-pointer transition-colors group"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-brand-600 group-hover:underline">
                          {sub.subscription_number}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-slate-900">{sub.customer_name}</p>
                      <p className="text-[10px] text-slate-400">{sub.customer_company || sub.customer_email}</p>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-medium text-slate-800">{sub.plan_name}</p>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">
                        {sub.billing_frequency}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-700">
                      {formatDate(sub.next_billing_date)}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {formatCurrency(sub.total_amount)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={sub.status} />
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedId(sub.subscription_number);
                          setCurrentView('subscription_detail');
                        }}
                        className="p-1.5 text-slate-400 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition-colors"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Subscription Modal Wizard */}
      {createModal && (
        <Modal
          isOpen={createModal}
          onClose={() => setCreateModal(false)}
          title="Create New Subscription Contract"
          subtitle="Deploy a new recurring software license for a client"
          maxWidth="max-w-xl"
        >
          <form onSubmit={handleCreateSubscription} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Select Customer</label>
              <select
                value={newSub.customer_id}
                onChange={(e) => setNewSub({ ...newSub, customer_id: e.target.value })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
              >
                <option value="">-- Choose an enterprise customer --</option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.company || c.email})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Subscription Plan</label>
                <select
                  value={newSub.plan_id}
                  onChange={(e) => setNewSub({ ...newSub, plan_id: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
                >
                  <option value="">-- Select Plan --</option>
                  {plans.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.plan_name} ({formatCurrency(p.price)} / {p.billing_frequency})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Quantity (Seats / Units)</label>
                <input
                  type="number"
                  min="1"
                  value={newSub.quantity}
                  onChange={(e) => setNewSub({ ...newSub, quantity: Math.max(1, parseInt(e.target.value) || 1) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Payment Terms</label>
                <select
                  value={newSub.payment_terms}
                  onChange={(e) => setNewSub({ ...newSub, payment_terms: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="Immediate Payment">Immediate Payment</option>
                  <option value="Net 15 Days">Net 15 Days</option>
                  <option value="Net 30 Days">Net 30 Days</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Initial Status</label>
                <select
                  value={newSub.status}
                  onChange={(e) => setNewSub({ ...newSub, status: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="ACTIVE">ACTIVE (Deploy Live Immediately)</option>
                  <option value="CONFIRMED">CONFIRMED (Awaiting Deployment)</option>
                  <option value="QUOTATION">QUOTATION (Sales Stage)</option>
                  <option value="DRAFT">DRAFT</option>
                </select>
              </div>
            </div>

            {/* Price Preview Card */}
            {selectedPlanObj && (
              <div className="p-3.5 bg-indigo-50/60 border border-indigo-100 rounded-xl text-xs space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Base Unit Price:</span>
                  <span>{formatCurrency(selectedPlanObj.price)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal ({newSub.quantity} unit):</span>
                  <span>{formatCurrency(selectedPlanObj.price * newSub.quantity)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Estimated GST (18%):</span>
                  <span>{formatCurrency(selectedPlanObj.price * newSub.quantity * 0.18)}</span>
                </div>
                <div className="flex justify-between text-indigo-900 font-bold pt-1 border-t border-indigo-200 text-sm">
                  <span>Total Recurring Commitment:</span>
                  <span>{formatCurrency(selectedPlanObj.price * newSub.quantity * 1.18)}</span>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Internal Notes</label>
              <textarea
                value={newSub.notes}
                onChange={(e) => setNewSub({ ...newSub, notes: e.target.value })}
                placeholder="Contract SLAs, custom terms, or client requirements..."
                rows="2"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCreateModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={creating}
                className="px-5 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
              >
                {creating ? 'Saving...' : 'Deploy Subscription'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
