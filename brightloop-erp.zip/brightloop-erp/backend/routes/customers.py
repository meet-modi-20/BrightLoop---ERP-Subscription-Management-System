from flask import Blueprint, request, jsonify
from database import get_db

customers_bp = Blueprint('customers', __name__)

@customers_bp.route('', methods=['GET'])
def list_customers():
    search = request.args.get('search', '').strip()

    query = """
        SELECT c.*,
               (SELECT COUNT(*) FROM subscriptions s WHERE s.customer_id = c.id AND s.status = 'ACTIVE') as active_subs,
               (SELECT COALESCE(SUM(p.amount), 0.0) FROM payments p WHERE p.customer_id = c.id AND p.status = 'completed') as total_revenue,
               (SELECT COUNT(*) FROM invoices inv WHERE inv.customer_id = c.id AND inv.payment_status = 'overdue') as overdue_invoices
        FROM customers c
        WHERE 1=1
    """
    params = []

    if search:
        query += " AND (c.name LIKE ? OR c.company LIKE ? OR c.email LIKE ? OR c.city LIKE ?)"
        wild = f"%{search}%"
        params.extend([wild, wild, wild, wild])

    query += " ORDER BY c.id DESC"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        customers = [dict(c) for c in cursor.fetchall()]

        return jsonify({"success": True, "count": len(customers), "customers": customers})

@customers_bp.route('/<int:cust_id>', methods=['GET'])
def get_customer_detail(cust_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM customers WHERE id = ?", (cust_id,))
        cust = cursor.fetchone()
        if not cust:
            return jsonify({"success": False, "error": "Customer not found"}), 404

        cust_data = dict(cust)

        # Get customer subscriptions
        cursor.execute("""
            SELECT s.*, p.plan_name
            FROM subscriptions s
            JOIN plans p ON s.plan_id = p.id
            WHERE s.customer_id = ?
            ORDER BY s.id DESC
        """, (cust_id,))
        cust_data['subscriptions'] = [dict(s) for s in cursor.fetchall()]

        # Get customer invoices
        cursor.execute("""
            SELECT * FROM invoices WHERE customer_id = ? ORDER BY id DESC
        """, (cust_id,))
        cust_data['invoices'] = [dict(i) for i in cursor.fetchall()]

        # Get customer payments
        cursor.execute("""
            SELECT p.*, inv.invoice_number
            FROM payments p
            JOIN invoices inv ON p.invoice_id = inv.id
            WHERE p.customer_id = ?
            ORDER BY p.id DESC
        """, (cust_id,))
        cust_data['payments'] = [dict(p) for p in cursor.fetchall()]

        return jsonify({"success": True, "customer": cust_data})

@customers_bp.route('', methods=['POST'])
def create_customer():
    data = request.get_json() or {}
    name = data.get('name', '').strip()
    email = data.get('email', '').strip().lower()
    company = data.get('company', '')
    phone = data.get('phone', '')
    address = data.get('address', '')
    city = data.get('city', '')
    state = data.get('state', '')
    tax_id = data.get('tax_id', '')
    payment_terms = data.get('payment_terms', 'Net 15 Days')

    if not name or not email:
        return jsonify({"success": False, "error": "Name and email are required."}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM customers WHERE LOWER(email) = ?", (email,))
        if cursor.fetchone():
            return jsonify({"success": False, "error": "Customer email already exists."}), 409

        cursor.execute("""
            INSERT INTO customers (name, email, phone, company, address, city, state, tax_id, payment_terms)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (name, email, phone, company, address, city, state, tax_id, payment_terms))
        cust_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CREATE', 'customer', ?, ?)
        """, (str(cust_id), f"Customer '{name}' ({company}) created."))

        return jsonify({"success": True, "message": "Customer created.", "customer_id": cust_id}), 201
