from flask import Blueprint, request, jsonify
from database import get_db

discounts_bp = Blueprint('discounts', __name__)

@discounts_bp.route('', methods=['GET'])
def list_discounts():
    active_only = request.args.get('active', 'false').lower() == 'true'
    query = "SELECT * FROM discounts WHERE 1=1"
    if active_only:
        query += " AND active = 1"
    query += " ORDER BY id DESC"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = [dict(r) for r in cursor.fetchall()]
        return jsonify({"success": True, "discounts": rows})

@discounts_bp.route('', methods=['POST'])
def create_discount():
    data = request.get_json() or {}
    name = data.get('name', '').strip()
    code = data.get('code', '').strip().upper()
    discount_type = data.get('discount_type', 'percentage').lower()
    discount_value = float(data.get('discount_value', 0.0))
    min_purchase = float(data.get('min_purchase', 0.0))
    min_quantity = int(data.get('min_quantity', 1))
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    max_usage = int(data.get('max_usage', 100))

    if not name or discount_value <= 0:
        return jsonify({"success": False, "error": "Name and valid discount value are required."}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        if code:
            cursor.execute("SELECT id FROM discounts WHERE code = ?", (code,))
            if cursor.fetchone():
                return jsonify({"success": False, "error": "Coupon code already exists."}), 409

        cursor.execute("""
            INSERT INTO discounts (
                name, code, discount_type, discount_value, min_purchase, min_quantity,
                start_date, end_date, max_usage, current_usage, active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 1)
        """, (name, code, discount_type, discount_value, min_purchase, min_quantity, start_date, end_date, max_usage))
        disc_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (1, 'Admin', 'CREATE', 'discount', ?, ?)
        """, (str(disc_id), f"Discount rule '{name}' ({discount_value}{'%' if discount_type=='percentage' else ' INR'}) created."))

        return jsonify({"success": True, "message": "Discount rule created.", "discount_id": disc_id}), 201

@discounts_bp.route('/<int:disc_id>/toggle', methods=['POST'])
def toggle_discount(disc_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE discounts SET active = CASE WHEN active = 1 THEN 0 ELSE 1 END WHERE id = ?", (disc_id,))
        return jsonify({"success": True, "message": "Discount status updated."})
