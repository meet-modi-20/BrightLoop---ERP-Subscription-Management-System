import React, { useState, useEffect } from 'react';
import { 
  Layers, 
  Plus, 
  Search, 
  Filter, 
  Check, 
  Calendar, 
  Repeat, 
  Archive, 
  Sparkles,
  ToggleLeft,
  ToggleRight,
  ChevronRight
} from 'lucide-react';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useToast } from '../context/ToastContext';

export default function Plans() {
  const [plans, setPlans] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [freqFilter, setFreqFilter] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [createModal, setCreateModal] = useState(false);
  const [viewMode, setViewMode] = useState('cards'); // 'cards' | 'table'

  // Plan form
  const [planForm, setPlanForm] = useState({
    plan_name: '',
    linked_product_id: '',
    description: '',
    price: '',
    billing_frequency: 'monthly',
    min_quantity: 1,
    start_date: '2026-01-01',
    end_date: '2027-12-31',
    allow_pause: true,
    allow_renewal: true,
    allow_early_closure: true,
    auto_close: false
  });

  const toast = useToast();

  const fetchPlans = async () => {
    setLoading(true);
    try {
      const res = await api.getPlans({ frequency: freqFilter, search: searchTerm });
      if (res.success) {
        setPlans(res.plans || []);
      }
    } catch (e) {
      toast.error('Failed to load plans');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlans();
  }, [freqFilter, searchTerm]);

  useEffect(() => {
    api.getProducts().then(res => {
      if (res.success) setProducts(res.products || []);
    });
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!planForm.plan_name || !planForm.price) {
      toast.error('Please enter plan name and price.');
      return;
    }

    try {
      const res = await api.createPlan({
        ...planForm,
        price: parseFloat(planForm.price) || 0
      });
      if (res.success) {
        toast.success(res.message);
        setCreateModal(false);
        fetchPlans();
      }
    } catch (err) {
      toast.error(err.message || 'Plan creation failed');
    }
  };

  const handleArchiveToggle = async (planId) => {
    try {
      const res = await api.archivePlan(planId);
      if (res.success) {
        toast.success(res.message);
        fetchPlans();
      }
    } catch (e) {
      toast.error('Failed to update status');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Layers className="w-6 h-6 text-brand-600" />
            <span>Subscription Plans & Pricing Rules</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Billing cycles, minimum commitments, pause/renewal policies (Odoo sale.subscription.plan)
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Card / Table Toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setViewMode('cards')}
              className={`px-3 py-1 rounded-lg transition-all ${
                viewMode === 'cards' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Cards
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1 rounded-lg transition-all ${
                viewMode === 'table' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Table
            </button>
          </div>

          <button
            onClick={() => setCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>New Plan</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto text-xs">
          {[
            { id: '', label: 'All Frequencies' },
            { id: 'monthly', label: 'Monthly' },
            { id: 'yearly', label: 'Yearly' },
            { id: 'weekly', label: 'Weekly' },
            { id: 'daily', label: 'Daily' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFreqFilter(f.id)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                freqFilter === f.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search plan name, description..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-100/80 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
          />
        </div>
      </div>

      {/* Cards View */}
      {viewMode === 'cards' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            <div className="col-span-full py-12 text-center text-slate-400">Loading plans...</div>
          ) : plans.length === 0 ? (
            <div className="col-span-full py-12 text-center text-slate-400">No plans found.</div>
          ) : (
            plans.map((plan) => (
              <div
                key={plan.id}
                className="erp-card p-6 flex flex-col justify-between relative overflow-hidden group hover:border-brand-300"
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-2.5 py-1 rounded-full border border-brand-200">
                        {plan.billing_frequency} Cycle
                      </span>
                      <h3 className="text-lg font-bold text-slate-900 mt-2">{plan.plan_name}</h3>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                        {plan.description}
                      </p>
                    </div>
                  </div>

                  {/* Pricing Display */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-baseline justify-between">
                    <div>
                      <span className="text-2xl font-black text-slate-900 font-mono tracking-tight">
                        {formatCurrency(plan.price)}
                      </span>
                      <span className="text-xs text-slate-500 ml-1">/ {plan.billing_frequency}</span>
                    </div>
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                      {plan.active_subscriber_count || 0} active
                    </span>
                  </div>

                  {/* Policy Features Checklist */}
                  <div className="space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Linked Product: <strong>{plan.linked_product_name || 'Core SaaS'}</strong></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Pause Permitted: {plan.allow_pause ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Auto-Renewal: {plan.allow_renewal ? 'Supported' : 'Disabled'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Early Cancellation: {plan.allow_early_closure ? 'Allowed' : 'Locked'}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    plan.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {plan.active ? 'Active Plan' : 'Archived'}
                  </span>
                  <button
                    onClick={() => handleArchiveToggle(plan.id)}
                    className="text-xs text-slate-500 hover:text-slate-800 font-medium"
                  >
                    {plan.active ? 'Archive' : 'Restore'}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Table View */}
      {viewMode === 'table' && (
        <div className="erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                  <th className="py-3 px-4">Plan Name</th>
                  <th className="py-3 px-4">Linked Product</th>
                  <th className="py-3 px-4">Recurrence</th>
                  <th className="py-3 px-4">Price</th>
                  <th className="py-3 px-4">Pause / Renew</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {plans.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-bold text-slate-900">{p.plan_name}</td>
                    <td className="py-3 px-4 text-slate-600">{p.linked_product_name || 'Core Suite'}</td>
                    <td className="py-3 px-4 uppercase text-[10px] font-bold text-indigo-700 font-mono">{p.billing_frequency}</td>
                    <td className="py-3 px-4 font-bold text-slate-900 font-mono">{formatCurrency(p.price)}</td>
                    <td className="py-3 px-4 text-slate-500">
                      {p.allow_pause ? 'Pause ✓' : 'Pause ✗'} • {p.allow_renewal ? 'Renew ✓' : 'Renew ✗'}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        p.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {p.active ? 'Active' : 'Archived'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleArchiveToggle(p.id)}
                        className="text-xs font-semibold text-brand-600 hover:text-brand-700"
                      >
                        {p.active ? 'Archive' : 'Restore'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Create Modal */}
      {createModal && (
        <Modal
          isOpen={createModal}
          onClose={() => setCreateModal(false)}
          title="Create New Subscription Plan"
          subtitle="Configure billing periodicity, pricing and lifecycle permissions"
          maxWidth="max-w-xl"
        >
          <form onSubmit={handleCreate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Plan Name</label>
              <input
                type="text"
                value={planForm.plan_name}
                onChange={(e) => setPlanForm({ ...planForm, plan_name: e.target.value })}
                placeholder="e.g. Enterprise Cloud Annual"
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Linked Product</label>
                <select
                  value={planForm.linked_product_id}
                  onChange={(e) => setPlanForm({ ...planForm, linked_product_id: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="">-- Choose Linked Product --</option>
                  {products.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Billing Frequency</label>
                <select
                  value={planForm.billing_frequency}
                  onChange={(e) => setPlanForm({ ...planForm, billing_frequency: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="yearly">Yearly</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Plan Recurring Price (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={planForm.price}
                  onChange={(e) => setPlanForm({ ...planForm, price: e.target.value })}
                  placeholder="4999"
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Minimum Commitment (Units)</label>
                <input
                  type="number"
                  min="1"
                  value={planForm.min_quantity}
                  onChange={(e) => setPlanForm({ ...planForm, min_quantity: parseInt(e.target.value) || 1 })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Plan Description</label>
              <textarea
                value={planForm.description}
                onChange={(e) => setPlanForm({ ...planForm, description: e.target.value })}
                placeholder="Included capabilities, webhook rate limits, priority support..."
                rows="2"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium resize-none"
              />
            </div>

            {/* Lifecycle Permission Toggles */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
              <p className="font-bold text-slate-800">Subscriber Policies & Lifecycle Options:</p>
              <div className="grid grid-cols-2 gap-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={planForm.allow_pause}
                    onChange={(e) => setPlanForm({ ...planForm, allow_pause: e.target.checked })}
                    className="rounded text-brand-600 focus:ring-brand-500"
                  />
                  <span>Allow Customer Pause</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={planForm.allow_renewal}
                    onChange={(e) => setPlanForm({ ...planForm, allow_renewal: e.target.checked })}
                    className="rounded text-brand-600 focus:ring-brand-500"
                  />
                  <span>Permit Auto-Renewal</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={planForm.allow_early_closure}
                    onChange={(e) => setPlanForm({ ...planForm, allow_early_closure: e.target.checked })}
                    className="rounded text-brand-600 focus:ring-brand-500"
                  />
                  <span>Allow Early Termination</span>
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCreateModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
              >
                Save Plan
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
