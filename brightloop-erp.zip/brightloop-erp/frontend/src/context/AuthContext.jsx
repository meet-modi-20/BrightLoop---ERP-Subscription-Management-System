import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext();

export const DEMO_ACCOUNTS = {
  admin: { email: 'admin@brightloop.com', password: 'Admin@123!', role: 'ADMIN' },
  staff: { email: 'staff@brightloop.com', password: 'Staff@123!', role: 'STAFF' },
  customer: { email: 'customer@brightloop.com', password: 'Customer@123!', role: 'CUSTOMER' }
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('brightloop_user');
    const savedToken = localStorage.getItem('brightloop_token');
    if (savedUser && savedToken) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        localStorage.removeItem('brightloop_user');
        localStorage.removeItem('brightloop_token');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const res = await api.login({ email, password });
    if (res.success && res.user) {
      setUser(res.user);
      localStorage.setItem('brightloop_user', JSON.stringify(res.user));
      localStorage.setItem('brightloop_token', res.user.token);
      return res.user;
    }
    throw new Error(res.error || 'Login failed');
  };

  const register = async (userData) => {
    const res = await api.register(userData);
    if (res.success && res.user) {
      setUser(res.user);
      localStorage.setItem('brightloop_user', JSON.stringify(res.user));
      localStorage.setItem('brightloop_token', res.user.token);
      return res.user;
    }
    throw new Error(res.error || 'Registration failed');
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('brightloop_user');
    localStorage.removeItem('brightloop_token');
  };

  const switchRole = async (roleKey) => {
    const acc = DEMO_ACCOUNTS[roleKey];
    if (acc) {
      return await login(acc.email, acc.password);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, switchRole }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
