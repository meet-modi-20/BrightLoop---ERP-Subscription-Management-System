import React, { useState, useEffect } from 'react';
import { 
  Repeat, 
  Receipt, 
  CreditCard, 
  Calendar, 
  Pause, 
  RotateCw, 
  XCircle, 
  Printer, 
  Download, 
  ShieldCheck, 
  ExternalLink,
  ChevronRight,
  Clock
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function CustomerPortal({ setCurrentView, setSelectedId }) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'subscriptions' | 'invoices' | 'payments'
  const [subscriptions, setSubscriptions] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  // Request modals
  const [requestModal, setRequestModal] = useState({ open: false, type: '', sub: null, text: '' });

  const toast = useToast();

  const fetchCustomerData = async () => {
    setLoading(true);
    try {
      const custId = user?.customer_id;
      const [sRes, iRes, pRes] = await Promise.all([
        api.getSubscriptions(custId ? { customer_id: custId } : {}),
        api.getInvoices(custId ? { customer_id: custId } : {}),
        api.getPayments(custId ? { customer_id: custId } : {})
      ]);

      if (sRes.success) setSubscriptions(sRes.subscriptions || []);
      if (iRes.success) setInvoices(iRes.invoices || []);
      if (pRes.success) setPayments(pRes.payments || []);
    } catch (e) {
      toast.error('Failed to load customer portal data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomerData();
  }, [user]);

  // Handle client requests (Pause, Cancel, Renew)
  const handleSubmitRequest = async () => {
    const { type, sub, text } = requestModal;
    try {
      if (type === 'pause') {
        await api.pauseSubscription(sub.id, text || 'Client self-service pause request');
        toast.success(`Pause request for ${sub.subscription_number} processed.`);
      } else if (type === 'cancel') {
        await api.closeSubscription(sub.id, text || 'Client cancellation request');
        toast.success(`Cancellation request for ${sub.subscription_number} processed.`);
      } else if (type === 'renew') {
        await api.renewSubscription(sub.id);
        toast.success(`Renewal for ${sub.subscription_number} confirmed!`);
      }
      setRequestModal({ open: false, type: '', sub: null, text: '' });
      fetchCustomerData();
    } catch (e) {
      toast.error('Request submission failed');
    }
  };

  // Aggregates
  const activeSubs = subscriptions.filter(s => s.status === 'ACTIVE');
  const totalPaid = payments.reduce((acc, p) => acc + (p.status === 'completed' ? p.amount : 0), 0);
  const outstandingBal = invoices.reduce((acc, inv) => {
    if (inv.payment_status === 'confirmed' || inv.payment_status === 'overdue') {
      return acc + Math.max(0, inv.grand_total - inv.amount_paid);
    }
    return acc;
  }, 0);

  const nextUpcomingBill = activeSubs.length > 0 
    ? [...activeSubs].sort((a,b) => new Date(a.next_billing_date) - new Date(b.next_billing_date))[0]
    : null;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 bg-purple-500/20 px-2.5 py-1 rounded-full border border-purple-500/30">
            Client Self-Service Portal
          </span>
          <h1 className="text-2xl font-black tracking-tight mt-2">Welcome, {user?.name || 'Customer'}</h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Manage your recurring enterprise licenses, inspect tax invoices and track payment history
          </p>
        </div>

        <div className="p-3 bg-white/10 rounded-xl backdrop-blur-md text-xs font-mono space-y-1">
          <p className="text-slate-300 text-[10px] uppercase font-bold">Authenticated Identity</p>
          <p className="font-bold text-white">{user?.email}</p>
        </div>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="erp-card p-4">
          <p className="text-[10px] font-bold uppercase text-slate-400">Active Subscriptions</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{activeSubs.length}</p>
          <span className="text-[10px] text-emerald-600 font-semibold">Running licenses</span>
        </div>
        <div className="erp-card p-4">
          <p className="text-[10px] font-bold uppercase text-slate-400">Next Upcoming Bill</p>
          <p className="text-lg font-bold text-brand-600 mt-1 font-mono">
            {nextUpcomingBill ? formatDate(nextUpcomingBill.next_billing_date) : 'None Due'}
          </p>
          <span className="text-[10px] text-slate-500">
            {nextUpcomingBill ? formatCurrency(nextUpcomingBill.total_amount) : 'All settled'}
          </span>
        </div>
        <div className="erp-card p-4">
          <p className="text-[10px] font-bold uppercase text-slate-400">Total Remitted</p>
          <p className="text-2xl font-bold text-emerald-700 mt-1 font-mono">{formatCurrency(totalPaid)}</p>
          <span className="text-[10px] text-slate-500">{payments.length} transactions</span>
        </div>
        <div className="erp-card p-4">
          <p className="text-[10px] font-bold uppercase text-slate-400">Outstanding Balance</p>
          <p className="text-2xl font-bold text-amber-700 mt-1 font-mono">{formatCurrency(outstandingBal)}</p>
          <span className="text-[10px] text-slate-500">Due on open invoices</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-1.5 text-xs font-semibold">
        {[
          { id: 'overview', label: 'My Subscriptions' },
          { id: 'invoices', label: 'My Invoices & Tax Receipts' },
          { id: 'payments', label: 'My Remittance History' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-xl transition-all ${
              activeTab === tab.id
                ? 'bg-brand-600 text-white shadow-xs font-bold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content 1: My Subscriptions */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {subscriptions.length === 0 ? (
              <div className="col-span-full py-12 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
                You have no subscriptions linked to this customer account.
              </div>
            ) : (
              subscriptions.map((sub) => (
                <div key={sub.id} className="erp-card p-5 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-brand-600 text-sm">{sub.subscription_number}</span>
                          <StatusBadge status={sub.status} />
                        </div>
                        <h3 className="text-base font-bold text-slate-900 mt-1">{sub.plan_name}</h3>
                      </div>
                      <span className="font-mono font-bold text-slate-900 text-sm">
                        {formatCurrency(sub.total_amount)}
                        <span className="text-[10px] text-slate-400 block font-normal text-right">/ {sub.billing_frequency}</span>
                      </span>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-slate-400 text-[10px] uppercase font-bold">Start Date</span>
                        <p className="font-semibold text-slate-800 font-mono mt-0.5">{formatDate(sub.start_date)}</p>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[10px] uppercase font-bold">Next Billing</span>
                        <p className="font-semibold text-emerald-700 font-mono mt-0.5">{formatDate(sub.next_billing_date)}</p>
                      </div>
                    </div>
                  </div>

                  {/* Customer Self-Service Actions */}
                  <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                    <button
                      onClick={() => {
                        setSelectedId(sub.subscription_number);
                        setCurrentView('subscription_detail');
                      }}
                      className="font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
                    >
                      <span>View Full Timeline</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center gap-1.5">
                      {sub.status === 'ACTIVE' && (
                        <>
                          <button
                            onClick={() => setRequestModal({ open: true, type: 'pause', sub, text: '' })}
                            className="px-2.5 py-1 text-slate-600 hover:text-purple-700 hover:bg-purple-50 rounded-lg font-semibold transition-colors"
                          >
                            Request Pause
                          </button>
                          <button
                            onClick={() => setRequestModal({ open: true, type: 'cancel', sub, text: '' })}
                            className="px-2.5 py-1 text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg font-semibold transition-colors"
                          >
                            Cancel
                          </button>
                        </>
                      )}
                      {(sub.status === 'CLOSED' || sub.status === 'EXPIRED') && (
                        <button
                          onClick={() => setRequestModal({ open: true, type: 'renew', sub, text: '' })}
                          className="px-3 py-1 bg-brand-600 text-white rounded-lg font-bold"
                        >
                          Request Renewal
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab Content 2: My Invoices */}
      {activeTab === 'invoices' && (
        <div className="erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Invoice #</th>
                  <th className="py-3 px-4">Invoice Date</th>
                  <th className="py-3 px-4">Due Date</th>
                  <th className="py-3 px-4">Grand Total</th>
                  <th className="py-3 px-4">Balance Due</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">View / PDF</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="py-8 text-center text-slate-400">No invoices generated yet.</td>
                  </tr>
                ) : (
                  invoices.map((inv) => {
                    const bal = Math.max(0, inv.grand_total - inv.amount_paid);
                    return (
                      <tr key={inv.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono font-bold text-brand-600">{inv.invoice_number}</td>
                        <td className="py-3 px-4 font-mono text-slate-600">{formatDate(inv.invoice_date)}</td>
                        <td className="py-3 px-4 font-mono text-slate-600">{formatDate(inv.due_date)}</td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">{formatCurrency(inv.grand_total)}</td>
                        <td className="py-3 px-4 font-mono font-semibold text-amber-700">{formatCurrency(bal)}</td>
                        <td className="py-3 px-4"><StatusBadge status={inv.payment_status} type="invoice" /></td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => {
                              setSelectedId(inv.invoice_number);
                              setCurrentView('invoice_detail');
                            }}
                            className="px-2.5 py-1 text-brand-600 hover:text-brand-700 hover:bg-brand-50 rounded-lg font-semibold inline-flex items-center gap-1"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Invoice</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab Content 3: My Payments */}
      {activeTab === 'payments' && (
        <div className="erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Payment Ref</th>
                  <th className="py-3 px-4">Payment Date</th>
                  <th className="py-3 px-4">Method</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {payments.length === 0 ? (
                  <tr>
                    <td colSpan="5" className="py-8 text-center text-slate-400">No payment receipts found.</td>
                  </tr>
                ) : (
                  payments.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono font-bold text-slate-800">{p.payment_reference}</td>
                      <td className="py-3 px-4 font-mono text-slate-600">{formatDate(p.payment_date)}</td>
                      <td className="py-3 px-4 uppercase text-[10px] font-bold text-slate-600">{p.payment_method}</td>
                      <td className="py-3 px-4 font-mono font-bold text-emerald-700">{formatCurrency(p.amount)}</td>
                      <td className="py-3 px-4"><StatusBadge status={p.status} type="payment" /></td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Request Modal */}
      {requestModal.open && (
        <Modal
          isOpen={requestModal.open}
          onClose={() => setRequestModal({ open: false, type: '', sub: null, text: '' })}
          title={`Confirm ${requestModal.type.toUpperCase()} Request`}
          subtitle={`Subscription: ${requestModal.sub?.subscription_number}`}
          maxWidth="max-w-md"
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-600">
              Please submit notes or reason for this {requestModal.type} request.
            </p>
            <textarea
              value={requestModal.text}
              onChange={(e) => setRequestModal({ ...requestModal, text: e.target.value })}
              placeholder="e.g. Migration completed, need to hold billing for 2 weeks..."
              rows="3"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium resize-none"
            />
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setRequestModal({ open: false, type: '', sub: null, text: '' })}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitRequest}
                className="px-4 py-1.5 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold"
              >
                Submit Request
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
