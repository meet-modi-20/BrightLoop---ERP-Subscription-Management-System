import React, { useState, useEffect } from 'react';
import { 
  Tag, 
  Plus, 
  Percent, 
  Calendar, 
  Users, 
  ShieldAlert, 
  Check, 
  X,
  Sparkles
} from 'lucide-react';
import Modal from '../components/Modal';
import { api } from '../services/api';
import { formatCurrency, formatDate } from '../utils/formatters';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function Discounts() {
  const { user } = useAuth();
  const [discounts, setDiscounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [createModal, setCreateModal] = useState(false);

  // Form
  const [discForm, setDiscForm] = useState({
    name: '',
    code: '',
    discount_type: 'percentage',
    discount_value: '',
    min_purchase: 0,
    min_quantity: 1,
    start_date: '2026-01-01',
    end_date: '2026-12-31',
    max_usage: 100
  });

  const toast = useToast();
  const isAdmin = user?.role === 'admin';

  const fetchDiscounts = async () => {
    setLoading(true);
    try {
      const res = await api.getDiscounts(false);
      if (res.success) {
        setDiscounts(res.discounts || []);
      }
    } catch (e) {
      toast.error('Failed to load discounts');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDiscounts();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!isAdmin) {
      toast.error('Only administrators can configure discount rules.');
      return;
    }

    try {
      const res = await api.createDiscount({
        ...discForm,
        discount_value: parseFloat(discForm.discount_value) || 0,
        min_purchase: parseFloat(discForm.min_purchase) || 0,
        max_usage: parseInt(discForm.max_usage) || 100
      });
      if (res.success) {
        toast.success(res.message);
        setCreateModal(false);
        fetchDiscounts();
      }
    } catch (err) {
      toast.error(err.message || 'Creation failed');
    }
  };

  const handleToggle = async (id) => {
    if (!isAdmin) {
      toast.error('Only administrators can modify discounts.');
      return;
    }

    try {
      const res = await api.toggleDiscount(id);
      if (res.success) {
        toast.success(res.message);
        fetchDiscounts();
      }
    } catch (e) {
      toast.error('Failed to update status');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Tag className="w-6 h-6 text-brand-600" />
            <span>Discount & Promotional Rules Engine</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Admin automated discount evaluation applied during recurring invoice generation
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>New Discount Rule</span>
          </button>
        )}
      </div>

      {!isAdmin && (
        <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
          <span>Role Restricted: Staff members have read-only visibility into promotional discount rules.</span>
        </div>
      )}

      {/* Discounts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-400">Loading discount policies...</div>
        ) : discounts.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-400">No discount rules found.</div>
        ) : (
          discounts.map((disc) => {
            const usagePercent = Math.min(100, Math.round((disc.current_usage / disc.max_usage) * 100));
            const isExhausted = disc.current_usage >= disc.max_usage;

            return (
              <div key={disc.id} className="erp-card p-5 flex flex-col justify-between group">
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        disc.discount_type === 'percentage' ? 'bg-indigo-50 text-indigo-700' : 'bg-emerald-50 text-emerald-700'
                      }`}>
                        {disc.discount_type === 'percentage' ? `${disc.discount_value}% OFF` : `₹${disc.discount_value} FLAT OFF`}
                      </span>
                      <h3 className="text-base font-bold text-slate-900 mt-2">{disc.name}</h3>
                      {disc.code && (
                        <p className="font-mono text-xs text-brand-600 font-bold mt-0.5">CODE: {disc.code}</p>
                      )}
                    </div>
                  </div>

                  {/* Conditions */}
                  <div className="space-y-1.5 text-xs text-slate-600 p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Min Purchase:</span>
                      <span className="font-semibold">{formatCurrency(disc.min_purchase)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Validity:</span>
                      <span className="font-mono text-[11px]">{formatDate(disc.start_date)} - {formatDate(disc.end_date)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Applicability:</span>
                      <span className="font-semibold text-purple-700">All Subscriptions</span>
                    </div>
                  </div>

                  {/* Usage Meter */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-500 text-[11px]">Usage Redemption:</span>
                      <span className="font-mono font-bold text-slate-800 text-[11px]">
                        {disc.current_usage} / {disc.max_usage} ({usagePercent}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isExhausted ? 'bg-rose-500' : usagePercent > 75 ? 'bg-amber-500' : 'bg-brand-600'
                        }`}
                        style={{ width: `${usagePercent}%` }}
                      />
                    </div>
                    {isExhausted && (
                      <p className="text-[10px] text-rose-600 font-semibold mt-1">Usage limit reached</p>
                    )}
                  </div>
                </div>

                <div className="pt-3 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    disc.active && !isExhausted ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {disc.active && !isExhausted ? 'Active Rule' : 'Inactive'}
                  </span>

                  {isAdmin && (
                    <button
                      onClick={() => handleToggle(disc.id)}
                      className="text-xs font-semibold text-brand-600 hover:text-brand-700"
                    >
                      {disc.active ? 'Disable' : 'Enable'}
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Create Modal */}
      {createModal && (
        <Modal
          isOpen={createModal}
          onClose={() => setCreateModal(false)}
          title="Create Discount Rule"
          subtitle="Define automatic promotion for recurring billing"
          maxWidth="max-w-xl"
        >
          <form onSubmit={handleCreate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Rule Name</label>
              <input
                type="text"
                value={discForm.name}
                onChange={(e) => setDiscForm({ ...discForm, name: e.target.value })}
                placeholder="e.g. Odoo Hackathon Grand Offer"
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Promo Code (Optional)</label>
                <input
                  type="text"
                  value={discForm.code}
                  onChange={(e) => setDiscForm({ ...discForm, code: e.target.value.toUpperCase() })}
                  placeholder="HACKATHON2026"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Discount Type</label>
                <select
                  value={discForm.discount_type}
                  onChange={(e) => setDiscForm({ ...discForm, discount_type: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                >
                  <option value="percentage">Percentage (%)</option>
                  <option value="fixed">Fixed Amount (₹)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Discount Value</label>
                <input
                  type="number"
                  min="1"
                  value={discForm.discount_value}
                  onChange={(e) => setDiscForm({ ...discForm, discount_value: e.target.value })}
                  placeholder="20"
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Min. Order (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={discForm.min_purchase}
                  onChange={(e) => setDiscForm({ ...discForm, min_purchase: e.target.value })}
                  placeholder="2000"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Max Redemptions</label>
                <input
                  type="number"
                  min="1"
                  value={discForm.max_usage}
                  onChange={(e) => setDiscForm({ ...discForm, max_usage: e.target.value })}
                  placeholder="500"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCreateModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20"
              >
                Save Discount Rule
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
