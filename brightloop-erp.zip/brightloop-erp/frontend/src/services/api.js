const API_BASE = '/api';

async function request(endpoint, options = {}) {
  const token = localStorage.getItem('brightloop_token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...(options.headers || {})
  };

  const config = {
    ...options,
    headers
  };

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, config);
    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      const errorMsg = data.error || data.message || `Request failed with status ${response.status}`;
      throw new Error(errorMsg);
    }
    return data;
  } catch (err) {
    console.error(`API Error on [${options.method || 'GET'} ${endpoint}]:`, err);
    throw err;
  }
}

export const api = {
  // Auth
  login: (credentials) => request('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
  register: (userData) => request('/auth/register', { method: 'POST', body: JSON.stringify(userData) }),
  getCurrentUser: (userId) => request(`/auth/me?user_id=${userId}`),

  // Dashboard
  getDashboardStats: (range = '30d') => request(`/dashboard/stats?range=${range}`),

  // Subscriptions
  getSubscriptions: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/subscriptions${q ? `?${q}` : ''}`);
  },
  getSubscription: (id) => request(`/subscriptions/${id}`),
  createSubscription: (data) => request('/subscriptions', { method: 'POST', body: JSON.stringify(data) }),
  convertQuotation: (id) => request(`/subscriptions/${id}/convert-quotation`, { method: 'POST' }),
  confirmSubscription: (id) => request(`/subscriptions/${id}/confirm`, { method: 'POST' }),
  activateSubscription: (id) => request(`/subscriptions/${id}/activate`, { method: 'POST' }),
  pauseSubscription: (id, reason) => request(`/subscriptions/${id}/pause`, { method: 'POST', body: JSON.stringify({ reason }) }),
  resumeSubscription: (id) => request(`/subscriptions/${id}/resume`, { method: 'POST' }),
  renewSubscription: (id) => request(`/subscriptions/${id}/renew`, { method: 'POST' }),
  closeSubscription: (id, reason) => request(`/subscriptions/${id}/close`, { method: 'POST', body: JSON.stringify({ reason }) }),
  manualGenerateInvoice: (id) => request(`/subscriptions/${id}/generate-invoice`, { method: 'POST' }),

  // Quotations
  getQuotations: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/quotations${q ? `?${q}` : ''}`);
  },
  getQuotation: (id) => request(`/quotations/${id}`),
  createQuotation: (data) => request('/quotations', { method: 'POST', body: JSON.stringify(data) }),
  confirmQuotation: (id) => request(`/quotations/${id}/confirm`, { method: 'POST' }),
  duplicateQuotation: (id) => request(`/quotations/${id}/duplicate`, { method: 'POST' }),
  cancelQuotation: (id) => request(`/quotations/${id}/cancel`, { method: 'POST' }),

  // Invoices & Recurring Engine
  getInvoices: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/invoices${q ? `?${q}` : ''}`);
  },
  getInvoice: (id) => request(`/invoices/${id}`),
  generateDueInvoices: (data = {}) => request('/invoices/generate-due', { method: 'POST', body: JSON.stringify(data) }),
  previewDueInvoices: (date) => request(`/invoices/preview-due${date ? `?target_date=${date}` : ''}`),
  confirmInvoice: (id) => request(`/invoices/${id}/confirm`, { method: 'POST' }),
  cancelInvoice: (id) => request(`/invoices/${id}/cancel`, { method: 'POST' }),
  sendInvoice: (id) => request(`/invoices/${id}/send`, { method: 'POST' }),

  // Payments
  getPayments: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/payments${q ? `?${q}` : ''}`);
  },
  recordPayment: (data) => request('/payments', { method: 'POST', body: JSON.stringify(data) }),

  // Products
  getProducts: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/products${q ? `?${q}` : ''}`);
  },
  getProduct: (id) => request(`/products/${id}`),
  createProduct: (data) => request('/products', { method: 'POST', body: JSON.stringify(data) }),
  updateProduct: (id, data) => request(`/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteProduct: (id) => request(`/products/${id}`, { method: 'DELETE' }),

  // Plans
  getPlans: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/plans${q ? `?${q}` : ''}`);
  },
  getPlan: (id) => request(`/plans/${id}`),
  createPlan: (data) => request('/plans', { method: 'POST', body: JSON.stringify(data) }),
  updatePlan: (id, data) => request(`/plans/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  archivePlan: (id) => request(`/plans/${id}/archive`, { method: 'POST' }),

  // Customers
  getCustomers: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/customers${q ? `?${q}` : ''}`);
  },
  getCustomer: (id) => request(`/customers/${id}`),
  createCustomer: (data) => request('/customers', { method: 'POST', body: JSON.stringify(data) }),

  // Discounts
  getDiscounts: (active = false) => request(`/discounts?active=${active}`),
  createDiscount: (data) => request('/discounts', { method: 'POST', body: JSON.stringify(data) }),
  toggleDiscount: (id) => request(`/discounts/${id}/toggle`, { method: 'POST' }),

  // Reports
  getAnalytics: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/reports/analytics${q ? `?${q}` : ''}`);
  },

  // Notifications
  getNotifications: (userId) => request(`/notifications${userId ? `?user_id=${userId}` : ''}`),
  markNotificationRead: (id) => request(`/notifications/${id}/read`, { method: 'POST' }),
  markAllNotificationsRead: (userId) => request('/notifications/read-all', { method: 'POST', body: JSON.stringify({ user_id: userId }) }),

  // Odoo Architecture
  getOdooBlueprint: () => request('/odoo/blueprint'),
  getOdooExportSample: () => request('/odoo/export-sample')
};
