import re
from flask import Blueprint, request, jsonify
from werkzeug.security import check_password_hash, generate_password_hash
from database import get_db

auth_bp = Blueprint('auth', __name__)

def validate_password_strength(password):
    if len(password) < 9:
        return False, "Password must be at least 9 characters long."
    if not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter."
    if not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter."
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        return False, "Password must contain at least one special character (!@#$%^&* etc)."
    return True, ""

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return jsonify({"success": False, "error": "Email and password are required."}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE LOWER(email) = ?", (email,))
        user = cursor.fetchone()

        if not user or not check_password_hash(user['password_hash'], password):
            return jsonify({"success": False, "error": "Invalid email or password."}), 401

        if user['status'] != 'active':
            return jsonify({"success": False, "error": "Account is inactive. Contact administrator."}), 403

        # If user is a customer, get their customer profile id
        customer_id = None
        if user['role'] == 'customer':
            cursor.execute("SELECT id FROM customers WHERE user_id = ? OR email = ?", (user['id'], user['email']))
            cust = cursor.fetchone()
            if cust:
                customer_id = cust['id']

        user_info = {
            "id": user['id'],
            "name": user['full_name'],
            "email": user['email'],
            "role": user['role'],
            "customer_id": customer_id,
            "token": f"token-{user['id']}-{user['role']}"
        }

        # Log login
        cursor.execute("""
            INSERT INTO activity_logs (user_id, user_name, action, entity_type, entity_id, description)
            VALUES (?, ?, 'LOGIN', 'user', ?, ?)
        """, (user['id'], user['full_name'], str(user['id']), f"User logged in as {user['role'].upper()}."))

        return jsonify({
            "success": True,
            "message": "Login successful.",
            "user": user_info
        })

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    full_name = data.get('full_name', '').strip()
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')
    confirm_password = data.get('confirm_password', '')

    if not full_name or not email or not password:
        return jsonify({"success": False, "error": "All fields are required."}), 400

    if password != confirm_password:
        return jsonify({"success": False, "error": "Passwords do not match."}), 400

    valid, err_msg = validate_password_strength(password)
    if not valid:
        return jsonify({"success": False, "error": err_msg}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE LOWER(email) = ?", (email,))
        if cursor.fetchone():
            return jsonify({"success": False, "error": "An account with this email already exists."}), 409

        password_hash = generate_password_hash(password)
        cursor.execute("""
            INSERT INTO users (full_name, email, password_hash, role)
            VALUES (?, ?, ?, 'customer')
        """, (full_name, email, password_hash))
        user_id = cursor.lastrowid

        # Also create customer entry
        cursor.execute("""
            INSERT INTO customers (user_id, name, email, company)
            VALUES (?, ?, ?, ?)
        """, (user_id, full_name, email, data.get('company', full_name)))
        customer_id = cursor.lastrowid

        # Notification
        cursor.execute("""
            INSERT INTO notifications (user_id, title, message, category, link)
            VALUES (?, 'Welcome to Brightloop ERP!', 'Your account has been set up successfully. Explore our subscription plans.', 'general', '/portal')
        """, (user_id,))

        user_info = {
            "id": user_id,
            "name": full_name,
            "email": email,
            "role": "customer",
            "customer_id": customer_id,
            "token": f"token-{user_id}-customer"
        }

        return jsonify({
            "success": True,
            "message": "Registration successful.",
            "user": user_info
        }), 201

@auth_bp.route('/me', methods=['GET'])
def get_current_user():
    user_id = request.args.get('user_id')
    if not user_id:
        return jsonify({"success": False, "error": "User ID required"}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, full_name, email, role, status FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        if not user:
            return jsonify({"success": False, "error": "User not found"}), 404

        customer_id = None
        if user['role'] == 'customer':
            cursor.execute("SELECT id FROM customers WHERE user_id = ?", (user['id'],))
            cust = cursor.fetchone()
            if cust:
                customer_id = cust['id']

        return jsonify({
            "success": True,
            "user": {
                "id": user['id'],
                "name": user['full_name'],
                "email": user['email'],
                "role": user['role'],
                "customer_id": customer_id
            }
        })
